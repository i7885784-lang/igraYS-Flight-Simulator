#ifndef FSAIRSHOWCONFIG_IS_INCLUDED
#define FSAIRSHOWCONFIG_IS_INCLUDED
#include "fssquadlimits.h"
struct FsAirshowConfig
{
    bool supply=true,synchronized=true,autoAfterburner=true;
    int burst=16;double interval=0.2,cameraSensitivity=0.35;
    int rgb[FsMaxShowAircraft][3];
    FsAirshowConfig(){for(auto &c:rgb)for(auto &v:c)v=255;}
};
#endif
