Исходники тестовой сборки №4. Включены текущий движок, библиотеки, модели и конвертеры; Су-47/Су-57 сохранены из теста №3а. Су-34 и его геометрии здесь нет.

Сборка Windows x86: CMake + MinGW-w64 i686, Release, target ysflight32_gl1. Конфигурация toolchain в mingw32.cmake; линковка -static -static-libgcc -static-libstdc++ -mwindows. Диагностический Win64 использует -DV861_VALIDATION; передаваемый Win32 собран без него.

Модель Су-27/МиГ-29: Python + зависимости конвертера; python model-source/build_model.py. Настоящая Windows 10 x86 не проверялась; игровые проверки Win64/Wine. Лицензии и уведомления сохранены.
