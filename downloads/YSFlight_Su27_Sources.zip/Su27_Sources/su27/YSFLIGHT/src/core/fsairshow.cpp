#define FSSIMPLEWINDOW_DONT_INCLUDE_OPENGL_HEADERS
#include <fssimplewindow.h>
#include "fs.h"
#include "fsairshow.h"
#include "fssmokepalette.h"
#include "fsafterburnervisual.h"
#include "fsformationautopilot.h"
#include "fsoperation.h"
#include "fstextresource.h"
#include "graphics/common/fsopengl.h"
namespace{const wchar_t *T(const char *k,const wchar_t *s){return FsGetTextResource(k,s);}YsColor C(int r,int g,int b){YsColor c;c.SetIntRGB(r,g,b);return c;}}
std::shared_ptr<FsSimExtension_Airshow> FsGetAirshow(const FsSimulation *sim)
{return sim ? std::dynamic_pointer_cast<FsSimExtension_Airshow>(sim->FindExtension(FsSimExtension_Airshow::Ident())) : nullptr;}
std::function<std::shared_ptr<FsSimExtensionBase>(void)> FsSimExtension_Airshow::Generator()
{return [](){return std::make_shared<FsSimExtension_Airshow>();};}
FsAirplane *FsSimExtension_Airshow::Aircraft(const FsSimulation *sim,int i) const
{
 auto player=sim->GetPlayerAirplane();if(i==0)return player;
 for(auto a=sim->FindNextAirplane(nullptr);a;a=sim->FindNextAirplane(a))if(a!=player && a->Prop().IsActive()==YSTRUE && a->squadSlot==i-1 && a->squadLeaderKey==FsExistence::GetSearchKey(player))return a;
 return nullptr;
}
YsArray<YsString> FsSimExtension_Airshow::Serialize(const FsSimulation *sim)
{
 YsArray<YsString> rows;YsString s;s.Printf("EXTENSIO %s CONFIG %d %d %d %d %.3f %.3f",Ident(),config.supply,config.synchronized,config.autoAfterburner,config.burst,config.interval,config.cameraSensitivity);rows.Append(s);
 s.Printf("EXTENSIO %s COVERHEIGHT %.0f",Ident(),config.coverHeight);rows.Append(s);
 for(int i=0;i<FsMaxShowAircraft;++i){s.Printf("EXTENSIO %s COLOR %d %d %d %d",Ident(),i,config.rgb[i][0],config.rgb[i][1],config.rgb[i][2]);rows.Append(s);}
 for(const auto &e:su27Events){int id=e.id;if(e.key!=YSNULLHASHKEY)if(auto a=sim->FindAirplane(e.key))id=a->ysfId;s.Printf("EXTENSIO %s SU27EVENT %.6f %d %d %d %d %d %d %.8f %.8f %.8f %.8f",Ident(),e.time,id,int(e.battery),int(e.pumps),int(e.left),int(e.right),int(e.parking),e.sl,e.sr,e.canopy,e.target);rows.Append(s);}
 return rows;
}
YSRESULT FsSimExtension_Airshow::ProcessCommand(FsSimulation *,const YsConstArrayMask<YsString> &a)
{
 if(a.GetN()>=14 && 0==a[2].Strcmp("SU27EVENT")){Su27Event e;e.time=YsGreater(0.0,atof(a[3]));e.id=atoi(a[4]);e.battery=atoi(a[5])!=0;e.pumps=atoi(a[6])!=0;e.left=atoi(a[7])!=0;e.right=atoi(a[8])!=0;e.parking=atoi(a[9])!=0;e.sl=YsBound(atof(a[10]),0.0,1.0);e.sr=YsBound(atof(a[11]),0.0,1.0);e.canopy=YsBound(atof(a[12]),0.0,1.0);e.target=YsBound(atof(a[13]),0.0,1.0);su27Events.Append(e);return YSOK;}

 if(a.GetN()>=4 && 0==a[2].Strcmp("COVERHEIGHT")){config.coverHeight=YsBound(atof(a[3]),10.0,100.0);return YSOK;}
 if(a.GetN()>=9 && 0==a[2].Strcmp("CONFIG")){config.supply=atoi(a[3])!=0;config.synchronized=atoi(a[4])!=0;config.autoAfterburner=atoi(a[5])!=0;config.burst=YsBound(atoi(a[6]),1,64);config.interval=YsBound(atof(a[7]),0.1,2.0);config.cameraSensitivity=YsBound(atof(a[8]),0.05,2.0);return YSOK;}
 if(a.GetN()>=7 && 0==a[2].Strcmp("COLOR")){int i=atoi(a[3]);if(i>=0 && i<FsMaxShowAircraft)for(int c=0;c<3;++c)config.rgb[i][c]=YsBound(atoi(a[4+c]),0,255);if(i>=0 && i<FsMaxShowAircraft){int p=FsNearestSmokePalette(config.rgb[i][0],config.rgb[i][1],config.rgb[i][2]);for(int c=0;c<3;++c)config.rgb[i][c]=FsSmokePalette[p].rgb[c];}return YSOK;}return YSERR;
}
namespace
{
bool BalanceLevelAirborneStart(FsAirplane &air)
{
 auto &p=air.Prop();
 YsVec3 velocity;p.GetVelocity(velocity);
 // Only a fresh, neutral, level airborne start. Ground starts, helicopters,
 // intentional climbs/banks and already-trimmed saved flights keep their setup.
 if(p.GetAircraftClass()==FSCL_HELICOPTER || p.IsOnGround()==YSTRUE ||
    p.GetVelocity()<20.0 || YsAbs(air.GetAttitude().p())>YsDegToRad(0.5) ||
    YsAbs(air.GetAttitude().b())>YsDegToRad(0.5) || YsAbs(velocity.y())>0.5 ||
    YsAbs(p.GetElvTrim())>0.001 || YsAbs(p.GetElevator())>0.001)return false;
 p.RefreshAirData(); // Refresh density at the actual starting altitude before balancing lift.
 const double speed=p.GetVelocity();
 const double weight=p.GetTotalWeight()*FsGravityConst;
 double low=-p.GetCriticalAOA()*0.2,high=p.GetCriticalAOA()*0.7;
 // Level lift includes the upward component of engine thrust.
 auto lift=[&](double a){return p.GetLift(a,speed)+p.GetDrag(a,speed)*tan(a);};
 if(lift(low)>weight || lift(high)<weight)return false;
 for(int i=0;i<32;++i){const double mid=(low+high)*0.5;if(lift(mid)<weight)low=mid;else high=mid;}
 const double aoa=(low+high)*0.5;
 const double trim=p.ComputeElevatorTrimForAOA(aoa);
 if(YsAbs(trim)>0.85)return false;
 const double requiredThrust=p.GetDrag(aoa,speed)/cos(aoa);
 // Use thrust at this altitude rather than the sea-level rating.
 if(p.GetThrust(1.0,air.GetPosition().y(),speed,YSFALSE)<requiredThrust)return false;
 low=0.0;high=1.0;
 for(int i=0;i<32;++i){const double mid=(low+high)*0.5;if(p.GetThrust(mid,air.GetPosition().y(),speed,YSFALSE)<requiredThrust)low=mid;else high=mid;}
 const double throttle=(low+high)*0.5;
 YsString command;
 // Preserve position and horizontal velocity; pitch supplies the 1G angle of attack.
 command.Printf("ATTITUDE %.9fdeg %.9fdeg 0deg",YsRadToDeg(air.GetAttitude().h()),YsRadToDeg(aoa));air.SendCommand(command);
 p.SetElvTrim(trim);p.SetThrottle(throttle);p.SetAfterburner(YSFALSE);
 printf("V862BALANCE id=%d speed=%.4f pitch=%.4f trim=%.6f throttle=%.6f\n",air.ysfId,speed,YsRadToDeg(aoa),trim,throttle);
 return true;
}
}
void FsSimExtension_Airshow::StartSimulation(FsSimulation *sim)
{
 replaying=false;su27Events.CleanUp();sim->SetCoverHeight(config.coverHeight);sim->GetPlayerSquad();SetupAircraft(sim,true);
 if(auto player=sim->GetPlayerAirplane())if(player->GetAutopilot()==nullptr && BalanceLevelAirborneStart(*player))sim->ReadControlBackFromAirplane(player);
 sim->AddTimedMessage(T("show/keys",L"F10: airshow | F2: orbit camera | right drag: rotate | wheel: zoom"));
}
void FsSimExtension_Airshow::StartReplay(FsSimulation *sim){replaying=true;sim->GetPlayerSquad();SetupAircraft(sim,false);ReplaySu27(sim);}
void FsSimExtension_Airshow::SetupAircraft(FsSimulation *sim,bool resupply)
{
 for(int i=0;i<FsMaxShowAircraft;++i)if(auto a=Aircraft(sim,i))
 {
  if(config.supply && resupply){a->SendCommand("MAXNMFLR 500");a->Prop().SetNumWeapon(FSWEAPON_FLARE_INTERNAL,500);a->SendCommand("LOADWEPN IFLR 500");YsString oil;oil.Printf("SMOKEOIL %.3fkg",YsGreater(100.0,a->Prop().GetSmokeOil()));a->SendCommand(oil);}
  if(a->Prop().GetNumSmokeGenerator()==0){YsString s;s.Printf("SMOKEGEN 0m 0m %.3fm",-a->GetApproximatedCollideRadius()*0.5);a->SendCommand(s);}
  YsString s;s.Printf("SMOKECOL ALL %d %d %d",config.rgb[i][0],config.rgb[i][1],config.rgb[i][2]);a->SendCommand(s);
 }

}
void FsSimExtension_Airshow::ApplyControls(FsSimulation *sim)
{
 if(replaying)return;
 for(int i=0;i<FsMaxShowAircraft;++i)if(auto a=Aircraft(sim,i))if(a->IsAlive()==YSTRUE)
 {
  if(smoke[i]){a->Prop().SetSmokeSelector(255);a->Prop().SetSmokeButton(YSTRUE);}
  // Auto reheat uses the native engine, fuel consumption and plume visibility.
  if(i==0 && FsAfterburnerVisual::RealEngineAllowsFlame(a->Prop().GetIdentifier()) && config.autoAfterburner && a->GetAutopilot()==nullptr && a->Prop().IsJet()==YSTRUE && a->Prop().GetHasAfterburner()==YSTRUE && a->Prop().GetAircraftClass()!=FSCL_HELICOPTER)
   a->Prop().SetAfterburner(a->Prop().GetThrottle()>0.98 ? YSTRUE : YSFALSE);
 }
}
void FsSimExtension_Airshow::OnInterval(FsSimulation *sim,double dt)
{
 if(replaying){ReplaySu27(sim);return;}
 if(dt<=0)return;
 sim->DiscoverSquadMembers();
 if(!Aircraft(sim,selected))selected=0;
 if(!Aircraft(sim,cameraUnit))cameraUnit=0;
 for(int i=1;i<FsMaxShowAircraft;++i)if(!Aircraft(sim,i)){remaining[i]=0;smoke[i]=false;}
 for(int n=int(breaks.GetN())-1;n>=0;--n)
 {
  auto &order=breaks[n];auto wing=sim->FindAirplane(order.key);auto leader=sim->GetPlayerAirplane();
  if(!wing || wing->IsAlive()!=YSTRUE || !leader){breaks.Delete(n);continue;}
  if(order.finish>=0.0 && sim->GetClock()>=order.finish)
  {printf("V82BREAK return time=%.3f slot=%d id=%d\n",sim->GetClock(),wing->squadSlot,wing->ysfId);FsCreateSafeFollower(*wing,*leader);breaks.Delete(n);continue;}
  if(!order.started && sim->GetClock()>=order.start)
  {
   YsAtt3 yaw;yaw.Set(order.departureHeading,0,0);YsVec3 forward;yaw.Mul(forward,YsVec3(0,0,200000));auto target=wing->GetPosition()+forward;
   target.SetY(wing->GetPosition().y()); // Terrain protection belongs to the flight controller, not a forced 300m climb.
   auto ap=FsFormation::Create();ap->leader=leader;ap->shouldBe=wing->squadOffset;ap->headingOnly=YSTRUE;ap->synchronizeTrigger=YSFALSE;ap->independentDeparture=true;
   forward.Normalize();ap->departureVelocity=forward*YsGreater(wing->Prop().GetVelocity(),wing->Prop().GetEstimatedLandingSpeed()*1.5);ap->departureAltitude=target.y();wing->SetAutopilot(ap);
   wing->squadTask=1;order.started=true;printf("V82BREAK start time=%.3f slot=%d id=%d\n",sim->GetClock(),wing->squadSlot,wing->ysfId);
  }
 }
 if(sim->GetClock()>=nextFlare)
 {
  for(int i=0;i<FsMaxShowAircraft;++i)if(remaining[i]>0)
  {
   if(auto a=Aircraft(sim,i))if(a->IsAlive()==YSTRUE){YSBOOL blocked=YSFALSE;a->Prop().FireWeapon(blocked,sim,sim->GetClock(),sim->GetWeaponStore(),a,FSWEAPON_FLARE);}
   --remaining[i];
  }
  nextFlare=sim->GetClock()+config.interval;
 }
}
void FsSimExtension_Airshow::Command(FsSimulation *sim,int action)
{
 if(replaying)return;

 if(action==1){bool on=!smoke[selected];for(int i=0;i<FsMaxShowAircraft;++i)if(config.synchronized || i==selected){smoke[i]=on;if(auto a=Aircraft(sim,i)){if(on && a->Prop().GetSmokeOil()<=0.0){smoke[i]=false;sim->AddTimedMessage(T("show/noOil",L"No smoke oil: enable show equipment before departure."));}a->Prop().SetSmokeButton(smoke[i] ? YSTRUE : YSFALSE);}}}
 if(action==2){for(int n=0;n<FsMaxShowAircraft;++n){selected=(selected+1)%FsMaxShowAircraft;if(Aircraft(sim,selected))break;}config.synchronized=false;cameraUnit=selected;}
 if(action==3)config.synchronized=!config.synchronized;
 if(action==4){for(int n=0;n<FsMaxShowAircraft;++n){cameraUnit=(cameraUnit+1)%FsMaxShowAircraft;if(Aircraft(sim,cameraUnit))break;}sim->SimProcessButtonFunction(FSBTF_OUTSIDEPLAYERVIEW,FSUSC_ENABLE);}
 if(action==5){const int values[]={4,8,16,32,64};int n=0;while(n<5 && values[n]<=config.burst)++n;config.burst=values[n%5]; }
 if(action==6)for(auto &n:remaining)n=0;
}
namespace
{
struct ShowLayout
{
 int x,y,width,height,left,right,top,row;
 ShowLayout(){int w,h;FsGetWindowSize(w,h);width=YsSmaller(1120,w-24);height=YsSmaller(650,h-24);x=(w-width)/2;y=(h-height)/2;left=x+20;right=x+width/2+10;top=y+100;row=YsSmaller(56,(height-170)/4);}
};
YsWString ShowUnitName(int i)
{
 YsWString name(T(i==0 ? "show/playerName" : "show/wingmanName",i==0 ? L"Player" : L"Wingman"));
 if(i>0){YsString number;number.Printf(" %d",i);YsWString tail;tail.SetUTF8String(number);name.Append(tail);}return name;
}
}
void FsSimExtension_Airshow::DrawMenu(const FsSimulation *sim) const
{
 const ShowLayout l;const auto ink=C(25,30,35),paper=C(225,227,230),edge=C(105,112,120);
 FsDrawRect(l.x,l.y,l.x+l.width,l.y+l.height,paper,YSTRUE);FsDrawRect(l.x,l.y,l.x+l.width,l.y+l.height,edge,YSFALSE);
 FsDrawRect(l.x,l.y,l.x+l.width,l.y+42,C(50,64,78),YSTRUE);
 FsDrawString(l.left,l.y+12,T("show/title",L"AIRSHOW - FLIGHT PAUSED"),YsWhite());
 FsDrawString(l.left,l.y+57,T("show/menuGuide",L"Click a button or press its number. Close this menu to resume the show."),ink);
 const wchar_t *names[]={T(smoke[selected] ? "show/smokeOff" : "show/smokeOn",L"Smoke on / off"),T("show/unit",L"Select aircraft"),T(config.synchronized ? "show/scopeAll" : "show/scopeOne",L"Who receives commands"),T("show/close",L"Resume flight (F10 / Esc)")};
 for(int i=0;i<4;++i)
 {
  int y=l.top+i*l.row;FsDrawRect(l.left,y,l.right-22,y+l.row-6,i==3 ? C(185,205,190) : C(248,249,250),YSTRUE);FsDrawRect(l.left,y,l.right-22,y+l.row-6,edge,YSFALSE);
  YsString num;num.Printf("%d",i+1);YsWString key;key.SetUTF8String(num);FsDrawString(l.left+10,y+10,key,ink);FsDrawString(l.left+35,y+10,names[i],ink);
 }
 YsWString recipient(T("show/recipient",L"Commands to: "));recipient.Append(config.synchronized ? YsWString(T("show/wholeSquad",L"Whole squad")) : ShowUnitName(selected));FsDrawString(l.right,l.top,recipient,ink);
 YsWString camera(T("show/cameraState",L"Camera: "));camera.Append(ShowUnitName(cameraUnit));FsDrawString(l.right,l.top+28,camera,ink);
 FsDrawString(l.right,l.top+56,T("show/flareKeys",L"Ctrl+F: player flares | Ctrl+Shift+F: all flares"),ink);
 FsDrawString(l.right,l.top+86,T("show/chooseRow",L"Click aircraft name to select, colour square to change:"),ink);
 int y=l.top+115;const int row=YsSmaller(30,(l.height-290)/FsMaxShowAircraft);
 for(int i=0;i<FsMaxShowAircraft;++i)if(auto a=Aircraft(sim,i))
 {
  if(i==selected && !config.synchronized)FsDrawRect(l.right-4,y-3,l.x+l.width-16,y+row-4,C(192,211,230),YSTRUE);
  FsDrawRect(l.right,y+1,l.right+14,y+15,C(config.rgb[i][0],config.rgb[i][1],config.rgb[i][2]),YSTRUE);FsDrawRect(l.right,y+1,l.right+14,y+15,edge,YSFALSE);
  YsWString unit=ShowUnitName(i);unit.Append(L" - ");const wchar_t *colour=T("show/custom",L"Custom");
  for(int c=0;c<FsSmokePaletteCount;++c)if(config.rgb[i][0]==FsSmokePalette[c].rgb[0] && config.rgb[i][1]==FsSmokePalette[c].rgb[1] && config.rgb[i][2]==FsSmokePalette[c].rgb[2])colour=T(FsSmokePalette[c].key,FsSmokePalette[c].name);
  unit.Append(colour);unit.Append(smoke[i] ? T("show/isSmoking",L" - smoke ON") : T("show/isNotSmoking",L" - smoke OFF"));FsDrawString(l.right+23,y,unit,ink);y+=row;
 }
 FsDrawString(l.left,l.y+l.height-60,T("show/cameraHelp",L"F2: outside view | right drag: rotate | wheel: zoom | F1: cockpit"),ink);
 FsDrawString(l.left,l.y+l.height-33,T("show/resumeHint",L"Commands run after closing the menu. Click colour squares to change smoke during flight."),ink);
 int lb,mb,rb,x,y2;FsGetMouseState(lb,mb,rb,x,y2);FsDrawCircle(x,y2,5,ink,YSFALSE);
}
void FsSimExtension_Airshow::Click(FsSimulation *sim,int x,int y)
{
 const ShowLayout l;
 if(x>=l.left && x<=l.right-22 && y>=l.top && y<l.top+4*l.row)
 {
  int i=(y-l.top)/l.row;if((y-l.top)%l.row>l.row-6)return;
  if(i==3)menuOpen=false;else Command(sim,i+1);return;
 }
 const int row=YsSmaller(30,(l.height-290)/FsMaxShowAircraft);int rowY=l.top+115;

 for(int i=0;i<FsMaxShowAircraft;++i)if(Aircraft(sim,i))
 {
  if(x>=l.right && x<=l.x+l.width-16 && y>=rowY-3 && y<rowY+row-3)
  {
   selected=i;cameraUnit=i;config.synchronized=false;
   if(x<=l.right+18)
   {
    int next=0;
    for(int n=0;n<FsSmokePaletteCount;++n)if(config.rgb[i][0]==FsSmokePalette[n].rgb[0] && config.rgb[i][1]==FsSmokePalette[n].rgb[1] && config.rgb[i][2]==FsSmokePalette[n].rgb[2])next=(n+1)%FsSmokePaletteCount;
    SetColour(sim,i,FsSmokePalette[next].rgb[0],FsSmokePalette[next].rgb[1],FsSmokePalette[next].rgb[2]);
   }
   return;
  }
  rowY+=row;
 }
}
void FsSimExtension_Airshow::CameraInput(int key,bool right,int x,int y)
{
 if(key==FSKEY_WHEELUP)distance=YsBound(distance/1.12,10.0,10000.0);
 if(key==FSKEY_WHEELDOWN)distance=YsBound(distance*1.12,10.0,10000.0);
 if(right && !dragging){restoreX=x;restoreY=y;}
 if(!right && dragging){FsSetMousePosition(restoreX,restoreY);x=restoreX;y=restoreY;}
 if(right && dragging){heading+=(x-lastX)*YsDegToRad(config.cameraSensitivity);pitch=YsBound(pitch+(y-lastY)*YsDegToRad(config.cameraSensitivity),-YsPi*0.48,YsPi*0.48);}
 dragging=right;lastX=x;lastY=y;
}
void FsSimExtension_Airshow::Report(const FsSimulation *sim) const
{
 printf("V8SHOW selected=%d sync=%d burst=%d camera=%d heading=%.3f pitch=%.3f distance=%.3f\n",selected,config.synchronized,config.burst,cameraUnit,heading,pitch,distance);
 for(int i=0;i<FsMaxShowAircraft;++i)if(auto a=Aircraft(sim,i))printf("V8SHOWUNIT slot=%d flare=%d smoke=%d ab=%d throttle=%.3f\n",i,a->Prop().GetNumWeapon(FSWEAPON_FLARE),int(a->Prop().IsTrailingSmoke(0)),int(a->Prop().GetAfterBurner()),a->Prop().GetThrottle());
 for(int i=0;i<FsMaxShowAircraft;++i)if(auto a=Aircraft(sim,i))printf("V82COLOR id=%d slot=%d r=%d g=%d b=%d remaining=%d\n",a->ysfId,i,config.rgb[i][0],config.rgb[i][1],config.rgb[i][2],remaining[i]);
}

void FsSimExtension_Airshow::ReleaseFlares(FsSimulation *sim,bool all)
{
 if(replaying || !sim->GetPlayerAirplane() || sim->GetPlayerAirplane()->isPlayingRecord==YSTRUE)return;
 bool any=false;
 for(int i=0;i<FsMaxShowAircraft;++i)if(all || i==0)if(auto a=Aircraft(sim,i))
 {
  if(a->Prop().GetNumWeapon(FSWEAPON_FLARE)>0){remaining[i]=config.burst;any=true;}
 }
 if(any)nextFlare=sim->GetClock();else sim->AddTimedMessage(T("show/noFlares",L"No flares: enable show equipment before departure."));
}
void FsSimExtension_Airshow::SetColour(FsSimulation *sim,int i,int r,int g,int b)
{
 if(i<0 || i>=FsMaxShowAircraft || replaying)return;
 int colour=FsNearestSmokePalette(r,g,b);r=FsSmokePalette[colour].rgb[0];g=FsSmokePalette[colour].rgb[1];b=FsSmokePalette[colour].rgb[2];
 config.rgb[i][0]=r;config.rgb[i][1]=g;config.rgb[i][2]=b;
 if(auto a=Aircraft(sim,i)){YsString s;s.Printf("SMOKECOL ALL %d %d %d",r,g,b);a->SendCommand(s);}
}
void FsSimExtension_Airshow::MoveUnit(int from,int to)
{
 if(from<1 || from>=FsMaxShowAircraft || to<1 || to>=FsMaxShowAircraft)return;
 smoke[to]=smoke[from];remaining[to]=remaining[from];for(int c=0;c<3;++c)config.rgb[to][c]=config.rgb[from][c];
 if(selected==from)selected=to;if(cameraUnit==from)cameraUnit=to;
}
void FsSimExtension_Airshow::CancelBreak(unsigned int key)
{for(int n=int(breaks.GetN())-1;n>=0;--n)if(breaks[n].key==key)breaks.Delete(n);}
void FsSimExtension_Airshow::StartBreak(FsSimulation *sim,const YsArray<FsAirplane *,8> &members)
{
 auto leader=sim->GetPlayerAirplane();if(!leader)return;
 bool column=true;for(auto wing:members)if(YsAbs(wing->squadOffset.x())>1.0)column=false;
 YsAtt3 yaw=leader->GetAttitude();yaw.SetP(0.0);yaw.SetB(0.0);
 // Use actual positions: a break can be ordered before reassembly has finished.
 YsArray<YsVec3,8> local;double width=1.0;
 for(auto wing:members){YsVec3 p;yaw.MulInverse(p,wing->GetPosition()-leader->GetPosition());local.Append(p);width=YsGreater(width,YsAbs(p.x()));}
 for(int i=0;i<members.GetN();++i)
 {
  auto wing=members[i];CancelBreak(FsExistence::GetSearchKey(wing));
  BreakOrder o;o.key=FsExistence::GetSearchKey(wing);o.start=sim->GetClock()+(column ? i*0.8 : 0.0);o.finish=-1.0;
  const double x=local[i].x();
  const double side=column ? (i%2==0 ? -1.0:1.0) : (x < -1.0 ? -1.0 : x > 1.0 ? 1.0 : (i%2==0 ? -1.0:1.0));
  const double angle=column ? 45.0 : 25.0+35.0*YsBound(YsAbs(x)/width,0.0,1.0);
  // YsAtt3 positive heading rotates +Z towards -X: subtract the outward side.
  o.departureHeading=yaw.h()-side*YsDegToRad(angle);
  printf("V86PLAN slot=%d x=%.3f outward=%d heading=%.3f column=%d\n",wing->squadSlot,x,int(side),YsRadToDeg(o.departureHeading),int(column));
  // Everyone is committed to the break now. Waiting aircraft hold their
  // present flight line instead of filling places vacated by earlier members.
  auto hold=FsFormation::Create();hold->leader=leader;hold->shouldBe=wing->squadOffset;
  hold->headingOnly=YSTRUE;hold->synchronizeTrigger=YSFALSE;hold->independentDeparture=true;
  wing->Prop().GetVelocity(hold->departureVelocity);hold->departureVelocity.SetY(0.0);
  hold->departureAltitude=wing->GetPosition().y();wing->SetAutopilot(hold);wing->squadTask=1;
  breaks.Append(o);
 }
}
void FsSimExtension_Airshow::ReturnBreak(FsSimulation *sim,const YsArray<FsAirplane *,8> &members)
{
 bool column=true;for(auto wing:members)if(YsAbs(wing->squadOffset.x())>1.0)column=false;
 int index=0;
 for(auto wing:members)
 {
  bool queued=false;
  for(auto &order:breaks)if(order.key==FsExistence::GetSearchKey(wing)){order.finish=sim->GetClock();queued=true;break;}
  if(!queued)FsCreateSafeFollower(*wing,*sim->GetPlayerAirplane());
  ++index;
 }
}

void FsSimExtension_Airshow::RecordSu27(const FsSimulation *sim,const FsAirplane &air)
{
 const auto &p=air.Prop();Su27Event e;e.time=sim->GetClock();e.key=FsExistence::GetSearchKey(&air);e.id=air.ysfId;
 e.battery=p.su27Battery;e.pumps=p.su27Pumps;e.left=p.su27Left;e.right=p.su27Right;e.parking=p.su27Parking;
 e.sl=p.su27SpoolLeft;e.sr=p.su27SpoolRight;e.canopy=p.su27Canopy;e.target=p.su27CanopyTarget;su27Events.Append(e);
}
void FsSimExtension_Airshow::ReplaySu27(FsSimulation *sim)
{
 const double now=sim->GetClock();
 for(auto air=sim->FindNextAirplane(nullptr);air;air=sim->FindNextAirplane(air))if(0==strcmp(air->Prop().GetIdentifier(),"SU-27_FLANKER")){
  const Su27Event *event=nullptr;
  for(const auto &e:su27Events)if(e.id==air->ysfId && e.time<=now+.00001 && (!event || e.time>=event->time))event=&e;
  if(!event)for(const auto &e:su27Events)if(e.id==air->ysfId && (!event || e.time<event->time))event=&e;
  if(!event)continue;const auto &e=*event;auto &p=air->Prop();const double elapsed=YsGreater(0.0,now-e.time);
  auto slew=[&](double v,double target,double rate){return v<target?YsSmaller(target,v+elapsed*rate):YsGreater(target,v-elapsed*rate);};
  p.su27Managed=true;p.su27Battery=e.battery;p.su27Pumps=e.pumps;p.su27Left=e.left;p.su27Right=e.right;p.su27Parking=e.parking;
  p.su27SpoolLeft=slew(e.sl,e.left?1.0:0.0,e.left?.125:.35);p.su27SpoolRight=slew(e.sr,e.right?1.0:0.0,e.right?.125:.35);
  p.su27CanopyTarget=e.target;p.su27Canopy=slew(e.canopy,e.target,.4);p.su27ThrustFactor=(p.su27SpoolLeft*p.su27SpoolLeft+p.su27SpoolRight*p.su27SpoolRight)*.5;
 }
}
