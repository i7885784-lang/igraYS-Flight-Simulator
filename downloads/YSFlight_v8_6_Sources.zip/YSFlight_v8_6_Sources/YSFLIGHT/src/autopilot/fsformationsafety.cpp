#include "fs.h"
#include "fsformationautopilot.h"

YSRESULT FsFormation::SafeFormationControl(FsAirplane &air,FsSimulation *sim,double dt)
{
 auto &p=air.Prop();YsVec3 velocity,leadVelocity;p.GetVelocity(velocity);if(independentDeparture)leadVelocity=departureVelocity;else leader->Prop().GetVelocity(leadVelocity);
 const double margin=YsGreater(18.0,air.GetApproximatedCollideRadius()*0.8);
 safeTerrain=sim->GetFieldElevation(air.GetPosition().x(),air.GetPosition().z());
 for(int i=1;i<=8;++i){auto sample=air.GetPosition()+velocity*(i*0.5);safeTerrain=YsGreater(safeTerrain,sim->GetFieldElevation(sample.x(),sample.z()));}
 goal.SetY(YsGreater(goal.y(),sim->GetFieldElevation(goal.x(),goal.z())+margin));
 // Follow current leader motion immediately; never wait for another wingman.
 safeGoal=goal;safeGoalValid=true;
 const double heading=independentDeparture ? air.GetAttitude().h() : leader->GetAttitude().h();
 if(!independentDeparture && headingTracked && dt>YsTolerance)
 {
  const double rate=atan2(sin(heading-lastLeaderHeading),cos(heading-lastLeaderHeading))/dt;
  formationTurnRate+=(YsBound(rate,-0.35,0.35)-formationTurnRate)*dt/(0.15+dt);
  auto accel=(leadVelocity-previousLeaderVelocity)/dt;
  if(accel.GetLength()>40.0){accel.Normalize();accel*=40.0;}
  leaderAcceleration+=(accel-leaderAcceleration)*dt/(0.25+dt);
 }
 previousLeaderVelocity=leadVelocity;lastLeaderHeading=heading;headingTracked=true;
 auto slot=independentDeparture ? YsOrigin() : safeGoal-leader->GetPosition();
 YsVec3 slotVelocity=leadVelocity+YsVec3(-slot.z()*formationTurnRate,0.0,slot.x()*formationTurnRate);
 auto error=safeGoal-air.GetPosition();auto horizontalError=error;horizontalError.SetY(0.0);
 const double velocityError=(slotVelocity-velocity).GetLength();
 if(horizontalError.GetLength()>25.0 || YsAbs(error.y())>8.0 || velocityError>8.0){rejoining=true;joinStableSeconds=0.0;}
 if(horizontalError.GetLength()<8.0 && YsAbs(error.y())<3.0 && velocityError<4.0)
 {joinStableSeconds+=dt;if(joinStableSeconds>0.8)rejoining=false;}else joinStableSeconds=0.0;
 // Hybrid: feed forward the manoeuvre now, use stronger interception while displaced.
 // Normal tracking and recapture share one continuous flight controller.
 const double response=(rejoining ? 2.2:1.8);
 auto steeringError=independentDeparture ? YsOrigin() : horizontalError;
 if(!independentDeparture && rejoining && YsAbs(shouldBe.x())<1.0)
 {
  YsAtt3 leadYaw=leader->GetAttitude();leadYaw.SetP(0.0);leadYaw.SetB(0.0);YsVec3 localError;leadYaw.MulInverse(localError,horizontalError);
  const double lane=40.0*YsBound((YsAbs(localError.z())-15.0)/100.0,0.0,1.0)*YsBound((YsAbs(localError.x())-10.0)/20.0,0.0,1.0);
  YsVec3 offset(localError.x()>0.0 ? -lane:lane,0.0,0.0);leadYaw.Mul(offset,offset);steeringError+=offset;
 }
 // Increase damping smoothly near the slot to settle without crossing it again.
 const double settling=YsBound((0.015-YsAbs(formationTurnRate))/0.010,0.0,1.0);
 const double velocityDamping=1.2+0.8*settling*YsBound((60.0-horizontalError.GetLength())/60.0,0.0,1.0);
 YsVec3 correction=steeringError/response+(slotVelocity-velocity)*velocityDamping;correction.SetY(0.0);
 const double correctionLimit=YsBound(leadVelocity.GetLength()*0.7,40.0,150.0);
 if(correction.GetLength()>correctionLimit){correction.Normalize();correction*=correctionLimit;}
 auto wantedVelocity=independentDeparture ? departureVelocity : slotVelocity+correction;wantedVelocity.SetY(0.0);
 double configuredSeparation=shouldBe.GetLength();
 double avoidanceTarget=0.0,closestTime=7.0;YsVec3 avoidVelocity=YsOrigin();collisionRisk=false;
 for(auto other=sim->FindNextAirplane(nullptr);other;other=sim->FindNextAirplane(other))if(other!=&air && other->IsAlive()==YSTRUE)
 {
  if(!independentDeparture && other!=leader && air.squadSlot>=0 && other->squadSlot>=0 && air.squadLeaderKey==other->squadLeaderKey)
   configuredSeparation=YsSmaller(configuredSeparation,(air.squadOffset-other->squadOffset).GetLength());
  auto relative=other->GetPosition()-air.GetPosition();const double distance=relative.GetLength();
  if(distance>1200.0)continue;
  YsVec3 ov;other->Prop().GetVelocity(ov);const auto rv=ov-velocity;
  const double t=YsBound(-(relative*rv)/YsGreater(1.0,rv.GetSquareLength()),0.0,6.0);
  const double closing=YsGreater(0.0,-(relative*rv)/YsGreater(1.0,distance));
  // One physical clearance for both tracking and avoidance. Parallel aircraft
  // 50m apart must not be permanently pushed into slot-indexed altitude steps.
  const double physical=YsGreater(6.0,(air.GetApproximatedCollideRadius()+other->GetApproximatedCollideRadius())*1.2+3.0);
  // Add manoeuvring room only while converging. Parallel tight formations
  // keep their original physical clearance, without a permanent altitude step.
  const double separation=physical+YsSmaller(45.0,closing*0.35+(closing>1.0 ? 5.0:0.0));
  const double predicted=(relative+rv*t).GetLength();
  if(predicted<separation && ((t>0.05 && closing>0.5) || distance<physical))
  {
   if(t<closestTime)
   {
    collisionRisk=true;closestTime=t;
    const double sign=(FsExistence::GetSearchKey(&air)<FsExistence::GetSearchKey(other) ? -1.0:1.0);
    auto away=-relative;away.SetY(0.0);
    if(away.GetLength()<1.0)away.Set(sign,0.0,0.0);
    away.Normalize();avoidVelocity=away*YsBound((separation-predicted)*1.2,12.0,55.0);
    // Short-lived vertical separation only for an imminent crossing; never
    // a permanent altitude assigned by wingman number.
    if(t<4.0)avoidanceTarget=sign*YsBound(separation*0.85,18.0,32.0);
   }
  }
 }
 // Safety wins over the desire to occupy the requested slot. Otherwise a
 // large interception correction can overpower the avoidance vector.
 if(collisionRisk && !independentDeparture)wantedVelocity=slotVelocity+correction*0.35;
 avoidanceHeight+=(avoidanceTarget-avoidanceHeight)*dt/(0.25+dt);
 // Closely spaced aircraft must brake with the leader, before positional error
 // develops. This affects only requested target gaps below 45m, not normal 50m formations.
 auto leadDirection=leadVelocity;leadDirection.SetY(0.0);
 if(!independentDeparture && leadDirection.Normalize()==YSOK)
  wantedVelocity+=leadDirection*(leaderAcceleration*leadDirection)*(2.5*YsBound((45.0-configuredSeparation)/5.0,0.0,1.0));
 wantedVelocity+=avoidVelocity;
 const double clearance=air.GetPosition().y()-safeTerrain;
 const double down=YsGreater(0.0,-velocity.y()),bank=air.GetAttitude().b();
 const double gLimit=YsBound(GetDefaultGLimit(air),2.0,6.0);
 const double rollTime=YsAbs(bank)/YsDegToRad(90.0);
 const double reserve=margin+down*(1.5+rollTime)+down*down/(2.0*YsGreater(3.0,(gLimit-1.0)*FsGravityConst*0.5));
 if((clearance<reserve && (down>1.0 || clearance<margin)) || cos(bank)<-0.15)recovering=true;
 if(recovering && velocity.y()>-1.0 && clearance>reserve+10.0 && YsAbs(bank)<YsDegToRad(25.0))recovering=false;
 p.NeutralDirectAttitudeControl();p.SetBrake(0.0);
 const double weight=p.GetTotalWeight()*FsGravityConst;
 const double liftAt100=YsGreater(1.0,p.GetLift(p.GetCriticalAOA()*0.7,100.0));
 const double levelSpeed=YsGreater(25.0,100.0*sqrt(weight*1.15/liftAt100));
 const double availableG=p.GetLift(p.GetCriticalAOA()*0.8,p.GetVelocity())/YsGreater(1.0,weight);
 const double minSpeed=levelSpeed/sqrt(YsGreater(0.4,cos(bank)));
 if(recovering)
 {
  p.BankController(0.0,YsDegToRad(100.0));p.SetSpoiler(0.0);
  p.GController(cos(bank)>0.3 ? YsBound(1.6+down*0.18,1.6,gLimit) : cos(bank)<-0.3 ? -0.5 : 0.0);
  commandedSpeed=YsGreater(minSpeed,leadVelocity.GetLength());commandedClimb=0.0;
  p.SpeedController(commandedSpeed);mode=FSFOMMODE_RECOVER_FROM_LOWALT;
 }
 else
 {
  YsAtt3 yaw=air.GetAttitude();yaw.SetP(0.0);yaw.SetB(0.0);YsVec3 local;yaw.MulInverse(local,wantedVelocity);
  const double bearing=atan2(-local.x(),local.z());
  double bankLimit=YsSmaller(acos(1.0/(gLimit-0.3)),YsDegToRad(clearance<120.0 ? 35.0 : clearance<200.0 ? 55.0 : 75.0));
  if(gLimit<3.1)bankLimit=YsSmaller(bankLimit,YsDegToRad(35.0));
  bankLimit=YsSmaller(bankLimit,acos(1.0/YsGreater(1.01,availableG*0.85)));
  if(p.GetVelocity()<minSpeed*1.05)bankLimit=YsSmaller(bankLimit,YsDegToRad(20.0));
  const double feedforward=atan2(wantedVelocity.GetLength()*formationTurnRate,FsGravityConst);
  if(YsAbs(formationTurnRate)<0.015 && horizontalError.GetLength()<120.0)
   bankLimit=YsSmaller(bankLimit,YsDegToRad(25.0+horizontalError.GetLength()*0.25));
  p.BankController(YsBound(bearing*2.4+feedforward,-bankLimit,bankLimit),YsDegToRad(90.0));
  const double targetHeight=YsGreater(safeGoal.y()+avoidanceHeight,safeTerrain+margin);
  const double descent=YsBound((clearance-margin)/4.0,2.0,50.0);
  commandedClimb=YsBound(leadVelocity.y()+(targetHeight-air.GetPosition().y())/2.0+leaderAcceleration.y()*0.3,-descent,45.0);
  const double requestedG=(1.0+(commandedClimb-velocity.y())*0.20+YsBound(leaderAcceleration.y()/FsGravityConst,-0.4,0.8)*0.4)/YsGreater(0.25,cos(bank));
  const double minimumG=(clearance>200.0 ? 0.15:0.6);
  p.GController(YsBound(requestedG,minimumG,YsGreater(minimumG,YsSmaller(gLimit,availableG*0.9))));
  // Acceleration is available during capture, not disabled at 45 degrees.
  // Slow only when the desired track is actually behind the aircraft.
  const double desiredSpeed=(YsAbs(bearing)>YsDegToRad(100.0) ? YsSmaller(leadVelocity.GetLength(),wantedVelocity.GetLength()) : wantedVelocity.GetLength());
  commandedSpeed=YsGreater(minSpeed,desiredSpeed);p.SpeedController(commandedSpeed);
  mode=(!rejoining && error.GetLength()<10.0 ? FSFOMMODE_INPOSITION:FSFOMMODE_LOSTPOSITION);
 }
 p.SetGControllerAOALimit(-p.GetCriticalAOA()*0.4,p.GetCriticalAOA()*(recovering ? 0.95:0.8));
 if(!independentDeparture){p.SetGear(leader->Prop().GetLandingGear());p.SetFlap(leader->Prop().GetFlap());}p.SetRudder(0.0);p.SmartRudder(dt);
 return YSOK;
}
