#include <ysclass.h>
#define FSSIMPLEWINDOW_DONT_INCLUDE_OPENGL_HEADERS
#include <fssimplewindow.h>
#include "fs.h"
#include "fsoperation.h"
#include "fsairshow.h"
#include "fsformationautopilot.h"
#include "fsdogfightautopilot.h"
#include "fsgrouplayout.h"
#include "fstextresource.h"
#include "graphics/common/fsopengl.h"
#include "graphics/common/fsfontrenderer.h"
namespace
{
const wchar_t *T(const char *key,const wchar_t *fallback){return FsGetTextResource(key,fallback);}
void Form(FsAirplane &wing,FsAirplane &leader)
{
    FsCreateSafeFollower(wing,leader);
    wing.squadAttackTargetKey=YSNULLHASHKEY;
}
YsColor SquadColor(int r,int g,int b){YsColor c;c.SetIntRGB(r,g,b);return c;}
void CenterText(int x,int y,const wchar_t *str,const YsColor &color)
{
    YsWString text(str);auto lines=text.Argv(L"\n");
    int lineY=y-int(lines.GetN()-1)*10;
    for(auto &line:lines){int w,h;fsUnicodeRenderer.GetTightRenderSize(w,h,line);FsDrawString(x-w/2,lineY-h/2,line,color);lineY+=20;}
}
int WheelItem(int x,int y,int w,int h,int count)
{
    const double dx=x-w/2,dy=y-h/2,r=sqrt(dx*dx+dy*dy),outer=YsSmaller(260.0,h*0.34);
    if(r<outer*0.29)return -2;
    if(r>outer+8)return -1;
    double angle=atan2(dx,-dy)+YsPi/double(count);if(angle<0)angle+=2*YsPi;
    return int(angle/(2*YsPi)*count)%count;
}
}
void FsSimulation::AddTimedMessage(const wchar_t str[])
{
    YsString utf8;utf8.EncodeUTF8(str);AddTimedMessage(utf8);
}
void FsSimulation::DiscoverSquadMembers()
{
    auto player=GetPlayerAirplane();if(nullptr==player || YSTRUE==player->isPlayingRecord)return;
    if(player->Prop().IsActive()!=YSTRUE)
    {
        const auto key=FsExistence::GetSearchKey(player);
        for(auto wing=FindNextAirplane(nullptr);wing;wing=FindNextAirplane(wing))
        if(wing!=player && wing->squadLeaderKey==key && wing->Prop().IsActive()==YSTRUE)
        {
            if(auto show=FsGetAirshow(this))show->CancelBreak(FsExistence::GetSearchKey(wing));
            YsAtt3 yaw=wing->GetAttitude();yaw.SetP(0);yaw.SetB(0);YsVec3 forward;yaw.Mul(forward,YsVec3(0,0,200000));
            auto target=wing->GetPosition()+forward;target.SetY(YsGreater(wing->GetPosition().y(),GetFieldElevation(wing->GetPosition().x(),wing->GetPosition().z())+300.0));
            auto ap=FsGotoPosition::Create();ap->SetSingleDestination(target);ap->SetSpeed(YsGreater(wing->Prop().GetVelocity(),wing->Prop().GetEstimatedLandingSpeed()*1.5));ap->SetUseAfterburner(YSFALSE);wing->SetAutopilot(ap);
            wing->squadTask=2;wing->squadSlot=-1;wing->squadLeaderKey=YSNULLHASHKEY;
            printf("V85DEPART id=%d after_leader_loss=1\n",wing->ysfId);
        }
        return;
    }
    int nextSlot=0;
    for(auto air=FindNextAirplane(nullptr);nullptr!=air;air=FindNextAirplane(air))
        if(air->squadSlot>=0)nextSlot=YsGreater(nextSlot,air->squadSlot+1);
    for(auto air=FindNextAirplane(nullptr);nullptr!=air;air=FindNextAirplane(air))
    {
        if(air->pendingSquadLeaderId>=0)
        {
            if(auto leader=FindAirplaneByYsfId(air->pendingSquadLeaderId))
            {air->squadLeaderKey=FsExistence::GetSearchKey(leader);air->pendingSquadLeaderId=-1;}
        }
        auto fm=dynamic_cast<FsFormation *>(air->GetAutopilot());
        if(nullptr!=fm && air!=player && air->iff==player->iff && air->Prop().IsActive()==YSTRUE)
        {
            if(nullptr==fm->leader && fm->pendingLeaderId>=0)fm->leader=GetAirplaneById(fm->pendingLeaderId);
            if(fm->leader==player)
            {
                if(air->squadSlot<0)
                {
                    air->squadLeaderKey=FsExistence::GetSearchKey(player);air->squadSlot=nextSlot++;
                    air->squadOffset=fm->shouldBe;
                    const double s=YsGreater(YsAbs(fm->shouldBe.x()),YsAbs(fm->shouldBe.z()));
                    if(s>1.0 && air->squadSlot==0)squadSpacing=YsBound(s,10.0,5000.0);
                }
                fm->headingOnly=YSTRUE;
            }
        }
        if(air->squadTask==4 && air->squadLeaderKey==FsExistence::GetSearchKey(player))
        {
            auto target=FindAirplane(air->squadAttackTargetKey);
            if(nullptr==target || YSTRUE!=target->IsAlive())Form(*air,*player);
        }
    }
    YsArray<FsAirplane *,8> all;
    const auto playerKey=FsExistence::GetSearchKey(player);
    for(auto air=FindNextAirplane(nullptr);air;air=FindNextAirplane(air))if(air!=player && air->squadSlot>=0 && air->squadLeaderKey==playerKey && air->netType==FSNET_LOCAL)all.Append(air);
    for(int i=0;i<all.GetN();++i)for(int j=i+1;j<all.GetN();++j)if(all[j]->squadSlot<all[i]->squadSlot){auto a=all[i];all[i]=all[j];all[j]=a;}
    YsArray<YsVec3,8> positions;for(auto a:all)positions.Append(a->squadOffset);
    int slot=0;
    for(auto air:all)
    {
        if(air->Prop().IsActive()!=YSTRUE){air->squadSlot=-1;air->squadLeaderKey=YSNULLHASHKEY;continue;}
        if(air->squadSlot!=slot)
        {
            const int old=air->squadSlot;
            if(auto show=FsGetAirshow(this))show->MoveUnit(old+1,slot+1);
            if(auto op=FsGetOperation(this))
            {
                // Remove dead occupant before reusing its slot, preserve live unit identity.
                for(int i=int(op->units.GetN())-1;i>=0;--i)if(op->units[i].slot==slot && old!=slot)op->units.Delete(i);
                if(auto unit=op->Unit(old))unit->slot=slot;
                if(op->scopeSlot==old)op->scopeSlot=slot;
            }
            air->squadSlot=slot;
            if(slot<positions.GetN())air->squadOffset=positions[slot];
            if(air->squadTask==0)if(auto fm=dynamic_cast<FsFormation *>(air->GetAutopilot()))fm->shouldBe=air->squadOffset;
        }
        ++slot;
    }
}
YsArray<FsAirplane *,8> FsSimulation::GetPlayerSquad()
{
    DiscoverSquadMembers();YsArray<FsAirplane *,8> result;auto player=GetPlayerAirplane();
    if(nullptr==player)return result;
    const auto key=FsExistence::GetSearchKey(player);
    for(auto air=FindNextAirplane(nullptr);nullptr!=air;air=FindNextAirplane(air))
        if(air!=player && air->squadSlot>=0 && air->squadLeaderKey==key && air->iff==player->iff &&
           YSTRUE==air->Prop().IsActive() && air->netType==FSNET_LOCAL)result.Append(air);
    for(int i=0;i<result.GetN();++i)for(int j=i+1;j<result.GetN();++j)if(result[j]->squadSlot<result[i]->squadSlot){auto a=result[i];result[i]=result[j];result[j]=a;}
    return result;
}
bool FsSimulation::IssueSquadCommand(int command)
{
    auto leader=GetPlayerAirplane();if(nullptr==leader || YSTRUE==leader->isPlayingRecord)return false;
    auto members=GetPlayerSquad();
    if(auto op=FsGetOperation(this))
    {
        for(int i=int(members.GetN())-1;i>=0;--i)if(!op->InScope(members[i]->squadSlot))members.Delete(i);
        for(auto wing:members)if(auto unit=op->Unit(wing->squadSlot)){const bool formation=(command==1 || command==8 || command==3 || command==4 || (command>=100 && FsGroupPatternAvailable(command-100)));unit->task=(formation ? 0 : 9);unit->pending=formation;unit->landRequested=false;}
    }
    if(0==members.GetN()){AddTimedMessage(T("v7/noWingmen",L"No available wingmen."));return false;}
    if(command==5)
    {
        bool covering=true;for(auto wing:members)if(wing->squadTask!=3)covering=false;
        if(covering)command=8;
    }
    if(auto show=FsGetAirshow(this))
    {
        if(command==2){show->StartBreak(this,members);AddTimedMessage(T("v7/scatterDone",L"Break, then return to formation."));return true;}
        if(command==1 || command==8){show->ReturnBreak(this,members);for(auto wing:members)wing->squadAttackTargetKey=YSNULLHASHKEY;AddTimedMessage(T("v7/regroupDone",L"Wingmen: returning to formation."));return true;}
        for(auto wing:members)show->CancelBreak(FsExistence::GetSearchKey(wing));
    }
    double radius=YsGreater(leader->GetRadiusFromCollision(),leader->GetApproximatedCollideRadius());
    for(auto wing:members)radius=YsGreater(radius,YsGreater(wing->GetRadiusFromCollision(),wing->GetApproximatedCollideRadius()));
    const double minSpacing=YsGreater(10.0,radius*2.4+8.0);
    std::vector<FsGroupOffset> existing(members.GetN());
    for(int i=0;i<members.GetN();++i){auto p=members[i]->squadOffset;existing[i]={p.x(),p.z(),p.y()};}
    squadSpacing=FsInferGroupSpacing(int(members.GetN()),existing.data(),squadSpacing);
    squadSpacing=YsBound(squadSpacing,minSpacing,5000.0);
    if(command==0)return false; // Opens the formation submenu in the UI.
    if(command>=100 && FsGroupPatternAvailable(command-100))
    {
        std::vector<FsGroupOffset> current(members.GetN()),target(members.GetN());std::vector<int> assignment(members.GetN());
        YsAtt3 yaw=leader->GetAttitude();yaw.SetP(0);yaw.SetB(0);
        for(int i=0;i<members.GetN();++i)
        {YsVec3 local;yaw.MulInverse(local,members[i]->GetPosition()-leader->GetPosition());current[i]={local.x(),local.z(),local.y()};target[i]=FsGetGroupOffset(command-100,i,squadSpacing);}
        FsAssignGroupSlots(int(members.GetN()),current.data(),target.data(),assignment.data());
        for(int i=0;i<members.GetN();++i)
        {
            auto wing=members[i];const auto p=target[assignment[i]];
            wing->squadOffset.Set(p.x,p.y,p.z);Form(*wing,*leader);
        }
        AddTimedMessage(T("v7/changing",L"Wingmen: changing formation."));return true;
    }
    if(command==3 || command==4)
    {
        const double requested=(command==3 ? squadSpacing/1.4 : squadSpacing*1.4);
        const double next=YsBound(requested,minSpacing,5000.0);
        double factor=next/squadSpacing,nearest=1.0e12;
        for(int i=0;i<members.GetN();++i)
        {
            nearest=YsSmaller(nearest,members[i]->squadOffset.GetLength());
            for(int j=0;j<i;++j)nearest=YsSmaller(nearest,(members[i]->squadOffset-members[j]->squadOffset).GetLength());
        }
        if(nearest>1.0)factor=YsGreater(factor,minSpacing/nearest);
        squadSpacing*=factor;
        for(auto wing:members){wing->squadOffset*=factor;Form(*wing,*leader);}
        AddTimedMessage(T(command==3 ? "v7/closerDone" : "v7/fartherDone",L"Wingmen: changing spacing."));return true;
    }
    if(command==1 || command==8)
    {
        for(auto wing:members)Form(*wing,*leader);
        AddTimedMessage(T("v7/regroupDone",L"Wingmen: returning to formation."));return true;
    }
    if(command==5 || command==6)
    {
        auto target=FindAirplane(leader->Prop().GetAirTargetKey());
        if(nullptr==target)target=FindAirplane(playerLockCandidate);
        if(command==6 && (nullptr==target || target->iff==leader->iff || YSTRUE!=target->IsAlive()))
        {AddTimedMessage(T("v7/noTarget",L"Aim at an enemy aircraft first."));return false;}
        int armed=0;
        for(auto wing:members)
        {
            const auto &p=wing->Prop();
            if(p.GetNumWeapon(FSWEAPON_AIM9)+p.GetNumWeapon(FSWEAPON_AIM9X)+p.GetNumWeapon(FSWEAPON_AIM120)+p.GetNumWeapon(FSWEAPON_GUN)<=0)continue;
            if(command==5){RadioCommSendCoverMe(wing,leader);wing->squadTask=3;}
            else
            {
                auto ap=FsDogfight::Create();ap->SetTargetFlyingAircraftOnly(YSTRUE);ap->SetTarget(target);wing->SetAutopilot(ap);
                wing->squadTask=4;wing->squadAttackTargetKey=FsExistence::GetSearchKey(target);
            }
            ++armed;
        }
        AddTimedMessage(armed>0 ? T(command==5 ? "v7/coverDone" : "v7/attackDone",L"Wingmen: order received.") : T("v7/noWeapons",L"Wingmen have no air-combat weapons."));return armed>0;
    }
    if(command==2 || command==7)
    {
        for(int i=0;i<members.GetN();++i)
        {
            auto wing=members[i];auto ap=FsGotoPosition::Create();
            const bool heli=(wing->Prop().GetAircraftClass()==FSCL_HELICOPTER);
            const double speed=heli ? 0.0 : YsGreater(wing->Prop().GetEstimatedLandingSpeed()*1.5,wing->Prop().GetVelocity());
            ap->SetSpeed(speed);ap->SetUseAfterburner(YSFALSE);
            const double angle=2.0*YsPi*double(i)/double(members.GetN());
            YsVec3 center;
            if(command==2)center=wing->GetPosition()+YsVec3(sin(angle)*3500.0,0.0,cos(angle)*3500.0);
            else center=leader->GetPosition()+YsVec3(sin(angle)*1500.0,0.0,cos(angle)*1500.0);
            const double altitude=YsGreater(wing->GetPosition().y()+30.0*i,GetFieldElevation(center.x(),center.z())+200.0);
            for(int corner=0;corner<4;++corner)
            {
                const double a=angle+2.0*YsPi*corner/4.0;
                YsVec3 point=center+YsVec3(sin(a)*600.0,0.0,cos(a)*600.0);
                point.SetY(YsGreater(altitude,GetFieldElevation(point.x(),point.z())+150.0));ap->destination.Append(point);
            }
            ap->destinationIdx=0;wing->SetAutopilot(ap);wing->squadTask=(command==2 ? 1 : 2);
        }
        AddTimedMessage(T(command==2 ? "v7/scatterDone" : "v7/holdDone",L"Wingmen: order received."));return true;
    }
    return false;
}
void FsSimulation::ToggleOperationMap()
{
    auto op=FsGetOperation(this);if(!op)return;
    if(squadWheelOpen){op->mapOpen=false;CloseSquadWheel();}
    else{ToggleSquadWheel();op->mapOpen=true;}
}
void FsSimulation::ToggleSquadWheel()
{
    if(squadWheelOpen){CloseSquadWheel();return;}
    auto player=GetPlayerAirplane();if(nullptr==player || YSTRUE==player->isPlayingRecord)return;
    if(nullptr!=netServer || nullptr!=netClient){SetUpRadioCommTargetDialog();return;}
    DiscoverSquadMembers();if(auto op=FsGetOperation(this)){op->wheelPage=0;op->mapOpen=false;}squadWasPaused=pause;pause=YSTRUE;squadWheelOpen=true;squadWheelFormations=false;squadFormationPage=0;
    int lb,mb,rb;FsGetMouseState(lb,mb,rb,squadMouseX,squadMouseY);
    int w,h;FsGetWindowSize(w,h);FsSetMousePosition(w/2,h/2);
    player->Prop().SetAllVirtualButton(YSFALSE);
}
void FsSimulation::CloseSquadWheel()
{
    squadWheelOpen=false;squadInputRelease=true;pause=squadWasPaused;
    FsSetMousePosition(squadMouseX,squadMouseY);
}
bool FsSimulation::ProcessSquadWheelInput()
{
    if(!squadWheelOpen && !squadInputRelease)return false;
    int lb,mb,rb,mx,my,event;
    int key;
    if(auto player=GetPlayerAirplane())player->Prop().SetAllVirtualButton(YSFALSE);
    if(squadInputRelease)
    {
        FsGetMouseState(lb,mb,rb,mx,my);
        while(FSMOUSEEVENT_NONE!=FsGetMouseEvent(lb,mb,rb,mx,my)){}
        while(FSKEY_NULL!=FsInkey()){}while(0!=FsInkeyChar()){}
        if(YSTRUE!=lb && YSTRUE!=rb)squadInputRelease=false;
        return true;
    }
    if(auto show=FsGetAirshow(this))if(show->menuOpen)
    {
        while(FSKEY_NULL!=(key=FsInkey())){if(key==FSKEY_ESC || ctlAssign.TranslateKeyStroke(key)==FSBTF_AIRSHOWMENU){show->menuOpen=false;CloseSquadWheel();break;}if(key>=FSKEY_1 && key<=FSKEY_4){int i=key-FSKEY_1;if(i==3){show->menuOpen=false;CloseSquadWheel();}else show->Command(this,i+1);}}
        while(FSMOUSEEVENT_NONE!=(event=FsGetMouseEvent(lb,mb,rb,mx,my)))if(event==FSMOUSEEVENT_LBUTTONDOWN){show->Click(this,mx,my);if(!show->menuOpen)CloseSquadWheel();}
        return true;
    }
    auto op=FsGetOperation(this);
    if(op && op->mapOpen)
    {
        while(FSKEY_NULL!=(key=FsInkey()))
        {
            if(key==FSKEY_ESC || key==FSKEY_ENTER || ctlAssign.TranslateKeyStroke(key)==FSBTF_TACTICALMAP){op->mapOpen=false;CloseSquadWheel();break;}
            if(key==FSKEY_WHEELUP)op->mapZoom=YsBound(op->mapZoom*1.25,0.25,12.0);
            if(key==FSKEY_WHEELDOWN)op->mapZoom=YsBound(op->mapZoom/1.25,0.25,12.0);
        }
        while(0!=FsInkeyChar()){}
        while(FSMOUSEEVENT_NONE!=(event=FsGetMouseEvent(lb,mb,rb,mx,my)))
            if(squadWheelOpen && event==FSMOUSEEVENT_LBUTTONDOWN){op->MapClick(this,mx,my);if(!op->mapOpen)CloseSquadWheel();}
        return true;
    }
    auto choose=[&](int item)
    {
        if(op && op->wheelPage>0)
        {if(item==-2){op->wheelPage=0;return;}if(op->WheelChoose(this,item))CloseSquadWheel();return;}
        if(op && item==-2 && !squadWheelFormations){op->wheelPage=1;return;}
        if(!op && item==-2 && !squadWheelFormations)if(auto show=FsGetAirshow(this)){show->menuOpen=true;return;}
        if(squadWheelFormations)
        {
            if(item==-2){squadWheelFormations=false;return;}
            if(item>=0 && item<FsGroupPatternCount){IssueSquadCommand(100+FsGroupPatternIds[item]);CloseSquadWheel();}
        }
        else if(item==0){squadWheelFormations=true;squadFormationPage=0;}
        else if(item>=1 && item<=8){IssueSquadCommand(item);CloseSquadWheel();}
        else if(item==-2)CloseSquadWheel();
    };
    while(FSKEY_NULL!=(key=FsInkey()))
    {
        if(key==FSKEY_ESC || ctlAssign.TranslateKeyStroke(key)==FSBTF_OPENRADIOCOMMMENU){CloseSquadWheel();break;}
        if(FSKEY_1<=key && key<=FSKEY_9){choose(key-FSKEY_1);if(!squadWheelOpen)break;}
        if(key==FSKEY_0 && squadWheelFormations){choose(9);if(!squadWheelOpen)break;}
    }
    while(0!=FsInkeyChar()){}
    while(FSMOUSEEVENT_NONE!=(event=FsGetMouseEvent(lb,mb,rb,mx,my)))
    {
        if(!squadWheelOpen)break;
        if(event==FSMOUSEEVENT_RBUTTONDOWN){CloseSquadWheel();break;}
        if(event==FSMOUSEEVENT_LBUTTONDOWN)
        {
            int w,h;FsGetWindowSize(w,h);const int item=WheelItem(mx,my,w,h,op && op->wheelPage>0 ? int(op->WheelLabels().GetN()) : squadWheelFormations ? FsGroupPatternCount : 9);
            if(item==-1)CloseSquadWheel();else choose(item);
        }
    }
    return true;
}
void FsSimulation::DrawSquadWheel() const
{
    if(!squadWheelOpen)return;
    if(auto show=FsGetAirshow(this))if(show->menuOpen){show->DrawMenu(this);return;}
    auto op=FsGetOperation(this);if(op && op->mapOpen){op->DrawMap(this);return;}
    int w,h;FsGetWindowSize(w,h);const int cx=w/2,cy=h/2,r=YsSmaller(260,int(h*0.34));
    const auto extra=op ? op->WheelLabels() : YsArray<YsWString>();
    const bool operationPage=op && op->wheelPage>0;
    const int count=operationPage ? int(extra.GetN()) : squadWheelFormations ? FsGroupPatternCount : 9;
    int lb,mb,rb,mx,my;FsGetMouseState(lb,mb,rb,mx,my);const int hover=WheelItem(mx,my,w,h,count);
    const wchar_t *main[]={T("v7/shape",L"Formation"),T("v7/regroup",L"Regroup"),T("v7/scatter",L"Scatter"),T("v7/closer",L"Closer"),T("v7/farther",L"Farther"),T("v7/cover",L"Cover me"),T("v7/attack",L"Attack target"),T("v7/hold",L"Hold area"),T("v7/abort",L"Abort attack")};
    const wchar_t *patterns[]={T("v7/diamond",L"Diamond"),T("v7/delta",L"Delta"),T("v7/vee",L"V formation"),T("v7/trail",L"Column"),T("v7/line",L"Line abreast"),T("v7/left",L"Echelon left"),T("v7/right",L"Echelon right"),T("v84/wheel7",L"Staircase up"),T("v84/wheel8",L"Staircase left"),T("v84/wheel9",L"Staircase right"),T("v84/wheel10",L"Staggered pairs"),T("v84/wheel11",L"Reverse V")};
    for(int item=0;item<count;++item)
    {
        int points[44];int n=0;points[n++]=cx;points[n++]=cy;
        for(int step=0;step<=20;++step)
        {
            const double a=(double(item)-0.5+double(step)/20.0)*2*YsPi/count;
            points[n++]=cx+int(sin(a)*r);points[n++]=cy-int(cos(a)*r);
        }
        FsDrawPolygon(n/2,points,item==hover ? SquadColor(25,103,121) : SquadColor(17,29,45));
        FsDrawLine(cx,cy,points[2],points[3],SquadColor(100,155,175));
        const double a=double(item)*2*YsPi/count;
        YsString number;number.Printf("%d\n",squadWheelFormations ? (item+1)%10:item+1);YsWString label;label.SetUTF8String(number);label.Append(operationPage ? extra[item].Txt() : squadWheelFormations ? patterns[FsGroupPatternIds[item]] : main[item]);
        CenterText(cx+int(sin(a)*r*0.69),cy-int(cos(a)*r*0.69),label,YsWhite());
    }
    FsDrawCircle(cx,cy,r,SquadColor(125,190,205),YSFALSE);
    FsDrawCircle(cx,cy,int(r*0.29),SquadColor(7,17,29),YSTRUE);
    CenterText(cx,cy,op ? T(operationPage || squadWheelFormations ? "v7/back" : "v8/groupsOrders",L"Groups / orders") : T(squadWheelFormations ? "v7/back" : FsGetAirshow(this) ? "show/tab" : "v7/squad",L"Wingmen"),SquadColor(130,225,235));
    if(op){YsWString scope=op->ScopeName();CenterText(cx,cy-r-66,scope,YsYellow());}
    FsDrawRect(cx-190,cy-r-47,cx+190,cy-r-12,SquadColor(7,17,29),YSTRUE);
    FsDrawRect(cx-300,cy+r+10,cx+300,cy+r+42,SquadColor(7,17,29),YSTRUE);
    CenterText(cx,cy-r-30,T("v7/wheelTitle",L"WINGMAN COMMANDS"),YsWhite());
    CenterText(cx,cy+r+24,T("v7/wheelHint",L"1-9 or mouse click. Esc cancels. Flight is paused."),YsWhite());
    FsDrawCircle(mx,my,5,YsWhite(),YSFALSE);FsDrawLine(mx-9,my,mx+9,my,YsWhite());FsDrawLine(mx,my-9,mx,my+9,YsWhite());
}

void FsSimulation::PrintSquadAndLockReport()
{
    auto player=GetPlayerAirplane();if(nullptr==player)return;
    printf("V7REPORT time=%.6f weapon=%d aim9=%d aim9x=%d aim120=%d candidate=%u target=%u lock=%.6f ready=%d paused=%d\n",
        currentTime,int(player->Prop().GetWeaponOfChoice()),player->Prop().GetNumWeapon(FSWEAPON_AIM9),
        player->Prop().GetNumWeapon(FSWEAPON_AIM9X),player->Prop().GetNumWeapon(FSWEAPON_AIM120),playerLockCandidate,
        player->Prop().GetAirTargetKey(),playerLockSeconds,playerLockReady ? 1 : 0,int(pause));
    printf("V85INPUT keyboard=%d arrow_up=%d arrow_left=%d\n",int(ctlAssign.primaryInputMode==FsControlAssignment::PRIMARYINPUT_KEYBOARD),int(ctlAssign.FindKeyByFunction(FSBTF_ELEVATORDOWN)==FSKEY_UP),int(ctlAssign.FindKeyByFunction(FSBTF_AILERONLEFT)==FSKEY_LEFT));
    printf("V8LEADER h=%.3f b=%.3f p=%.3f y=%.3f speed=%.3f\n",YsRadToDeg(player->GetAttitude().h()),YsRadToDeg(player->GetAttitude().b()),YsRadToDeg(player->GetAttitude().p()),player->GetPosition().y(),player->Prop().GetVelocity());
    auto members=GetPlayerSquad();printf("V7SQUAD count=%d\n",int(members.GetN()));
    for(auto wing:members)
    {
        const auto pos=wing->GetPosition();YsVec3 goal=wing->squadOffset;
        YsAtt3 heading=player->GetAttitude();heading.SetP(0.0);heading.SetB(0.0);heading.Mul(goal,goal);goal+=player->GetPosition();
        auto fm=dynamic_cast<FsFormation *>(wing->GetAutopilot());
        printf("V7MEMBER id=%d slot=%d task=%d autopilot=%d x=%.3f y=%.3f z=%.3f ox=%.3f oy=%.3f oz=%.3f error=%.3f formationMode=%d\n",
            wing->ysfId,wing->squadSlot,wing->squadTask,wing->GetAutopilot()!=nullptr ? int(wing->GetAutopilot()->Type()) : -1,
            pos.x(),pos.y(),pos.z(),wing->squadOffset.x(),wing->squadOffset.y(),wing->squadOffset.z(),
            (goal-pos).GetLength(),fm!=nullptr ? fm->mode : -1);
        printf("V8FOLLOW slot=%d safe=%d agl=%.3f speed=%.3f bank=%.3f pitch=%.3f spoiler=%.3f alive=%d\n",wing->squadSlot,fm!=nullptr ? int(fm->headingOnly) : 0,wing->GetAGL(),wing->Prop().GetVelocity(),YsRadToDeg(wing->GetAttitude().b()),YsRadToDeg(wing->GetAttitude().p()),wing->Prop().GetSpoiler(),int(wing->IsAlive()));
    }
    for(auto wing:members)if(auto fm=dynamic_cast<FsFormation *>(wing->GetAutopilot()))printf("V83GUIDE slot=%d rejoin=%d avoid=%d dy=%.3f targetSpeed=%.3f targetClimb=%.3f turn=%.3f\n",wing->squadSlot,int(fm->rejoining),int(fm->collisionRisk),fm->avoidanceHeight,fm->commandedSpeed,fm->commandedClimb,fm->formationTurnRate);
    if(auto op=FsGetOperation(this))op->Report(this);
    if(auto show=FsGetAirshow(this))show->Report(this);
    fflush(stdout);
}
