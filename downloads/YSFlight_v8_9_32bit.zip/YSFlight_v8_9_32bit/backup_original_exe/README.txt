These are the original executables from the uploaded archive.
To restore, close the game and copy these files to the parent game folder, replacing the modified files.
Do not launch them inside this backup folder: the game assets are in the parent folder.
