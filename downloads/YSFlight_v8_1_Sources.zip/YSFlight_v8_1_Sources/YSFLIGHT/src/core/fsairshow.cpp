#define FSSIMPLEWINDOW_DONT_INCLUDE_OPENGL_HEADERS
#include <fssimplewindow.h>
#include "fs.h"
#include "fsairshow.h"
#include "fsafterburnervisual.h"
#include "fstextresource.h"
#include "graphics/common/fsopengl.h"
namespace{const wchar_t *T(const char *k,const wchar_t *s){return FsGetTextResource(k,s);}YsColor C(int r,int g,int b){YsColor c;c.SetIntRGB(r,g,b);return c;}}
std::shared_ptr<FsSimExtension_Airshow> FsGetAirshow(const FsSimulation *sim)
{return sim ? std::dynamic_pointer_cast<FsSimExtension_Airshow>(sim->FindExtension(FsSimExtension_Airshow::Ident())) : nullptr;}
std::function<std::shared_ptr<FsSimExtensionBase>(void)> FsSimExtension_Airshow::Generator()
{return [](){return std::make_shared<FsSimExtension_Airshow>();};}
FsAirplane *FsSimExtension_Airshow::Aircraft(const FsSimulation *sim,int i) const
{
 auto player=sim->GetPlayerAirplane();if(i==0)return player;
 for(auto a=sim->FindNextAirplane(nullptr);a;a=sim->FindNextAirplane(a))if(a!=player && a->squadSlot==i-1 && a->squadLeaderKey==FsExistence::GetSearchKey(player))return a;
 return nullptr;
}
YsArray<YsString> FsSimExtension_Airshow::Serialize(const FsSimulation *)
{
 YsArray<YsString> rows;YsString s;s.Printf("EXTENSIO %s CONFIG %d %d %d %d %.3f %.3f",Ident(),config.supply,config.synchronized,config.autoAfterburner,config.burst,config.interval,config.cameraSensitivity);rows.Append(s);
 for(int i=0;i<9;++i){s.Printf("EXTENSIO %s COLOR %d %d %d %d",Ident(),i,config.rgb[i][0],config.rgb[i][1],config.rgb[i][2]);rows.Append(s);}
 return rows;
}
YSRESULT FsSimExtension_Airshow::ProcessCommand(FsSimulation *,const YsConstArrayMask<YsString> &a)
{
 if(a.GetN()>=9 && 0==a[2].Strcmp("CONFIG")){config.supply=atoi(a[3])!=0;config.synchronized=atoi(a[4])!=0;config.autoAfterburner=atoi(a[5])!=0;config.burst=YsBound(atoi(a[6]),1,64);config.interval=YsBound(atof(a[7]),0.1,2.0);config.cameraSensitivity=YsBound(atof(a[8]),0.05,2.0);return YSOK;}
 if(a.GetN()>=7 && 0==a[2].Strcmp("COLOR")){int i=atoi(a[3]);if(i>=0 && i<9)for(int c=0;c<3;++c)config.rgb[i][c]=YsBound(atoi(a[4+c]),0,255);return YSOK;}return YSERR;
}
void FsSimExtension_Airshow::StartSimulation(FsSimulation *sim)
{
 replaying=false;sim->GetPlayerSquad();SetupAircraft(sim,true);
 sim->AddTimedMessage(T("show/keys",L"F10: airshow | F2: orbit camera | right drag: rotate | wheel: zoom"));
}
void FsSimExtension_Airshow::StartReplay(FsSimulation *sim){replaying=true;sim->GetPlayerSquad();SetupAircraft(sim,false);}
void FsSimExtension_Airshow::SetupAircraft(FsSimulation *sim,bool resupply)
{
 for(int i=0;i<9;++i)if(auto a=Aircraft(sim,i))
 {
  if(config.supply && resupply){a->SendCommand("MAXNMFLR 500");a->Prop().SetNumWeapon(FSWEAPON_FLARE_INTERNAL,500);a->SendCommand("LOADWEPN IFLR 500");YsString oil;oil.Printf("SMOKEOIL %.3fkg",YsGreater(100.0,a->Prop().GetSmokeOil()));a->SendCommand(oil);}
  if(a->Prop().GetNumSmokeGenerator()==0){YsString s;s.Printf("SMOKEGEN 0m 0m %.3fm",-a->GetApproximatedCollideRadius()*0.5);a->SendCommand(s);}
  YsString s;s.Printf("SMOKECOL ALL %d %d %d",config.rgb[i][0],config.rgb[i][1],config.rgb[i][2]);a->SendCommand(s);
 }

}
void FsSimExtension_Airshow::ApplyControls(FsSimulation *sim)
{
 if(replaying)return;
 for(int i=0;i<9;++i)if(auto a=Aircraft(sim,i))if(a->IsAlive()==YSTRUE)
 {
  if(smoke[i]){a->Prop().SetSmokeSelector(255);a->Prop().SetSmokeButton(YSTRUE);}
  // Auto reheat uses the native engine, fuel consumption and plume visibility.
  if(i==0 && FsAfterburnerVisual::RealEngineAllowsFlame(a->Prop().GetIdentifier()) && config.autoAfterburner && a->GetAutopilot()==nullptr && a->Prop().IsJet()==YSTRUE && a->Prop().GetHasAfterburner()==YSTRUE && a->Prop().GetAircraftClass()!=FSCL_HELICOPTER)
   a->Prop().SetAfterburner(a->Prop().GetThrottle()>0.98 ? YSTRUE : YSFALSE);
 }
}
void FsSimExtension_Airshow::OnInterval(FsSimulation *sim,double dt)
{
 if(replaying || dt<=0)return;
 if(sim->GetClock()>=nextFlare)
 {
  for(int i=0;i<9;++i)if(remaining[i]>0)
  {
   if(auto a=Aircraft(sim,i))if(a->IsAlive()==YSTRUE){YSBOOL blocked=YSFALSE;a->Prop().FireWeapon(blocked,sim,sim->GetClock(),sim->GetWeaponStore(),a,FSWEAPON_FLARE);}
   --remaining[i];
  }
  nextFlare=sim->GetClock()+config.interval;
 }
}
void FsSimExtension_Airshow::Command(FsSimulation *sim,int action)
{
 if(replaying)return;
 if(action==0){for(int i=0;i<9;++i)if(config.synchronized || i==selected){if(auto a=Aircraft(sim,i)){if(a->Prop().GetNumWeapon(FSWEAPON_FLARE)>0)remaining[i]=config.burst;else sim->AddTimedMessage(T("show/noFlares",L"No flares: enable show equipment before departure."));}}nextFlare=sim->GetClock();}
 if(action==1){bool on=!smoke[selected];for(int i=0;i<9;++i)if(config.synchronized || i==selected){smoke[i]=on;if(auto a=Aircraft(sim,i)){if(on && a->Prop().GetSmokeOil()<=0.0){smoke[i]=false;sim->AddTimedMessage(T("show/noOil",L"No smoke oil: enable show equipment before departure."));}a->Prop().SetSmokeButton(smoke[i] ? YSTRUE : YSFALSE);}}}
 if(action==2){for(int n=0;n<9;++n){selected=(selected+1)%9;if(Aircraft(sim,selected))break;}config.synchronized=false;}
 if(action==3)config.synchronized=!config.synchronized;
 if(action==4){for(int n=0;n<9;++n){cameraUnit=(cameraUnit+1)%9;if(Aircraft(sim,cameraUnit))break;}sim->SimProcessButtonFunction(FSBTF_OUTSIDEPLAYERVIEW,FSUSC_ENABLE);}
 if(action==5){const int values[]={4,8,16,32,64};int n=0;while(n<5 && values[n]<=config.burst)++n;config.burst=values[n%5]; }
 if(action==6)for(auto &n:remaining)n=0;
}
namespace
{
struct ShowLayout
{
 int x,y,width,height,left,right,top,row;
 ShowLayout(){int w,h;FsGetWindowSize(w,h);width=YsSmaller(1120,w-24);height=YsSmaller(650,h-24);x=(w-width)/2;y=(h-height)/2;left=x+20;right=x+width/2+10;top=y+100;row=YsSmaller(51,(height-170)/8);}
};
YsWString ShowUnitName(int i)
{
 YsWString name(T(i==0 ? "show/playerName" : "show/wingmanName",i==0 ? L"Player" : L"Wingman"));
 if(i>0){YsString number;number.Printf(" %d",i);YsWString tail;tail.SetUTF8String(number);name.Append(tail);}return name;
}
}
void FsSimExtension_Airshow::DrawMenu(const FsSimulation *sim) const
{
 const ShowLayout l;const auto ink=C(25,30,35),paper=C(225,227,230),edge=C(105,112,120);
 FsDrawRect(l.x,l.y,l.x+l.width,l.y+l.height,paper,YSTRUE);FsDrawRect(l.x,l.y,l.x+l.width,l.y+l.height,edge,YSFALSE);
 FsDrawRect(l.x,l.y,l.x+l.width,l.y+42,C(50,64,78),YSTRUE);
 FsDrawString(l.left,l.y+12,T("show/title",L"AIRSHOW - FLIGHT PAUSED"),YsWhite());
 FsDrawString(l.left,l.y+57,T("show/menuGuide",L"Click a button or press its number. Close this menu to resume the show."),ink);
 const wchar_t *names[]={T("show/flare",L"Release flare burst"),T(smoke[selected] ? "show/smokeOff" : "show/smokeOn",L"Smoke on / off"),T("show/unit",L"Select aircraft"),T(config.synchronized ? "show/scopeAll" : "show/scopeOne",L"Who receives commands"),T("show/camera",L"Camera target"),T("show/burst",L"Burst length"),T("show/stop",L"Stop flare burst"),T("show/close",L"Resume flight (F10 / Esc)")};
 for(int i=0;i<8;++i)
 {
  int y=l.top+i*l.row;FsDrawRect(l.left,y,l.right-22,y+l.row-6,i==7 ? C(185,205,190) : C(248,249,250),YSTRUE);FsDrawRect(l.left,y,l.right-22,y+l.row-6,edge,YSFALSE);
  YsString num;num.Printf("%d",i+1);YsWString key;key.SetUTF8String(num);FsDrawString(l.left+10,y+10,key,ink);FsDrawString(l.left+35,y+10,names[i],ink);
 }
 YsWString recipient(T("show/recipient",L"Commands to: "));recipient.Append(config.synchronized ? YsWString(T("show/wholeSquad",L"Whole squad")) : ShowUnitName(selected));FsDrawString(l.right,l.top,recipient,ink);
 YsWString camera(T("show/cameraState",L"Camera: "));camera.Append(ShowUnitName(cameraUnit));FsDrawString(l.right,l.top+28,camera,ink);
 YsString count;count.Printf("%d",config.burst);YsWString series(T("show/burstState",L"Flares per burst: "));YsWString number;number.SetUTF8String(count);series.Append(number);FsDrawString(l.right,l.top+56,series,ink);
 FsDrawString(l.right,l.top+86,T("show/chooseRow",L"Click an aircraft below to command it alone:"),ink);
 int y=l.top+115;const int row=YsSmaller(30,(l.height-290)/9);
 for(int i=0;i<9;++i)if(auto a=Aircraft(sim,i))
 {
  if(i==selected && !config.synchronized)FsDrawRect(l.right-4,y-3,l.x+l.width-16,y+row-4,C(192,211,230),YSTRUE);
  FsDrawRect(l.right,y+1,l.right+14,y+15,C(config.rgb[i][0],config.rgb[i][1],config.rgb[i][2]),YSTRUE);FsDrawRect(l.right,y+1,l.right+14,y+15,edge,YSFALSE);
  YsWString unit=ShowUnitName(i);unit.Append(smoke[i] ? T("show/isSmoking",L" - smoke ON") : T("show/isNotSmoking",L" - smoke OFF"));FsDrawString(l.right+23,y,unit,ink);y+=row;
 }
 FsDrawString(l.left,l.y+l.height-60,T("show/cameraHelp",L"F2: outside view | right drag: rotate | wheel: zoom | F1: cockpit"),ink);
 FsDrawString(l.left,l.y+l.height-33,T("show/resumeHint",L"Commands run after closing the menu. Smoke colours are set before departure."),ink);
 int lb,mb,rb,x,y2;FsGetMouseState(lb,mb,rb,x,y2);FsDrawCircle(x,y2,5,ink,YSFALSE);
}
void FsSimExtension_Airshow::Click(FsSimulation *sim,int x,int y)
{
 const ShowLayout l;
 if(x>=l.left && x<=l.right-22 && y>=l.top && y<l.top+8*l.row)
 {
  int i=(y-l.top)/l.row;if((y-l.top)%l.row>l.row-6)return;
  if(i==7)menuOpen=false;else Command(sim,i);return;
 }
 const int row=YsSmaller(30,(l.height-290)/9);int rowY=l.top+115;
 for(int i=0;i<9;++i)if(Aircraft(sim,i)){if(x>=l.right && x<=l.x+l.width-16 && y>=rowY-3 && y<rowY+row-3){selected=i;config.synchronized=false;return;}rowY+=row;}
}
void FsSimExtension_Airshow::CameraInput(int key,bool right,int x,int y)
{
 if(key==FSKEY_WHEELUP)distance=YsBound(distance/1.12,10.0,10000.0);
 if(key==FSKEY_WHEELDOWN)distance=YsBound(distance*1.12,10.0,10000.0);
 if(right && !dragging){restoreX=x;restoreY=y;}
 if(!right && dragging){FsSetMousePosition(restoreX,restoreY);x=restoreX;y=restoreY;}
 if(right && dragging){heading+=(x-lastX)*YsDegToRad(config.cameraSensitivity);pitch=YsBound(pitch+(y-lastY)*YsDegToRad(config.cameraSensitivity),-YsPi*0.48,YsPi*0.48);}
 dragging=right;lastX=x;lastY=y;
}
void FsSimExtension_Airshow::Report(const FsSimulation *sim) const
{
 printf("V8SHOW selected=%d sync=%d burst=%d camera=%d heading=%.3f pitch=%.3f distance=%.3f\n",selected,config.synchronized,config.burst,cameraUnit,heading,pitch,distance);
 for(int i=0;i<9;++i)if(auto a=Aircraft(sim,i))printf("V8SHOWUNIT slot=%d flare=%d smoke=%d ab=%d throttle=%.3f\n",i,a->Prop().GetNumWeapon(FSWEAPON_FLARE),int(a->Prop().IsTrailingSmoke(0)),int(a->Prop().GetAfterBurner()),a->Prop().GetThrottle());
}
