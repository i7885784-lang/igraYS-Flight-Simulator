﻿Шасси внутри корпуса, тест №3а: исправлено освещение внешних створок Су-27/МиГ-29.
Распакуйте всю папку в новое место, запустите ysflight32_gl1.exe. G — шасси.
Механизмы/остальные самолёты прежние от теста №3. Су-34 в публичной сборке отсутствует.
Авторы, оригиналы, GPL и конвертеры: aircraft/*-source/NOTICE.txt.
Проверено Win64/Wine; настоящая Windows 10 x86 не проверялась.
Отчёт: https://github.com/i7885784-lang/igraYS-Flight-Simulator/blob/ysflight-center-download/reports/internal-gear-test-3a/REPORT.md
