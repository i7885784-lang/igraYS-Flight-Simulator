#ifndef FSSQUADLIMITS_IS_INCLUDED
#define FSSQUADLIMITS_IS_INCLUDED
constexpr int FsMaxPlayerWingmen=10;
constexpr int FsMaxShowAircraft=FsMaxPlayerWingmen+1;
#endif
