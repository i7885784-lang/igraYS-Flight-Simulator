#ifndef FSSMOKEPALETTE_IS_INCLUDED
#define FSSMOKEPALETTE_IS_INCLUDED
struct FsSmokePaletteEntry { const char *key;const wchar_t *name;int rgb[3]; };
static const FsSmokePaletteEntry FsSmokePalette[]={
{"show/white",L"White",{255,255,255}},
{"show/blue",L"Blue",{70,140,255}},
{"show/red",L"Red",{255,60,60}},
{"show/yellow",L"Yellow",{255,215,0}},
{"show/green",L"Green",{50,230,90}},
{"show/purple",L"Purple",{190,80,255}},
{"show/orange",L"Orange",{255,130,30}},
{"show/cyan",L"Cyan",{50,230,230}},
{"show/pink",L"Pink",{255,100,180}},
{"show/black",L"Black",{0,0,0}},
{"show/gray",L"Gray",{120,120,120}},
{"show/brown",L"Brown",{145,85,45}},
{"show/navy",L"Dark blue",{20,40,130}},
{"show/lime",L"Lime",{170,255,30}},
{"show/magenta",L"Magenta",{255,0,255}},
};
constexpr int FsSmokePaletteCount=sizeof(FsSmokePalette)/sizeof(FsSmokePalette[0]);
#endif
