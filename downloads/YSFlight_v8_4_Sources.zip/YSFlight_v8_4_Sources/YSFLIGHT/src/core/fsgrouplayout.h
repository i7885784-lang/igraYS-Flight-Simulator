#ifndef FSGROUPLAYOUT_IS_INCLUDED
#define FSGROUPLAYOUT_IS_INCLUDED
constexpr int FsGroupPatternCount=12;
struct FsGroupOffset { double x,z,y;FsGroupOffset(double x=0.0,double z=0.0,double y=0.0):x(x),z(z),y(y){} };
inline FsGroupOffset FsGetGroupOffset(int pattern,int index,double spacing)
{
    static const int diamond[10][2]={{-1,-1},{1,-1},{0,-2},{-2,-2},{2,-2},{-1,-3},{1,-3},{0,-4},{-2,-4},{2,-4}};
    static const int delta[10][2]={{-1,-1},{1,-1},{-2,-2},{0,-2},{2,-2},{-3,-3},{-1,-3},{1,-3},{3,-3},{0,-4}};
    const int rank=index/2+1;FsGroupOffset p;
    switch(pattern)
    {
    case 0:p={double(diamond[index%10][0]),double(diamond[index%10][1])};break;
    case 1:p={double(delta[index%10][0]),double(delta[index%10][1])};break;
    case 2:p={double(index%2==0 ? -rank : rank),double(-rank)};break;
    case 3:p={0.0,double(-index-1)};break;
    case 4:p={double(index%2==0 ? -rank : rank),0.0};break;
    case 5:p={double(-index-1),double(-index-1)};break;
    case 6:p={double(index+1),double(-index-1)};break;
    case 7:p={0.0,double(-index-1),0.4*(index+1)};break;
    case 8:p={double(-index-1),double(-index-1),0.4*(index+1)};break;
    case 9:p={double(index+1),double(-index-1),0.4*(index+1)};break;
    case 10:p={index%2==0 ? -0.5:0.5,double(-rank)};break;
    case 11:p={double(index%2==0 ? -rank : rank),double(rank)};break;
    default:p={0.0,double(-index-1)};break;
    }
    p.x*=spacing;p.y*=spacing;p.z*=spacing;return p;
}
#endif
