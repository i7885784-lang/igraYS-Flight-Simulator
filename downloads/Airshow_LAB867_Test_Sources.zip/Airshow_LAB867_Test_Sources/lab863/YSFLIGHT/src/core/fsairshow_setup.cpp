#include "fs.h"
#include "fssmokepalette.h"
#include "fsguinewflightdialog.h"
#include "fstextresource.h"
namespace{const wchar_t *T(const char *k,const wchar_t *s){return FsGetTextResource(k,s);}}
void FsGuiNewFlightDialogClass::MakeShowTab()
{
 int tab=AddTab(mainTab,T("show/tab",L"Airshow"));BeginAddTabItem(mainTab,tab);
 const wchar_t *units[]={T("v8/player",L"Player"),T("show/wing1",L"Wingman 1"),T("show/wing2",L"Wingman 2"),T("show/wing3",L"Wingman 3"),T("show/wing4",L"Wingman 4"),T("show/wing5",L"Wingman 5"),T("show/wing6",L"Wingman 6"),T("show/wing7",L"Wingman 7"),T("show/wing8",L"Wingman 8")};
 AddStaticText(0,FSKEY_NULL,T("show/unitColor",L"Smoke colour for aircraft"),YSTRUE);
 showUnit=AddDropList(MkId("showUnit"),FSKEY_NULL,L"",FsMaxShowAircraft,units,FsMaxShowAircraft,16,16,YSFALSE);
 const wchar_t *palette[FsSmokePaletteCount];for(int i=0;i<FsSmokePaletteCount;++i)palette[i]=T(FsSmokePalette[i].key,FsSmokePalette[i].name);
 AddStaticText(0,FSKEY_NULL,T("show/palette",L"2. Choose a colour"),YSTRUE);
 showPalette=AddDropList(MkId("showPalette"),FSKEY_NULL,T("show/palette",L"Palette"),FsSmokePaletteCount,palette,10,18,18,YSFALSE);
 showSupply=AddTextButton(MkId("showSupply"),FSKEY_NULL,FSGUI_CHECKBOX,T("show/supply",L"Show equipment: 500 flares and smoke oil"),YSTRUE);showSupply->SetCheck(YSTRUE);
 showSync=AddTextButton(MkId("showSync"),FSKEY_NULL,FSGUI_CHECKBOX,T("show/all",L"Apply smoke commands to all aircraft"),YSTRUE);showSync->SetCheck(YSTRUE);
 showAutoAB=AddTextButton(MkId("showAutoAB"),FSKEY_NULL,FSGUI_CHECKBOX,T("show/autoAB",L"Automatic reheat at full throttle (equipped jets only)"),YSTRUE);showAutoAB->SetCheck(YSTRUE);
 showBurst=AddTextBox(MkId("showBurst"),FSKEY_NULL,FsGuiTextBox::HORIZONTAL,T("show/burstCount",L"Flares in burst (1-64)"),"16",4,YSTRUE);
 showInterval=AddTextBox(MkId("showInterval"),FSKEY_NULL,FsGuiTextBox::HORIZONTAL,T("show/interval",L"Burst interval, ms"),"200",5,YSTRUE);
 showSensitivity=AddTextBox(MkId("showSensitivity"),FSKEY_NULL,FsGuiTextBox::HORIZONTAL,T("show/sensitivity",L"Camera sensitivity, percent"),"100",4,YSTRUE);
 AddStaticText(0,FSKEY_NULL,T("show/hint",L"F10: smoke / flares / camera target. F2: right drag to orbit, wheel to zoom.\nRGB is saved separately for every aircraft. Smoke starts switched off."),YSTRUE);
 EndAddTabItem();showEdit=0;UpdateShow();
}
void FsGuiNewFlightDialogClass::CaptureShow()
{
 if(showUnit==nullptr)return;
 const int colour=YsBound(showPalette->GetSelection(),0,FsSmokePaletteCount-1);for(int c=0;c<3;++c)info.show.rgb[showEdit][c]=FsSmokePalette[colour].rgb[c];
 info.show.supply=showSupply->GetCheck()==YSTRUE;info.show.synchronized=showSync->GetCheck()==YSTRUE;info.show.autoAfterburner=showAutoAB->GetCheck()==YSTRUE;
 info.show.burst=YsBound(showBurst->GetInteger(),1,64);info.show.interval=YsBound(showInterval->GetInteger()/1000.0,0.1,2.0);info.show.cameraSensitivity=YsBound(showSensitivity->GetInteger()*0.0035,0.05,2.0);
}
void FsGuiNewFlightDialogClass::UpdateShow()
{
 const int c=FsNearestSmokePalette(info.show.rgb[showEdit][0],info.show.rgb[showEdit][1],info.show.rgb[showEdit][2]);
 showPalette->Select(c);for(int j=0;j<3;++j)info.show.rgb[showEdit][j]=FsSmokePalette[c].rgb[j];SetNeedRedraw(YSTRUE);
}
