#ifndef FSSMOKEPALETTE_IS_INCLUDED
#define FSSMOKEPALETTE_IS_INCLUDED
struct FsSmokePaletteEntry { const char *key;const wchar_t *name;int rgb[3]; };
static const FsSmokePaletteEntry FsSmokePalette[]={
{"show/black",L"Black",{0,0,0}},
{"show/white",L"White",{255,255,255}},
{"show/blue",L"Blue",{70,140,255}},
{"show/red",L"Red",{255,60,60}},
{"show/green",L"Green",{50,230,90}},
{"show/yellow",L"Yellow",{255,215,0}},
};
constexpr int FsSmokePaletteCount=sizeof(FsSmokePalette)/sizeof(FsSmokePalette[0]);
inline int FsNearestSmokePalette(int r,int g,int b)
{
 int best=0,distance=1000000000;
 for(int i=0;i<FsSmokePaletteCount;++i){int dr=r-FsSmokePalette[i].rgb[0],dg=g-FsSmokePalette[i].rgb[1],db=b-FsSmokePalette[i].rgb[2];int d=dr*dr+dg*dg+db*db;if(d<distance){distance=d;best=i;}}
 return best;
}
#endif
