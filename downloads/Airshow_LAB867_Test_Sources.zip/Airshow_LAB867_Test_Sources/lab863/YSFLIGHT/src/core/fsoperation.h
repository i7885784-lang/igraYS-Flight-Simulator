#ifndef FSOPERATION_IS_INCLUDED
#define FSOPERATION_IS_INCLUDED
#include "fssimextension.h"
class FsAirplane;
class FsGround;
struct FsOperationUnit
{
    int slot=-1,group=1,task=0,waypoint=0,followGroup=0;
    double height=150.0,speed=25.0,nextFire=0.0;
    YsVec3 destination=YsOrigin();
    YsArray<YsVec3> route;
    bool pending=true,landRequested=false;
    YsString targetName;
};
class FsSimExtension_Operation : public FsSimExtensionBase
{
public:
    YsVec3 landing=YsOrigin(),rally=YsOrigin(),selectedPoint=YsOrigin();
    YsArray<YsString> defenders;
    YsArray<FsOperationUnit> units;
    YsString groupName[4];
    int transportSlot=-1,status=0,scopeGroup=0,scopeSlot=-2,wheelPage=0;
    double landingSeconds=0.0,resultTime=-1.0,mapZoom=1.0;
    bool replaying=false,mapOpen=false,hasPoint=false;
    YsString selectedGround;
    FsSimExtension_Operation();
    static const char *Ident(){return "SQUAD_OPERATION_V8";}
    virtual const char *GetIdent() const{return Ident();}
    static std::function<std::shared_ptr<FsSimExtensionBase>(void)> Generator();
    virtual YsArray<YsString> Serialize(const FsSimulation *sim);
    virtual YSRESULT ProcessCommand(FsSimulation *sim,const YsConstArrayMask<YsString> &args);
    virtual void StartSimulation(FsSimulation *sim);
    virtual void StartReplay(FsSimulation *){replaying=true;}
    virtual void OnInterval(FsSimulation *sim,double dt);
    virtual YSBOOL MustKeepRunning(const FsSimulation *) const{return status==0 ? YSTRUE : YSFALSE;}
    virtual YSBOOL MustTerminate(const FsSimulation *sim) const override;
    virtual YSBOOL CanContinue(FsSimulation *) const override{return status==0 ? YSTRUE : YSFALSE;}
    virtual YSBOOL CanResume(FsSimulation *) const override{return status==0 ? YSTRUE : YSFALSE;}
    FsAirplane *Aircraft(const FsSimulation *sim,int slot) const;
    FsOperationUnit *Unit(int slot);
    bool InScope(int slot) const;
    int LiveDefenders(const FsSimulation *sim) const;
    void Order(FsSimulation *sim,int task,int followGroup=-1);
    void ApplyUnit(FsSimulation *sim,FsOperationUnit &unit);
    void Draw(const FsSimulation *sim) const;
    void DrawMap(const FsSimulation *sim) const;
    void MapClick(FsSimulation *sim,int x,int y);
    YsWString ScopeName() const;
    YsArray<YsWString> WheelLabels() const;
    bool WheelChoose(FsSimulation *sim,int item);
    void Report(const FsSimulation *sim) const;
};
void FsCreateSafeFollower(FsAirplane &wing,FsAirplane &leader);
std::shared_ptr<FsSimExtension_Operation> FsGetOperation(const FsSimulation *sim);
#endif
