#ifndef FSMAPPREVIEW_IS_INCLUDED
#define FSMAPPREVIEW_IS_INCLUDED
#include <algorithm>
#include <cmath>

// Top-down camera shared by map rendering, cursor picking and zoom/pan input.
// Screen coordinates have their origin at the top left; world Z points upwards.
struct FsMapPreviewTransform
{
    int left=0,top=0,width=1,height=1;
    double cx=0.0,cy=0.0,cameraX=0.0,cameraY=1.0,cameraZ=0.0,projection=1.0;
    bool Contains(int x,int y) const
    {
        return left<=x && x<left+width && top<=y && y<top+height;
    }
    void Project(double &sx,double &sy,double x,double y,double z) const
    {
        const double depth=std::max(0.001,cameraY-y);
        sx=cx+(x-cameraX)*projection/depth;
        sy=cy-(z-cameraZ)*projection/depth;
    }
    void Unproject(double &x,double &z,double sx,double sy,double groundY) const
    {
        const double depth=std::max(0.001,cameraY-groundY);
        x=cameraX+(sx-cx)*depth/projection;
        z=cameraZ-(sy-cy)*depth/projection;
    }
};
#endif
