#include <ysclass.h>
#include <time.h>

#ifdef WIN32  // Assuming UNIX
#define _WINSOCKAPI_
#include <windows.h>
#else
#include <sys/time.h>
#endif



#include <ysbitmap.h>
#define FSSIMPLEWINDOW_DONT_INCLUDE_OPENGL_HEADERS
#include <fssimplewindow.h>

#include "fsoption.h"

#include "fs.h"
#include "fsgui.h"
#include <fsguicommondrawing.h>
#include "graphics/common/fsopengl.h"
#include "platform/common/fswindow.h"

#include "graphics/common/fstexturemanager.h"



#include "fsguiselectiondialogbase.h"

#include "fsfilename.h"

namespace
{
// Match the off-centre fixed-function frustum for renderers using an explicit matrix.
YsMatrix4x4 PreviewProjection(const FsProjection &prj)
{
    const double w=prj.viewportDim.xd(),h=prj.viewportDim.yd();
    YsMatrix4x4 mat;
    for(int row=1; row<=4; ++row)
    {
        for(int col=1; col<=4; ++col) mat.Set(row,col,0.0);
    }
    mat.Set(1,1,2.0*prj.prjPlnDist/w);
    mat.Set(2,2,2.0*prj.prjPlnDist/h);
    mat.Set(1,3,1.0-2.0*prj.cx/w);
    mat.Set(2,3,2.0*prj.cy/h-1.0);
    mat.Set(3,3,-(prj.farz+prj.nearz)/(prj.farz-prj.nearz));
    mat.Set(3,4,-2.0*prj.farz*prj.nearz/(prj.farz-prj.nearz));
    mat.Set(4,3,-1.0);
    return mat;
}
}

FsGuiDialogWithFieldAndAircraft::FsGuiDialogWithFieldAndAircraft()
{
    interactiveMapPreview=false;
    mapPreviewZoom=1.0;
    mapPreviewPan=YsOrigin();
	scn=new YsScenery;
	stpLoaded=YSFALSE;

	FsOption opt;
	opt.Load(FsGetOptionFile());
	useMapPreview=opt.useMapPreview;
}

FsGuiDialogWithFieldAndAircraft::~FsGuiDialogWithFieldAndAircraft()
{
	delete scn;
}


void FsGuiDialogWithFieldAndAircraft::GetPreviewArea(int &left,int &top,int &width,int &height,YSBOOL aircraft) const
{
    int w,h; FsGetWindowSize(w,h);
    left=YsSmaller(w-1,GetLeftX()+GetWidth()+24);
    width=YsGreater(1,w-left-20);
    const int split=h*43/100;
    top=(aircraft==YSTRUE ? 44 : split+46);
    height=YsGreater(1,(aircraft==YSTRUE ? split-56 : h-top-78));
}

FsMapPreviewTransform FsGuiDialogWithFieldAndAircraft::GetMapPreviewTransform(void) const
{
    FsMapPreviewTransform view;
    GetPreviewArea(view.left,view.top,view.width,view.height,YSFALSE);
    view.cx=view.left+view.width/2;
    view.cy=view.top+view.height/2;
    YsVec3 box[2];scn->GetBoundingBox(box);
    const auto centre=(box[0]+box[1])/2.0;
    const double extentX=YsGreater(100.0,box[1].x()-box[0].x());
    const double extentZ=YsGreater(100.0,box[1].z()-box[0].z());
    view.cameraX=centre.x()+mapPreviewPan.x();
    view.cameraZ=centre.z()+mapPreviewPan.z();
    view.cameraY=YsGreater(box[1].y()+1000.0,YsGreater(extentX,extentZ)*1.4);
    view.projection=mapPreviewZoom*YsSmaller(view.width*0.90*view.cameraY/extentX,view.height*0.90*view.cameraY/extentZ);
    return view;
}

bool FsGuiDialogWithFieldAndAircraft::PickMapPoint(YsVec3 &pos,int mx,int my) const
{
    const auto view=GetMapPreviewTransform();
    if(!view.Contains(mx,my)) return false;
    // Intersect the cursor ray with the height field. Bisection also works on slopes,
    // where repeatedly projecting onto the previous height can oscillate.
    YsVec3 bounds[2];scn->GetBoundingBox(bounds);
    double low=YsSmaller(0.0,bounds[0].y())-1.0;
    double high=YsSmaller(view.cameraY-0.001,YsGreater(0.0,bounds[1].y())+1.0);
    double x=0.0,z=0.0,elevation=0.0;
    for(int i=0;i<40;++i)
    {
        const double rayHeight=(low+high)/2.0;
        view.Unproject(x,z,mx,my,rayHeight);
        pos.Set(x,0.0,z);
        const YsSceneryItem *terrain=nullptr;
        elevation=scn->GetElevation(terrain,pos);
        if(rayHeight>elevation) high=rayHeight;
        else low=rayHeight;
    }
    view.Unproject(x,z,mx,my,(low+high)/2.0);
    pos.Set(x,elevation,z);
    return true;
}

void FsGuiDialogWithFieldAndAircraft::ResetMapPreview(void)
{
    mapPreviewZoom=1.0;mapPreviewPan=YsOrigin();
}

void FsGuiDialogWithFieldAndAircraft::ZoomMapPreview(double factor,int mx,int my)
{
    YsVec3 before;
    if(!PickMapPoint(before,mx,my)) return;
    mapPreviewZoom=YsBound(mapPreviewZoom*factor,0.5,64.0);
    const auto next=GetMapPreviewTransform();
    double x,z;next.Unproject(x,z,mx,my,before.y());
    mapPreviewPan.AddX(before.x()-x);
    mapPreviewPan.AddZ(before.z()-z);
    SetNeedRedraw(YSTRUE);
}

void FsGuiDialogWithFieldAndAircraft::PanMapPreview(int dx,int dy)
{
    const auto view=GetMapPreviewTransform();
    const double metresPerPixel=view.cameraY/view.projection;
    mapPreviewPan.AddX(-dx*metresPerPixel);
    mapPreviewPan.AddZ(dy*metresPerPixel);
    SetNeedRedraw(YSTRUE);
}

void FsGuiDialogWithFieldAndAircraft::ReloadField(FsWorld *world,const char fieldName[])
{
	if(fieldName!=NULL && fieldName[0]!=0)
	{
		ResetMapPreview();
		scn->Initialize();
		world->GetFieldVisual(*scn,fieldName);
		MakeMapVisibleDistanceAllInfinity();
	}
}

void FsGuiDialogWithFieldAndAircraft::ReloadStartPos(FsWorld *world,const char fieldName[],const char stpName[])
{
	if(fieldName!=NULL && fieldName[0]!=0 && stpName!=NULL && stpName[0]!=0)
	{
		FsStartPosInfo stpInfo;

		stpLoaded=YSFALSE;
		if(world->GetStartPositionInfo(stpInfo,fieldName,stpName)==YSOK)
		{
			if(stpInfo.onCarrier==YSTRUE)
			{
				if(scn!=NULL)
				{
					const YsSceneryGndObj *gob;
					YsMatrix4x4 mat(YSFALSE);

					gob=scn->SearchGndObjByTag(stpInfo.carrierTag);
					if(gob!=NULL && scn->GetTransformation(mat,gob)==YSOK)
					{
						stpPos=mat*stpInfo.relPosCarrier;

						YsVec3 ev,uv;
						ev=stpInfo.relAttCarrier.GetForwardVector();
						uv=stpInfo.relAttCarrier.GetUpVector();

						mat.Mul(ev,ev,0.0);
						mat.Mul(uv,uv,0.0);

						stpAtt.SetTwoVector(ev,uv);
						stpLoaded=YSTRUE;
					}
				}
			}
			else
			{
				if(stpInfo.InterpretPosition(stpPos,stpAtt)==YSOK)
				{
					stpLoaded=YSTRUE;
				}
			}
		}
	}
}

void FsGuiDialogWithFieldAndAircraft::MakeMapVisibleDistanceAllInfinity(void)
{
	YsArray <YsScenery *,16> todo;
	todo.Append(scn);
	for(int i=0; i<todo.GetN(); i++)
	{
		YsListItem <YsScenery2DDrawing> *map=NULL;
		while(NULL!=(map=todo[i]->FindNextMap(map)))
		{
			Ys2DDrawing *drw=&map->dat.GetDrawing();

			YsListItem <Ys2DDrawingElement> *elm=NULL;
			while(NULL!=(elm=drw->FindNextElem(elm)))
			{
				elm->dat.SetVisibleDist(YsInfinity);
			}
		}

		YsListItem <YsScenery> *chd=NULL;
		while(NULL!=(chd=todo[i]->FindNextChildScenery(chd)))
		{
			todo.Append(&chd->dat);
		}
	}
}

void FsGuiDialogWithFieldAndAircraft::DrawAirplane(FsWorld *world,const char typeName[],const YsAtt3 &att,YSSIZE_T nWpnCfg,const int *wpnCfg,YSBOOL smallMode) const
{
	const FsAirplaneTemplate *tmpl;
	FsVisualDnm vis;

	if((tmpl=world->GetAirplaneTemplate(typeName))!=NULL &&
	   (vis=world->GetAirplaneVisual(typeName))!=NULL)
	{
		FsAirplaneProperty prop;   // Be careful!  prop.belongTo will be NULL.
		YsVec3 pos;

		FsVisualDnm weaponShapeOverrideStatic[(int)FSWEAPON_NUMWEAPONTYPE];
		FsVisualDnm weaponShapeOverrideFlying[(int)FSWEAPON_NUMWEAPONTYPE];
		for(int i=0; i<(int)FSWEAPON_NUMWEAPONTYPE; i++)
		{
			weaponShapeOverrideStatic[i]=world->GetAirplaneWeaponShapeOverride(typeName,(FSWEAPONTYPE)i,0);
			weaponShapeOverrideFlying[i]=world->GetAirplaneWeaponShapeOverride(typeName,(FSWEAPONTYPE)i,1);
		}

		int wid,hei;
		FsGetWindowSize(wid,hei);


		for(int i=0; i<256; i++)
		{
			vis.SetState(i,0,0,0.0);
		}

		prop=*tmpl->GetProperty();

        // Fit every aircraft, including large bombers, in the available preview area.
        pos.Set(0.0,0.0,YsGreater(1.0,prop.GetOutsideRadius()*3.0));
		prop.SetPosition(pos);
		prop.SetAttitude(att);
		prop.ApplyWeaponConfig(nWpnCfg,wpnCfg);
		prop.SetupVisual(vis);

		YsVec3 lightEv(-2.0,-10.0,10.0);
		lightEv.Normalize();
		if(YSTRUE==FsIsShadowMapAvailable())
		{
			auto &commonTexture=FsCommonTexture::GetCommonTexture();
			commonTexture.ReadyShadowMap();

			for(int i=0; i<commonTexture.GetMaxNumShadowMap(); ++i)
			{
				auto texUnit=commonTexture.GetShadowMapTexture(i);
				if(nullptr!=texUnit)
				{
					// For mysterious reason, the following block doesn't even erase
					// the shadow map. >>
					YsProjectionTransformation proj;
					proj.SetProjectionMode(YsProjectionTransformation::ORTHOGONAL);
					proj.SetAspectRatio(1.0);
					proj.SetOrthogonalProjectionHeight((double)(i+1)*prop.GetOutsideRadius()*2.2);
					proj.SetNearFar(0.0,(double)(i+4)*prop.GetOutsideRadius()*2.2); // Dirty trick to reduce depth fighting problem in shadow buffer.
					auto projMat=proj.GetProjectionMatrix();

					YsAtt3 lightViewAtt;
					lightViewAtt.SetForwardVector(lightEv);
					lightViewAtt.SetB(0.0);
					auto lightOrigin=pos-lightEv*prop.GetOutsideRadius()*1.1;

					YsMatrix4x4 viewMat;
					viewMat.RotateXY(-lightViewAtt.b());
					viewMat.RotateZY(-lightViewAtt.p());
					viewMat.RotateXZ(-lightViewAtt.h());
					viewMat.Translate(-lightOrigin);

					auto texWid=texUnit->GetWidth();
					auto texHei=texUnit->GetHeight();

					texUnit->BindFrameBuffer();

					FsBeginRenderShadowMap(projMat,viewMat,texWid,texHei);

					// It was a tough problem to fix:
					//  (1) Draw(pos,att) was ignoring camera matrix.  Need to use DrawShadow and give viewMat.
					//      Left-Hand coordinate transformation is taken care all in the DrawShadow function.
					//  (2) FsBeginRenderShadowMap was not enabling DepthMask and DepthFunc.
					vis.DrawShadow(viewMat,projMat,pos,att,YsIdentity4x4());
					prop.DrawOrdinanceShadow(YSFALSE,weaponShapeOverrideStatic,viewMat,projMat,YsIdentity4x4());

					FsEndRenderShadowMap();

					texUnit->Bind(5+i);
					FsEnableShadowMap(YsIdentity4x4(),projMat,viewMat,5+i,0+i);
					// For mysterious reason, the above block doesn't even erase
					// the shadow map. <<
				}
			}
		}


		FsProjection prj;
		FsSimulation::GetStandardProjection(prj);
        const int previewLeft=YsSmaller(wid-1,GetLeftX()+GetWidth()+20);
        const int previewWidth=YsGreater(1,wid-previewLeft-16);
        prj.cx=previewLeft+previewWidth/2;
        prj.cy=(smallMode==YSTRUE ? hei/5 : hei/2);
        prj.prjPlnDist=3.0*YsSmaller(previewWidth*0.40,hei*(smallMode==YSTRUE ? 0.15 : 0.38));
        if(interactiveMapPreview && smallMode==YSTRUE)
        {
            int x,y,w,h;GetPreviewArea(x,y,w,h,YSTRUE);
            prj.cx=x+w/2;prj.cy=y+h/2;
            prj.prjPlnDist=3.0*YsSmaller(w*0.45,h*0.55);
            FsGuiCommonDrawing::SetClipRect(x,y,w,h);
        }
        const auto previewMatrix=PreviewProjection(prj);
		FsSetSceneProjection(prj);

		FsSetCameraPosition(YsOrigin(),YsZeroAtt(),YSTRUE);
		FsSetDirectionalLight(YsOrigin(),-lightEv,FSDAYLIGHT);

		vis.Draw(YsIdentity4x4(),previewMatrix,pos,att,YsVisual::DRAWOPAQUE);
		prop.DrawOrdinanceVisual(YSFALSE,weaponShapeOverrideStatic,YsIdentity4x4(),previewMatrix,YsVisual::DRAWOPAQUE);

		vis.Draw(YsIdentity4x4(),previewMatrix,pos,att,YsVisual::DRAWTRANSPARENT);
		prop.DrawOrdinanceVisual(YSFALSE,weaponShapeOverrideStatic,YsIdentity4x4(),previewMatrix,YsVisual::DRAWTRANSPARENT);

		FsFlushScene(); // BiFlushBuffer();

		FsSet2DDrawing();
        if(interactiveMapPreview && smallMode==YSTRUE) FsGuiCommonDrawing::ClearClipRect();
	}
}

void FsGuiDialogWithFieldAndAircraft::DrawField(FsWorld * /*world*/,YSBOOL /*drawStp*/,YSBOOL smallMode,YSBOOL drawCursor,const YsVec3 &cursorPos) const
{
	if(useMapPreview==YSTRUE && scn!=NULL)
	{
		int wid,hei;
		FsGetWindowSize(wid,hei);

		double l;
		YsVec3 bbx[2],satellite;
		YsAtt3 att;
		scn->GetBoundingBox(bbx);

		satellite=(bbx[0]+bbx[1])/2.0;
		l=YsGreater(1.0,(bbx[1]-bbx[0]).L0Norm());
		if(smallMode==YSTRUE)
		{
			l*=1.2;
		}

		satellite.SetY(l*1.4);
		att.Set(0.0,-YsPi/2.0,0.0);


        FsProjection prj;
        FsSimulation::GetStandardProjection(prj);
        prj.nearz=l;prj.farz=l*1.5;
        const int previewLeft=YsSmaller(wid-1,GetLeftX()+GetWidth()+20);
        const int previewWidth=YsGreater(1,wid-previewLeft-16);
        prj.cx=previewLeft+previewWidth/2;
        prj.cy=(smallMode==YSTRUE ? hei*2/3 : hei/2);
        prj.prjPlnDist=1.4*YsSmaller(previewWidth*0.78,hei*(smallMode==YSTRUE ? 0.48 : 0.82));
        if(interactiveMapPreview)
        {
            const auto mapView=GetMapPreviewTransform();
            satellite.Set(mapView.cameraX,mapView.cameraY,mapView.cameraZ);
            prj.cx=int(mapView.cx);prj.cy=int(mapView.cy);
            prj.prjPlnDist=mapView.projection;
            prj.nearz=1.0;prj.farz=mapView.cameraY+YsGreater(l,1000.0)*2.0;
            FsGuiCommonDrawing::SetClipRect(mapView.left,mapView.top,mapView.width,mapView.height);
        }
        YsMatrix4x4 viewMat;
        viewMat.RotateXY(-att.b());viewMat.RotateZY(-att.p());viewMat.RotateXZ(-att.h());viewMat.Translate(-satellite);
        const auto previewMatrix=PreviewProjection(prj);
        YsColor water=scn->GetGroundColor();
        if(interactiveMapPreview) water.SetIntRGB(30,66,88);
        FsDrawRect(0,0,wid-1,hei-1,water,YSTRUE);
		FsSetSceneProjection(prj);

		FsSetCameraPosition(satellite,att,YSTRUE);
		FsSetDirectionalLight(satellite,YsYVec(),FSDAYLIGHT);

		scn->DrawMapVisual(viewMat,YsIdentity4x4(),previewMatrix,-YsInfinity,YsInfinity,YSTRUE,0.0);
		scn->DrawVisual(viewMat,YsIdentity4x4(),previewMatrix,0.0,YSFALSE); // forShadowMap=YSFALSE

		if(stpLoaded==YSTRUE && !interactiveMapPreview)
		{
			YsVec3 p1,p2;
			p1=stpPos;
			p2=stpPos;
			p1.SubX(20000.0);
			p2.AddX(20000.0);
			FsDrawLine3d(p1,p2,YsWhite());

			p1=stpPos;
			p2=stpPos;
			p1.SubZ(20000.0);
			p2.AddZ(20000.0);
			FsDrawLine3d(p1,p2,YsWhite());
		}

		if(YSTRUE==drawCursor)
		{
			YsVec3 p1,p2;
			p1=cursorPos;
			p2=cursorPos;
			p1.SubX(20000.0);
			p2.AddX(20000.0);
			FsDrawLine3d(p1,p2,YsWhite());

			p1=cursorPos;
			p2=cursorPos;
			p1.SubZ(20000.0);
			p2.AddZ(20000.0);
			FsDrawLine3d(p1,p2,YsWhite());
		}

		FsFlushScene();

		FsSet2DDrawing();
        if(interactiveMapPreview)
        {
            if(stpLoaded==YSTRUE)
            {
                const auto view=GetMapPreviewTransform();
                const YsSceneryItem *terrain=nullptr;
                double sx,sy;
                view.Project(sx,sy,stpPos.x(),scn->GetElevation(terrain,stpPos),stpPos.z());
                FsDrawCircle(int(sx),int(sy),10,YsYellow(),YSFALSE);
                FsDrawLine(int(sx)-16,int(sy),int(sx)+16,int(sy),YsYellow());
                FsDrawLine(int(sx),int(sy)-16,int(sx),int(sy)+16,YsYellow());
            }
            FsGuiCommonDrawing::ClearClipRect();
        }
	}
}

void FsGuiDialogWithFieldAndAircraft::ResetFieldListBySearchKeyword(FsWorld *world,FsGuiListBox *fieldList,FsGuiTextBox *fieldSearch,YSBOOL forRacingMode)
{
	YsString curSel;
	YsArray <YsString,16> searchKeyWord;

	if(fieldList!=NULL)
	{
		fieldList->GetSelectedString(curSel);
	}

	YsString searchTxt;
	if(nullptr!=fieldSearch)
	{
		fieldSearch->GetText(searchTxt);
	}

	if(nullptr!=fieldList)
	{
		PopulateFieldList(world,fieldList,searchTxt,forRacingMode);
		if(0<curSel.Strlen())
		{
			YsString newCurSel;
			fieldList->SelectByString(curSel,YSTRUE);
			if(YSOK!=fieldList->GetSelectedString(newCurSel) || 0!=newCurSel.Strcmp(curSel))
			{
				FieldSelectionChanged();
			}
		}
	}
}

void FsGuiDialogWithFieldAndAircraft::FieldSelectionChanged(void)
{
}

void FsGuiDialogWithFieldAndAircraft::PopulateFieldList(FsWorld *world,FsGuiListBox *fieldList,const char keyword[],YSBOOL forRacingMode)
{
	YsArray <YsString> searchKeyWord;

	if(nullptr!=keyword && 0!=keyword[0])
	{
		YsString str(keyword);
		str.Capitalize();
		searchKeyWord=str.Argv();
	}


	YsArray <const char *> nameLst;
	const char *name;
	int i;
	for(i=0; (name=world->GetFieldTemplateName(i))!=NULL; i++)
	{
		if(0<searchKeyWord.size())
		{
			YsString cap(name);
			cap.Capitalize();
			if(FsTestKeyWordMatch(cap,searchKeyWord.GetN(),searchKeyWord)!=YSTRUE)
			{
				continue;
			}
		}
		if(YSTRUE==forRacingMode && YSTRUE!=world->IsFieldTemplateRaceCourseAvailable(i))
		{
			continue;
		}

		nameLst.Append(name);
	}

	if(0<nameLst.GetN() && nullptr!=fieldList)
	{
		fieldList->SetChoice(nameLst.GetN(),nameLst);
		fieldList->Select(0);
	}
}
