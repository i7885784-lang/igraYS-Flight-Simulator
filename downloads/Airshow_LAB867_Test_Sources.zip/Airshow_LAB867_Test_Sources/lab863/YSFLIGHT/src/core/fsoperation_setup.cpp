#include "fs.h"
#include "fsguinewflightdialog.h"
#include "fstextresource.h"
#include "graphics/common/fsopengl.h"
namespace
{
const wchar_t *T(const char *key,const wchar_t *fallback){return FsGetTextResource(key,fallback);}
}
void FsGuiNewFlightDialogClass::MakeOperationTab()
{
    const int tab=AddTab(mainTab,T("v8/planning",L"Orders"));BeginAddTabItem(mainTab,tab);
    const wchar_t *slots[]={T("v8/player",L"Player"),L"1",L"2",L"3",L"4",L"5",L"6",L"7",L"8",L"9",L"10"};
    const wchar_t *groups[]={L"1",L"2",L"3",L"4"};
    const wchar_t *tasks[]={T("v8/follow",L"Follow commander"),T("v8/wait",L"Wait / hover"),T("v8/route",L"Follow route"),T("v8/airattack",L"Attack air targets"),T("v8/groundattack",L"Attack ground targets")};
    AddStaticText(0,FSKEY_NULL,T("v8/editUnit",L"Configure unit"),YSTRUE);
    operationUnitChoice=AddDropList(MkId("opUnit"),FSKEY_NULL,L"",FsMaxShowAircraft,slots,FsMaxShowAircraft,10,10,YSFALSE);
    AddStaticText(0,FSKEY_NULL,T("v8/unitGroup",L"Group"),YSFALSE);
    operationGroupChoice=AddDropList(MkId("opGroup"),FSKEY_NULL,L"",4,groups,4,3,3,YSFALSE);
    operationTaskChoice=AddDropList(MkId("opTask"),FSKEY_NULL,T("v8/task",L"Initial order"),5,tasks,5,25,25,YSTRUE);
    operationHeight=AddTextBox(MkId("opHeight"),FSKEY_NULL,FsGuiTextBox::HORIZONTAL,T("v8/routeHeight",L"Route height AGL, m"),"150",5,YSTRUE);
    operationSpeed=AddTextBox(MkId("opSpeed"),FSKEY_NULL,FsGuiTextBox::HORIZONTAL,T("v8/routeSpeed",L"Route speed, km/h"),"90",5,YSFALSE);
    operationRouteEdit=AddTextButton(MkId("opRouteEdit"),FSKEY_NULL,FSGUI_CHECKBOX,T("v8/editRoute",L"Click map to add route points"),YSTRUE);
    operationRouteList=AddEmptyListBox(MkId("opRoute"),FSKEY_NULL,L"",4,40,YSTRUE);
    operationRouteClear=AddTextButton(MkId("opRouteClear"),FSKEY_NULL,FSGUI_PUSHBUTTON,T("v8/clearRoute",L"Clear route"),YSTRUE);
    AddStaticText(0,FSKEY_NULL,T("v8/transport",L"Transport to deliver troops"),YSTRUE);
    operationTransportChoice=AddDropList(MkId("opTransport"),FSKEY_NULL,L"",FsMaxShowAircraft,slots,FsMaxShowAircraft,10,10,YSFALSE);
    for(int i=0;i<4;++i)
    {
        YsString id;id.Printf("opName%d",i+1);YsString label;label.Printf("%d: ",i+1);
        operationGroupNames[i]=AddTextBox(MkId(id),FSKEY_NULL,FsGuiTextBox::HORIZONTAL,label.Txt(),"",18,i%2==0 ? YSTRUE : YSFALSE);
        operationGroupNames[i]->SetLengthLimit(24);
    }
    AddStaticText(0,FSKEY_NULL,T("v8/planningHint",L"Enable wingmen in their tab. Map orders can be changed during flight (F11)."),YSTRUE);
    EndAddTabItem();
    operationUnits.Clear();
    for(int slot=-1;slot<FsMaxPlayerWingmen;++slot){FsOperationUnit u;u.slot=slot;u.group=(slot<0 ? 1 : 2);u.task=(slot<0 ? 1 : 0);operationUnits.Append(u);}
    operationGroups[0].EncodeUTF8(T("v8/transportGroup",L"Transport"));operationGroups[1].EncodeUTF8(T("v8/strikeGroup",L"Strike"));
    operationGroups[2].EncodeUTF8(T("v8/coverGroup",L"Cover"));operationGroups[3].EncodeUTF8(T("v8/reserveGroup",L"Reserve"));
    operationUnitChoice->Select(0);operationTransportChoice->Select(0);operationEdit=-1;UpdateOperationControls();
}
void FsGuiNewFlightDialogClass::CaptureOperationControls()
{
    if(operationUnitChoice==nullptr)return;
    for(auto &u:operationUnits)if(u.slot==operationEdit)
    {
        u.group=YsBound(operationGroupChoice->GetSelection()+1,1,4);u.task=YsBound(operationTaskChoice->GetSelection(),0,4);
        u.height=YsBound(double(operationHeight->GetInteger()),30.0,10000.0);u.speed=YsBound(double(operationSpeed->GetInteger())/3.6,0.0,400.0);
    }
    operationTransport=operationTransportChoice->GetSelection()-1;
    for(int i=0;i<4;++i){operationGroups[i]=operationGroupNames[i]->GetString();operationGroups[i].Replace("\"","'");}
}
void FsGuiNewFlightDialogClass::UpdateOperationControls()
{
    if(operationUnitChoice==nullptr)return;
    for(auto &u:operationUnits)if(u.slot==operationEdit)
    {
        operationGroupChoice->Select(u.group-1);operationTaskChoice->Select(YsBound(u.task,0,4));operationHeight->SetInteger(int(u.height));operationSpeed->SetInteger(int(u.speed*3.6));
        operationRouteList->ClearChoice();int n=1;for(const auto &point:u.route){YsString row;row.Printf("%d: X %.0f / Z %.0f",n++,point.x(),point.z());operationRouteList->AddString(row,YSFALSE);}
    }
    for(int i=0;i<4;++i)operationGroupNames[i]->SetText(operationGroups[i]);
    SetNeedRedraw(YSTRUE);
}
void FsGuiNewFlightDialogClass::DrawOperationPreview() const
{
    const auto v=GetMapPreviewTransform();double x,y;v.Project(x,y,operationLanding.x(),operationLanding.y(),operationLanding.z());
    if(v.Contains(int(x),int(y))){FsDrawCircle(int(x),int(y),12,YsGreen(),YSFALSE);FsDrawString(int(x)+14,int(y),T("v8/lz",L"Landing zone"),YsGreen());}
    for(const auto &u:operationUnits)if(u.slot==operationEdit)
    {
        bool have=false;double px=0,py=0;int n=1;
        for(const auto &p:u.route)
        {
            v.Project(x,y,p.x(),0.0,p.z());if(v.Contains(int(x),int(y)))
            {if(have && v.Contains(int(px),int(py)))FsDrawLine(int(px),int(py),int(x),int(y),YsYellow());FsDrawCircle(int(x),int(y),5,YsYellow(),YSFALSE);YsString label;label.Printf("%d",n);FsDrawString(int(x)+7,int(y),label,YsYellow());}
            px=x;py=y;have=true;++n;
        }
    }
}
