#ifndef FSKEYBOARDAXIS_IS_INCLUDED
#define FSKEYBOARDAXIS_IS_INCLUDED
#include <algorithm>
#include <cmath>
struct FsKeyboardAxis
{
    static double Step(double value,bool positive,bool negative,double dt,double pressRate,double releaseRate)
    {
        if(!std::isfinite(value)) value=0.0;
        value=std::max(-1.0,std::min(1.0,value));
        if(!std::isfinite(dt) || dt<=0.0) return value;
        const double target=(positive==negative ? 0.0 : (positive ? 1.0 : -1.0));
        const double rate=(target==0.0 ? releaseRate : pressRate);
        const double distance=std::max(0.0,rate)*std::min(dt,1.0);
        if(value<target) return std::min(target,value+distance);
        if(value>target) return std::max(target,value-distance);
        return value;
    }
};
#endif
