#ifndef FSGROUPLAYOUT_IS_INCLUDED
#define FSGROUPLAYOUT_IS_INCLUDED
#include <cmath>
#include <limits>
#include <vector>
#include <functional>
constexpr int FsGroupPatternCount=10;
static const int FsGroupPatternIds[FsGroupPatternCount]={0,1,2,3,4,5,6,7,10,11};
inline bool FsGroupPatternAvailable(int id){for(auto p:FsGroupPatternIds)if(p==id)return true;return false;}
struct FsGroupOffset { double x,z,y;FsGroupOffset(double x=0.0,double z=0.0,double y=0.0):x(x),z(z),y(y){} };
inline FsGroupOffset FsGetGroupOffset(int pattern,int index,double spacing)
{
    static const int diamond[10][2]={{-1,-1},{1,-1},{0,-2},{-2,-2},{2,-2},{-1,-3},{1,-3},{0,-4},{-2,-4},{2,-4}};
    static const int delta[10][2]={{-1,-1},{1,-1},{-2,-2},{0,-2},{2,-2},{-3,-3},{-1,-3},{1,-3},{3,-3},{0,-4}};
    const int rank=index/2+1;FsGroupOffset p;
    switch(pattern)
    {
    case 0:p={double(diamond[index%10][0]),double(diamond[index%10][1])};break;
    case 1:p={double(delta[index%10][0]),double(delta[index%10][1])};break;
    case 2:p={double(index%2==0 ? -rank : rank),double(-rank)};break;
    case 3:p={0.0,double(-index-1)};break;
    case 4:p={double(index%2==0 ? -rank : rank),0.0};break;
    case 5:p={double(-index-1),double(-index-1)};break;
    case 6:p={double(index+1),double(-index-1)};break;
    case 7:p={0.0,double(-index-1),0.4*(index+1)};break;
    case 8:p={double(-index-1),double(-index-1),0.4*(index+1)};break;
    case 9:p={double(index+1),double(-index-1),0.4*(index+1)};break;
    case 10:{const int n=index+1,row=n/2;p={double(n%2)+0.5*(row%2),double(-row)};break;}
    case 11:p={double(index%2==0 ? -rank : rank),double(rank)};break;
    default:p={0.0,double(-index-1)};break;
    }
    p.x*=spacing;p.y*=spacing;p.z*=spacing;return p;
}
// Minimum total travel distance avoids assigning geometrically crossing routes.
// Aircraft identity, smoke colour and squad number stay with the same aircraft.
inline void FsAssignGroupSlots(int count,const FsGroupOffset current[],const FsGroupOffset target[],int assignment[])
{
 if(count<=0)return;
 // Legacy saves may contain more than the current eight-wingman UI limit.
 if(count>12)
 {
  std::vector<bool> used(count,false);
  for(int i=0;i<count;++i){double best=std::numeric_limits<double>::infinity();int selected=0;
   for(int j=0;j<count;++j)if(!used[j]){const double dx=current[i].x-target[j].x,dz=current[i].z-target[j].z,dy=current[i].y-target[j].y;const double d=dx*dx+dz*dz+dy*dy;if(d<best){best=d;selected=j;}}
   assignment[i]=selected;used[selected]=true;}return;
 }
 const int states=1<<count;std::vector<double> cost(states);std::vector<int> previous(states),chosen(states);
 for(int i=0;i<states;++i){cost[i]=std::numeric_limits<double>::infinity();previous[i]=-1;chosen[i]=-1;}cost[0]=0;
 for(int mask=0;mask<states;++mask)
 {
  int row=0;for(int bits=mask;bits;bits>>=1)row+=bits&1;if(row>=count)continue;
  for(int j=0;j<count;++j)if(!(mask&(1<<j)))
  {
   const double dx=current[row].x-target[j].x,dz=current[row].z-target[j].z,dy=current[row].y-target[j].y;
   const double next=cost[mask]+sqrt(dx*dx+dz*dz+dy*dy);const int dest=mask|(1<<j);
   if(next<cost[dest]){cost[dest]=next;previous[dest]=mask;chosen[dest]=j;}
  }
 }
 for(int row=count-1,mask=states-1;row>=0;--row){assignment[row]=chosen[mask];mask=previous[mask];}
}
inline double FsInferGroupSpacing(int count,const FsGroupOffset current[],double fallback)
{
 double outer=0;for(int i=0;i<count;++i)outer=fmax(outer,sqrt(current[i].x*current[i].x+current[i].y*current[i].y+current[i].z*current[i].z));
 for(auto pattern:FsGroupPatternIds)
 {
  double canonical=0;for(int i=0;i<count;++i){auto p=FsGetGroupOffset(pattern,i,1);canonical=fmax(canonical,sqrt(p.x*p.x+p.y*p.y+p.z*p.z));}
  if(canonical<1e-6)continue;const double scale=outer/canonical;bool match=scale>1;
  for(int i=0;i<count && match;++i)
  {
   auto p=FsGetGroupOffset(pattern,i,scale);bool found=false;
   for(int j=0;j<count;++j)if(fabs(p.x-current[j].x)<.02 && fabs(p.y-current[j].y)<.02 && fabs(p.z-current[j].z)<.02){found=true;break;}
   if(!found)match=false;
  }
  if(match)return scale;
 }
 return fallback;
}

inline std::vector<FsGroupOffset> FsCompactMain(int pattern,int count,double d)
{
 std::vector<FsGroupOffset> p;if(count<=0)return p;
 if(pattern==3 || pattern==5 || pattern==6 || pattern==7 || pattern==10 || count>=8)
 {for(int i=0;i<count;++i)p.push_back(FsGetGroupOffset(pattern,i,d));return p;}
 if(count%2)p.push_back({0,pattern==11 ? d:-d,0});
 int row=0;
 for(int i=0;int(p.size())<count && i<10;++i){auto a=FsGetGroupOffset(pattern,i,d);if(a.x>=0)continue;bool paired=false;for(int j=0;j<10;++j){auto b=FsGetGroupOffset(pattern,j,d);if(fabs(a.x+b.x)<.001 && fabs(a.z-b.z)<.001)paired=true;}if(!paired)continue;
  p.push_back(a);a.x=-a.x;p.push_back(a);++row;}
 return p;
}
inline std::vector<FsGroupOffset> FsCompactCover(int count,double d,double h)
{
 std::vector<FsGroupOffset> p;if(count%2)p.push_back({0,-d,h});
 for(int i=0;i<count/2;++i){const double z=-(i+1+(count%2))*d;p.push_back({-d*.5,z,h});p.push_back({d*.5,z,h});}return p;
}


// Fit the whole transfer, not just the final places. No plane may share an
// intermediate lane or reverse its order with another plane in that lane.
inline bool FsAssignCoverRoute(int n,const FsGroupOffset cur[],const FsGroupOffset target[],double height,double clearance,int result[],bool &along,double *retreat=nullptr)
{
 if(n<=0 || n>8)return false;
 for(int pass=0;pass<3;++pass)
 {
 const double shift=clearance*1.5*pass;std::vector<FsGroupOffset> work(cur,cur+n);for(auto &p:work)p.z-=shift;
 auto closest=[](double a,double b){return a*b<=0 ? 0.0:fmin(fabs(a),fabs(b));};
 bool clearRetreat=true;
 if(pass>0)for(int i=0;i<n;++i){const double z=closest(cur[i].z,work[i].z),y=closest(cur[i].y,height);if(cur[i].x*cur[i].x+z*z+y*y<clearance*clearance)clearRetreat=false;}
 if(!clearRetreat)continue;
 double best=1e100;bool found=false;std::vector<int> chosen(n,-1);std::vector<bool> used(n,false);
 for(bool axis:{true,false})
 {
  std::function<void(int,double)> search=[&](int row,double cost)
  {
   if(cost>=best)return;
   if(row==n){best=cost;found=true;along=axis;for(int i=0;i<n;++i)result[i]=chosen[i];return;}
   for(int j=0;j<n;++j)if(!used[j])
   {
    const double ix=axis ? work[row].x:target[j].x,iz=axis ? target[j].z:work[row].z;
    if(ix*ix+iz*iz+height*height<clearance*clearance)continue;
    const double nearFirst=axis ? work[row].x*work[row].x+pow(closest(work[row].z,target[j].z),2) : work[row].z*work[row].z+pow(closest(work[row].x,target[j].x),2);
    const double nearSecond=axis ? target[j].z*target[j].z+pow(closest(work[row].x,target[j].x),2) : target[j].x*target[j].x+pow(closest(work[row].z,target[j].z),2);
    if(fmin(nearFirst,nearSecond)+height*height<clearance*clearance)continue;
    bool safe=true;
    for(int k=0;k<row && safe;++k)
    {
     const auto q=target[chosen[k]];
     const double kx=axis ? work[k].x:q.x,kz=axis ? q.z:work[k].z;
     if((ix-kx)*(ix-kx)+(iz-kz)*(iz-kz)<clearance*clearance-.001){safe=false;break;}
     const double fixed1=axis ? work[row].x-work[k].x:work[row].z-work[k].z;
     const double start1=axis ? work[row].z-work[k].z:work[row].x-work[k].x;
     const double end1=axis ? target[j].z-q.z:target[j].x-q.x;
     const double fixed2=axis ? target[j].z-q.z:target[j].x-q.x;
     const double start2=axis ? work[row].x-work[k].x:work[row].z-work[k].z;
     const double end2=axis ? target[j].x-q.x:target[j].z-q.z;
     if((fabs(fixed1)<clearance && start1*end1<-.001) || (fabs(fixed2)<clearance && start2*end2<-.001))safe=false;
    }
    if(!safe)continue;
    const double dx=work[row].x-target[j].x,dz=work[row].z-target[j].z;
    chosen[row]=j;used[j]=true;search(row+1,cost+dx*dx+dz*dz);used[j]=false;
   }
  };
  search(0,0);
 }
 if(found){if(retreat)*retreat=shift;return true;}
 }
 return false;
}
#endif
