#include "fsweaponlaunchpolicy.h"
#include <ysclass.h>
#define FSSIMPLEWINDOW_DONT_INCLUDE_OPENGL_HEADERS
#include <fssimplewindow.h>
#include "fs.h"
#include "fstextresource.h"
#include "fsairsound.h"
#include "graphics/common/fsopengl.h"
#include "graphics/common/fsfontrenderer.h"
namespace
{
bool AirMissile(FSWEAPONTYPE t){return t==FSWEAPON_AIM9 || t==FSWEAPON_AIM9X || t==FSWEAPON_AIM120;}
YsColor LockColor(int r,int g,int b){YsColor c;c.SetIntRGB(r,g,b);return c;}
}
void FsSimulation::UpdatePlayerMissileLock(const double /*dt*/)
{
    auto player=GetPlayerAirplane();if(nullptr==player || YSTRUE==player->isPlayingRecord)return;
    const auto weapon=player->Prop().GetWeaponOfChoice();
    auto target=FindAirplane(player->Prop().GetAirTargetKey());
    bool valid=AirMissile(weapon) && player->Prop().GetNumWeapon(weapon)>0 && YSTRUE==player->IsAlive() &&
        nullptr!=target && YSTRUE==target->IsAlive() && target->iff!=player->iff;
    if(valid)
    {
        YsVec3 relative;player->GetAttitude().MulInverse(relative,target->GetPosition()-player->GetPosition());
        const double angle=atan2(relative.GetLengthXY(),relative.z());
        const double range=player->Prop().GetAAMRange(weapon)*target->Prop().GetRadarCrossSection();
        valid=relative.z()>0.0 && angle<=YsDegToRad(10.0) && relative.GetSquareLength()<=range*range;
    }
    const auto candidate=valid ? FsExistence::GetSearchKey(target) : YSNULLHASHKEY;
    // Use simulation time: opening the command wheel or pressing Pause cannot earn lock time.
    const double elapsed=(playerLockLastTime>=0.0 ? YsBound(currentTime-playerLockLastTime,0.0,0.25) : 0.0);
    if(!valid || candidate!=playerLockCandidate || weapon!=playerLockWeapon)
    {
        playerLockSeconds=0.0;playerLockReady=false;
    }
    else playerLockSeconds=YsSmaller(3.0,playerLockSeconds+elapsed);
    const bool newlyReady=valid && playerLockSeconds>=3.0 && !playerLockReady;
    playerLockCandidate=candidate;playerLockWeapon=weapon;playerLockLastTime=currentTime;
    playerLockReady=valid && playerLockSeconds>=3.0;
    player->Prop().SetAirTargetKey(playerLockReady ? candidate : YSNULLHASHKEY);
    if(newlyReady)
    {
        FsSoundSetOneTime(FSSND_ONETIME_NOTICE);
    }
}
bool FsSimulation::PlayerMissileLaunchAllowed(FSWEAPONTYPE type) const
{
    if(!AirMissile(type))return true;
    const auto player=GetPlayerAirplane();
    if(nullptr==player || YSTRUE==player->isPlayingRecord)return true;
    const auto target=FindAirplane(playerLockCandidate);
    if(!playerLockReady || playerLockWeapon!=type || nullptr==target || YSTRUE!=player->IsAlive() ||
       YSTRUE!=target->IsAlive() || target->iff==player->iff || player->Prop().GetWeaponOfChoice()!=type ||
       player->Prop().GetAirTargetKey()!=playerLockCandidate)return false;
    YsVec3 relative;player->GetAttitude().MulInverse(relative,target->GetPosition()-player->GetPosition());
    const double range=player->Prop().GetAAMRange(type)*target->Prop().GetRadarCrossSection();
    return relative.z()>0.0 && atan2(relative.GetLengthXY(),relative.z())<=YsDegToRad(10.0) &&
        relative.GetSquareLength()<=range*range;
}
void FsSimulation::DrawPlayerMissileLock() const
{
    const auto player=GetPlayerAirplane();if(nullptr==player || YSTRUE==player->isPlayingRecord || squadWheelOpen)return;
    const auto type=player->Prop().GetWeaponOfChoice();if(!AirMissile(type))return;
    int w,h;FsGetWindowSize(w,h);const int width=YsSmaller(460,w-40),left=(w-width)/2,top=h-112;
    const YsColor color=playerLockReady ? LockColor(70,245,145) : LockColor(255,195,65);
    FsDrawRect(left-10,top-9,left+width+10,top+79,LockColor(8,17,28),YSTRUE);
    const wchar_t *status;
    if(player->Prop().GetNumWeapon(type)<=0)status=FsGetTextResource("v7/noMissiles",L"No selected missiles remaining");
    else if(playerLockCandidate==YSNULLHASHKEY)status=FsGetTextResource("v7/findTarget",L"Aim at an enemy aircraft - launch blocked");
    else if(playerLockReady)status=FsGetTextResource("v7/lockReady",L"LOCKED - missile launch enabled");
    else status=FsGetTextResource("v7/acquiring",L"Acquiring target - hold aim for 3 seconds");
    FsDrawString(left,top,status,color);
    FsDrawRect(left,top+30,left+width,top+43,LockColor(80,105,125),YSFALSE);
    const int filled=int((width-4)*YsBound(playerLockSeconds/3.0,0.0,1.0));
    if(filled>0)FsDrawRect(left+2,top+32,left+2+filled,top+41,color,YSTRUE);
    YsString narrow;narrow.Printf("%s  %.1f / 3.0",type==FSWEAPON_AIM120 ? "AIM-120" : type==FSWEAPON_AIM9X ? "AIM-9X" : "AIM-9",playerLockSeconds);YsWString detail;detail.SetUTF8String(narrow);
    FsDrawString(left,top+51,detail,YsWhite());
}

bool FsWeaponOwnerIsPlayer(const FsSimulation *sim,const FsExistence *owner)
{
    return nullptr!=sim && nullptr!=owner && owner==sim->GetPlayerAirplane();
}
bool FsAllowPlayerWeaponLaunch(const FsSimulation *sim,const FsExistence *owner,FSWEAPONTYPE weapon)
{
    return !FsWeaponOwnerIsPlayer(sim,owner) || sim->PlayerMissileLaunchAllowed(weapon);
}
