#ifndef FSAFTERBURNERVISUAL_IS_INCLUDED
#define FSAFTERBURNERVISUAL_IS_INCLUDED
#include <cmath>
#include <cstring>
struct FsAfterburnerVisual
{
    static bool RealEngineAllowsFlame(const char *identifier)
    {
        // The stock AMX definition incorrectly advertises an afterburner.
        // Its Rolls-Royce Spey 807 has no reheat. This corrects visuals only.
        return nullptr!=identifier && 0!=std::strcmp(identifier,"AMX");
    }
    static bool Visible(bool jet,bool helicopter,bool equipped,bool activated,bool active,bool powerLoss,double fuel,double throttle)
    {
        return jet && !helicopter && equipped && activated && active && !powerLoss && fuel>1e-6 && throttle>0.01;
    }
    static double Length(double throttle,double time)
    {
        throttle=throttle<0.0 ? 0.0 : (throttle>1.0 ? 1.0 : throttle);
        return (0.40+1.20*throttle)*(0.98+0.02*std::sin(37.0*time));
    }
};
#endif
