#ifndef FSWEAPONLAUNCHPOLICY_IS_INCLUDED
#define FSWEAPONLAUNCHPOLICY_IS_INCLUDED
#include "fsdef.h"
class FsSimulation;
class FsExistence;
// Implemented in the simulation layer; vehicle code needs no simulation internals.
bool FsWeaponOwnerIsPlayer(const FsSimulation *sim,const FsExistence *owner);
bool FsAllowPlayerWeaponLaunch(const FsSimulation *sim,const FsExistence *owner,FSWEAPONTYPE weapon);
#endif
