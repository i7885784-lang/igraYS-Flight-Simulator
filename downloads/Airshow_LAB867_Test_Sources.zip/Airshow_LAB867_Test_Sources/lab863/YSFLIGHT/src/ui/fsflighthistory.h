#ifndef FSFLIGHTHISTORY_IS_INCLUDED
#define FSFLIGHTHISTORY_IS_INCLUDED
#include <vector>
#include <string>
#include <ysclass.h>
class FsWorld;
struct FsFlightHistoryEntry
{
    std::string id,date,field,aircraft;
    YsWString start,record;
    bool hasRecord=false;
};
class FsFlightHistory
{
public:
    static YsWString Directory();
    static std::vector<FsFlightHistoryEntry> List();
    static YsWString LatestStart();
    static bool Begin(FsWorld &world,YsWString &activeStart);
    static bool Finish(FsWorld &world,const YsWString &activeStart);
    static bool ImportPrevious();
};
#endif
