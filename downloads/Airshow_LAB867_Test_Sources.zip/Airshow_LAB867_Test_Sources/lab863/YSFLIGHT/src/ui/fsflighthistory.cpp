#include "fsflighthistory.h"
#include "fsworld.h"
#include "fsfilename.h"
#include <ysport.h>
#include <algorithm>
#include <ctime>
#include <cstdio>
#include <cstring>
#ifdef _WIN32
#include <windows.h>
#endif
namespace
{
YsWString Path(const YsWString &dir,const std::string &name)
{
    YsWString leaf,out;leaf.SetUTF8String(name.c_str());out.MakeFullPathName(dir,leaf);return out;
}
bool Commit(const YsWString &temporary,const YsWString &dest)
{
#ifdef _WIN32
    return 0!=MoveFileExW(temporary,dest,MOVEFILE_REPLACE_EXISTING|MOVEFILE_WRITE_THROUGH);
#else
    YsString a,b;YsUnicodeToSystemEncoding(a,temporary);YsUnicodeToSystemEncoding(b,dest);
    return 0==rename(a,b);
#endif
}
bool Copy(const YsWString &source,const YsWString &dest)
{
    YsFileIO::File in(source,"rb");if(nullptr==in)return false;
    YsWString tmp=dest;tmp.Append(L".tmp");
    FILE *out=YsFileIO::Fopen(tmp,"wb");if(nullptr==out)return false;
    char buf[65536];size_t n;bool ok=true;
    while(0<(n=fread(buf,1,sizeof(buf),in)))if(n!=fwrite(buf,1,n,out)){ok=false;break;}
    if(ferror(in))ok=false;
    if(0!=fclose(out))ok=false;
    return ok && Commit(tmp,dest);
}
bool Save(FsWorld &world,const YsWString &dest)
{
    YsWString tmp=dest;tmp.Append(L".tmp");
    return YSOK==world.Save(tmp,6,8,6,8,6,8,0.0) && Commit(tmp,dest);
}
std::string NewId()
{
    time_t t=time(nullptr);tm local=*localtime(&t);char base[40];strftime(base,sizeof(base),"%Y%m%d-%H%M%S",&local);
    for(unsigned int i=0;i<100000;++i)
    {
        char id[64];snprintf(id,sizeof(id),"%s-%05u",base,i);
        if(YSTRUE!=YsFileIO::CheckFileExist(Path(FsFlightHistory::Directory(),std::string(id)+".start.yfs")))return id;
    }
    return "";
}
FsFlightHistoryEntry Describe(const YsWString &start,const std::string &id)
{
    FsFlightHistoryEntry e;e.id=id;e.start=start;e.record=Path(FsFlightHistory::Directory(),id+".record.yfs");
    e.hasRecord=(YSTRUE==YsFileIO::CheckFileExist(e.record));
    e.date=id.size()>=15 ? id.substr(0,4)+"-"+id.substr(4,2)+"-"+id.substr(6,2)+" "+id.substr(9,2)+":"+id.substr(11,2)+":"+id.substr(13,2) : id;
    YsFileIO::File in(start,"r");char line[4096],name[1024],player[32];
    if(nullptr!=in)while(nullptr!=fgets(line,sizeof(line),in))
    {
        if(1==sscanf(line,"FIELDNAM %1023s",name))e.field=name;
        if(2==sscanf(line,"AIRPLANE %1023s %31s",name,player) && 0==strcmp(player,"TRUE"))e.aircraft=name;
        if(2==sscanf(line,"GROUNDOB %1023s %31s",name,player) && 0==strcmp(player,"TRUE"))e.aircraft=name;
    }
    if(e.field.empty())e.field="?";if(e.aircraft.empty())e.aircraft="?";
    return e;
}
void WriteInfo(const FsFlightHistoryEntry &e)
{
    auto name=Path(FsFlightHistory::Directory(),e.id+".info");YsWString tmp=name;tmp.Append(L".tmp");
    FILE *fp=YsFileIO::Fopen(tmp,"w");if(nullptr==fp)return;
    const bool ok=0<fprintf(fp,"%s\n%s\n%s\n",e.date.c_str(),e.field.c_str(),e.aircraft.c_str());
    const int closed=fclose(fp);if(ok && 0==closed)Commit(tmp,name);
}
std::string Line(FILE *fp)
{
    char s[4096];if(nullptr==fgets(s,sizeof(s),fp))return "";
    std::string out=s;while(!out.empty() && (out.back()=='\n' || out.back()=='\r'))out.pop_back();return out;
}
}
YsWString FsFlightHistory::Directory()
{
    YsWString dir;dir.MakeFullPathName(FsGetUserYsflightDir(),L"FlightHistory");YsFileIO::MkDir(dir);return dir;
}
std::vector<FsFlightHistoryEntry> FsFlightHistory::List()
{
    std::vector<FsFlightHistoryEntry> out;YsFileList files;
    files.FindFileList(Directory(),nullptr,L".start.yfs");
    for(int i=0;i<files.GetN();++i)
    {
        if(YSTRUE==files.IsDirectory(i))continue;
        YsString name;name.EncodeUTF8(files.GetFileName(i));std::string id=name.Txt();id.resize(id.size()-10);
        FsFlightHistoryEntry e;e.id=id;e.start=files.GetFileNameW(i);e.record=Path(Directory(),id+".record.yfs");
        e.hasRecord=(YSTRUE==YsFileIO::CheckFileExist(e.record));
        YsFileIO::File info(Path(Directory(),id+".info"),"r");
        if(nullptr!=info){e.date=Line(info);e.field=Line(info);e.aircraft=Line(info);}
        if(e.date.empty() || e.field.empty() || e.aircraft.empty()){e=Describe(e.start,id);WriteInfo(e);}
        out.push_back(e);
    }
    std::sort(out.begin(),out.end(),[](const FsFlightHistoryEntry &a,const FsFlightHistoryEntry &b){return a.id>b.id;});return out;
}
YsWString FsFlightHistory::LatestStart()
{
    // prevflight is updated only at actual takeoff, never by browsing history.
    if(YSTRUE==YsFileIO::CheckFileExist(FsGetPrevFlightFile()))return YsWString(FsGetPrevFlightFile());
    auto list=List();return list.empty() ? YsWString() : list.front().start;
}
bool FsFlightHistory::ImportPrevious()
{
    if(!List().empty() || YSTRUE!=YsFileIO::CheckFileExist(FsGetPrevFlightFile()))return true;
    const auto id=NewId();if(id.empty())return false;
    auto path=Path(Directory(),id+".start.yfs");if(!Copy(YsWString(FsGetPrevFlightFile()),path))return false;
    WriteInfo(Describe(path,id));return true;
}
bool FsFlightHistory::Begin(FsWorld &world,YsWString &activeStart)
{
    if(!ImportPrevious())return false;
    const auto id=NewId();if(id.empty())return false;
    auto path=Path(Directory(),id+".start.yfs");
    if(!Save(world,path))return false;
    WriteInfo(Describe(path,id));
    // Archive is already safe if updating the compatibility file fails.
    if(!Copy(path,YsWString(FsGetPrevFlightFile())))return false;
    activeStart=path;return true;
}
bool FsFlightHistory::Finish(FsWorld &world,const YsWString &activeStart)
{
    if(0==activeStart.Strlen())return true;
    YsWString dest=activeStart;dest.DeleteRange(dest.Strlen()-10,10);dest.Append(L".record.yfs");
    return Save(world,dest);
}
