#define FSSIMPLEWINDOW_DONT_INCLUDE_OPENGL_HEADERS
#include <fssimplewindow.h>
#include <fsgui.h>
#include <ysport.h>
#include "fsguimaincanvas.h"
#include "fsflighthistory.h"
#include <algorithm>
#include <cctype>
#include <set>
namespace
{
const wchar_t *T(const char *key,const wchar_t *fallback){return FsGetTextResource(key,fallback);}
std::string Lower(std::string s){for(auto &c:s)c=static_cast<char>(tolower(static_cast<unsigned char>(c)));return s;}
class FlightBrowser : public FsGuiDialog
{
public:
    std::vector<FsFlightHistoryEntry> entries;
    std::vector<int> visible;
    FsGuiListBox *list;
    FsGuiTextBox *search;
    FsGuiDropList *field,*aircraft,*type;
    FsGuiButton *load,*watch,*cancel,*external;
    FsGuiStatic *status;
    YsWString selected;
    void Make()
    {
        SetIdent("flightHistory");
        SetTextMessage(T("v6/history",L"My flights"));
        FsFlightHistory::ImportPrevious();entries=FsFlightHistory::List();
        search=AddTextBox(MkId("search"),FSKEY_NULL,FsGuiTextBox::HORIZONTAL,T("v6/search",L"Search (date, map, aircraft)"),L"",36,YSTRUE);
        const wchar_t *all[]={T("v6/all",L"All")};
        AddStaticText(0,FSKEY_NULL,T("v6/field",L"Map"),YSTRUE);
        field=AddDropList(MkId("fieldFilter"),FSKEY_NULL,T("v6/field",L"Map"),1,all,7,20,20,YSFALSE);
        AddStaticText(0,FSKEY_NULL,T("v6/aircraft",L"Aircraft"),YSFALSE);
        aircraft=AddDropList(MkId("aircraftFilter"),FSKEY_NULL,T("v6/aircraft",L"Aircraft"),1,all,7,24,24,YSFALSE);
        const wchar_t *types[]={T("v6/all",L"All"),T("v6/recorded",L"With replay"),T("v6/startonly",L"Starting setup only")};
        AddStaticText(0,FSKEY_NULL,T("v6/type",L"Show"),YSTRUE);
        type=AddDropList(MkId("recordFilter"),FSKEY_NULL,T("v6/type",L"Show"),3,types,3,24,24,YSFALSE);
        std::set<std::string> maps,planes;
        for(const auto &e:entries){maps.insert(e.field);planes.insert(e.aircraft);}
        for(const auto &s:maps)field->AddString(s.c_str(),YSFALSE);
        for(const auto &s:planes)aircraft->AddString(s.c_str(),YSFALSE);
        field->Select(0);aircraft->Select(0);type->Select(0);
        list=AddEmptyListBox(MkId("flights"),FSKEY_NULL,T("v6/columns",L"Date / Map / Aircraft   (newest first)"),10,76,YSTRUE);
        status=AddStaticText(0,FSKEY_NULL,L"",76,2,YSTRUE);
        load=AddTextButton(MkId("load"),FSKEY_NULL,FSGUI_PUSHBUTTON,T("v6/load",L"Select for flight"),YSTRUE);
        watch=AddTextButton(MkId("watch"),FSKEY_NULL,FSGUI_PUSHBUTTON,T("v6/watch",L"Watch replay"),YSFALSE);
        cancel=AddTextButton(MkId("cancel"),FSKEY_ESC,FSGUI_PUSHBUTTON,FSGUI_COMMON_CANCEL,YSFALSE);
        external=AddTextButton(MkId("external"),FSKEY_NULL,FSGUI_PUSHBUTTON,T("v6/external",L"Open older .yfs file..."),YSTRUE);
        AddStaticText(0,FSKEY_NULL,T("v6/hint",L"Automatic saving on this device. Select a setup, then press Fly Now on the main screen."),YSTRUE);
        SetTransparency(YSFALSE);SetBackgroundAlpha(0.98);Refresh();Fit();
    }
    void Refresh()
    {
        const auto query=Lower(search->GetString().Txt());
        const std::string map=field->GetSelectedString().Txt(),plane=aircraft->GetSelectedString().Txt();
        visible.clear();list->ClearChoice();
        for(int i=0;i<(int)entries.size();++i)
        {
            const auto &e=entries[i];
            if(field->GetSelection()>0 && e.field!=map)continue;
            if(aircraft->GetSelection()>0 && e.aircraft!=plane)continue;
            if(type->GetSelection()==1 && !e.hasRecord)continue;
            if(type->GetSelection()==2 && e.hasRecord)continue;
            const auto text=e.date+"  |  "+e.field+"  |  "+e.aircraft;
            if(!query.empty() && Lower(text).find(query)==std::string::npos)continue;
            visible.push_back(i);list->AddString(text.c_str(),YSFALSE);
        }
        if(!visible.empty())list->Select(0);
        UpdateSelection();SetNeedRedraw(YSTRUE);
    }
    void UpdateSelection()
    {
        const int n=list->GetSelection();
        if(n<0 || n>=(int)visible.size())
        {
            load->Disable();watch->Disable();status->SetText(T("v6/empty",L"No matching flights. Your next flight will be saved here automatically."));
        }
        else
        {
            load->Enable();const auto &e=entries[visible[n]];
            if(e.hasRecord)watch->Enable();else watch->Disable();
            status->SetText(e.hasRecord ? T("v6/available",L"Starting setup and replay are available.") : T("v6/norecord",L"Starting setup is available. No completed replay for this flight."));
        }
    }
    virtual void OnButtonClick(FsGuiButton *btn)
    {
        if(btn==cancel){CloseModalDialog(0);return;}
        if(btn==external){CloseModalDialog(3);return;}
        const int n=list->GetSelection();if(n<0 || n>=(int)visible.size())return;
        const auto &e=entries[visible[n]];
        if(btn==load){selected=e.start;CloseModalDialog(1);}
        else if(btn==watch && e.hasRecord){selected=e.record;CloseModalDialog(2);}
    }
    virtual void OnListBoxSelChange(FsGuiListBox *,int){UpdateSelection();}
    virtual void OnTextBoxChange(FsGuiTextBox *){Refresh();}
    virtual void OnDropListSelChange(FsGuiDropList *,int){Refresh();}
};
}
void FsGuiMainCanvas::OpenFlightHistory(FsGuiPopUpMenuItem *)
{
    auto dlg=FsGuiDialog::CreateSelfDestructiveDialog<FlightBrowser>();dlg->Make();
    dlg->BindCloseModalCallBack(&THISCLASS::FlightHistorySelected,this);AttachModalDialog(dlg);
}
void FsGuiMainCanvas::FlightHistorySelected(FsGuiDialog *closed,int code)
{
    auto dlg=dynamic_cast<FlightBrowser *>(closed);if(nullptr==dlg || 0==code)return;
    if(3==code)
    {
        auto file=FsGuiDialog::CreateSelfDestructiveDialog<FsGuiFileDialog>();file->Initialize();
        file->mode=FsGuiFileDialog::MODE_OPEN;file->title.Set(T("v6/external",L"Open older .yfs file..."));
        file->fileExtensionArray.Append(L".yfs");
        file->defaultFileName.MakeFullPathName(FsGetUserYsflightDir(),L"*.yfs");
        file->BindCloseModalCallBack(&THISCLASS::File_Open_FileSelected,this);AttachModalDialog(file);return;
    }
    // Validate before replacing the current world; Cancel never changes it.
    YsFileIO::File test(dlg->selected,"r");YsString first;
    if(nullptr==test || nullptr==first.Fgets(test) || YSTRUE!=first.DOESSTARTWITH("YFSVERSI"))
    {
        StartMessageBox(FSGUI_COMMON_ERROR,FSGUI_FILEDLG_CANNOT_LOAD_FILE,FSGUI_COMMON_OK,nullptr,0,0);return;
    }
    if(!runLoop->SavePendingFlightHistory())return;
    auto world=runLoop->GetWorld();world->TerminateSimulation();
    if(YSOK!=world->Load(dlg->selected))
    {
        StartMessageBox(FSGUI_COMMON_ERROR,FSGUI_FILEDLG_CANNOT_LOAD_FILE,FSGUI_COMMON_OK,nullptr,0,0);return;
    }
    readiness=SIMULATION_INITIAL;
    if(2==code)Sim_ReplayRecord(nullptr);
}
