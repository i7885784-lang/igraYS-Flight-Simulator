#define FSSIMPLEWINDOW_DONT_INCLUDE_OPENGL_HEADERS
#include <fssimplewindow.h>
#include <fsgui.h>
#include "fs.h"
#include "fsguimaincanvas.h"
#include "fsmissiongoal.h"
#include "fsoperation.h"
namespace
{
const wchar_t *T(const char *k,const wchar_t *s){return FsGetTextResource(k,s);}
class MissionList : public FsGuiDialog
{
public:
    FsGuiButton *prepare,*cancel;
    void Make()
    {
        SetIdent("missionsDlg");SetTextMessage(T("v8/missions",L"Missions"));
        AddStaticText(0,FSKEY_NULL,T("v8/missionTitle",L"GUARDED LANDING ZONE"),YSTRUE);
        AddStaticText(0,FSKEY_NULL,T("v8/missionDescription",L"Clear the defence. Deliver the transport helicopter to the marked zone.\nKeep it on the ground for 8 seconds. Losing it or your aircraft means defeat."),YSTRUE);
        AddStaticText(0,FSKEY_NULL,T("v8/missionDifficulty",L"Easy operation | 1 defended landing zone | configure aircraft, groups and routes"),YSTRUE);
        prepare=AddTextButton(MkId("prepare"),FSKEY_NULL,FSGUI_PUSHBUTTON,T("v8/prepare",L"Prepare operation"),YSTRUE);
        cancel=AddTextButton(MkId("cancel"),FSKEY_ESC,FSGUI_PUSHBUTTON,FSGUI_COMMON_CANCEL,YSFALSE);
        SetTransparency(YSFALSE);Fit();
    }
    virtual void OnButtonClick(FsGuiButton *b){if(b==prepare)CloseModalDialog(1);if(b==cancel)CloseModalDialog(0);}
};
void AircraftDefaults(FsWorld &world,FsNewFlightAirplaneData &data,const char *name)
{
    data.typeName=name;data.fuel=75;
    if(auto tmpl=world.GetAirplaneTemplate(name))tmpl->GetProperty()->GetWeaponConfig(data.weaponConfig);
}
YsVec3 LandingSite(FsWorld &world)
{
    FsStartPosInfo pos;YsVec3 result(45000,0,-14000);YsAtt3 att;
    if(world.GetStartPositionInfo(pos,"AOMORI","MISAWA_RW28")==YSOK)pos.InterpretPosition(result,att);
    result.SetY(world.GetFieldElevation(result.x(),result.z()));return result;
}
}
void FsGuiMainCanvas::OpenMissions(FsGuiPopUpMenuItem *)
{
    if(!runLoop->SavePendingFlightHistory())return;
    auto dlg=FsGuiDialog::CreateSelfDestructiveDialog<MissionList>();dlg->Make();
    dlg->BindCloseModalCallBack(&THISCLASS::MissionChosen,this);AttachModalDialog(dlg);
}
void FsGuiMainCanvas::MissionChosen(FsGuiDialog *,int code)
{
    if(code!=1)return;
    auto world=runLoop->GetWorld();FsNewFlightDialogOption option;
    option.operationSetup=true;option.canSelectField=YSFALSE;option.canSelectStartPosition=YSFALSE;
    option.canSelectWingmen=YSTRUE;option.canChooseFomType=YSTRUE;option.flyNowButton=YSTRUE;
    option.fieldName="AOMORI";option.aircraftName="UH-60_BLACKHAWK";option.startPosName="MISAWA_RW10";
    auto dlg=FsGuiDialog::CreateSelfDestructiveDialog<FsGuiNewFlightDialogClass>();dlg->InitialSetUp(option);dlg->Make(world);
    FsFlightConfig cfg;cfg.Load(FsGetConfigFile());FsNewFlightDialogInfo info;info.SetFromConfig(world,cfg);info.SetFromOption(option);
    info.addComputerAircraft=YSFALSE;info.separateWingmanStarts=YSFALSE;
    info.groupAirStart=YSTRUE;info.groupHeight=180;info.groupHeading=0;info.groupSpeed=0;info.groupSpacing=90;
    AircraftDefaults(*world,info.playerAirInfo,"UH-60_BLACKHAWK");
    for(int i=0;i<2;++i){info.wingman[i]=YSTRUE;AircraftDefaults(*world,info.wingmanInfo[i],"AH-64_APACHE");}
    dlg->InitializeDialog(world,info);dlg->customStartAllowed=true;
    dlg->groupStartCheck->SetCheck(YSTRUE);dlg->groupHeightBox->SetInteger(180);dlg->groupSpacingBox->SetInteger(90);
    dlg->separateStartsCheck->Disable();dlg->addComputerAircraft->SetCheck(YSFALSE);dlg->addComputerAircraft->Disable();
    dlg->operationLanding=LandingSite(*world);dlg->UpdateStartControls();dlg->UpdateGroupControls();dlg->UpdateWingmanControls();
    dlg->SetTextMessage(T("v8/prepareTitle",L"Operation preparation: guarded landing zone"));
    dlg->BindCloseModalCallBack(&THISCLASS::MissionSetupSelected,this);AttachModalDialog(dlg);
}
void FsGuiMainCanvas::MissionSetupSelected(FsGuiDialog *closed,int code)
{
    auto dlg=dynamic_cast<FsGuiNewFlightDialogClass *>(closed);if(dlg==nullptr || code!=YSOK)return;
    dlg->CaptureOperationControls();auto world=runLoop->GetWorld();auto &info=dlg->info;
    const int transportSlot=dlg->operationTransport;
    const auto &data=(transportSlot<0 ? info.playerAirInfo : info.wingmanInfo[YsBound(transportSlot,0,FsNewFlightDialogInfo::MaxNumWingman-1)]);
    auto tmpl=world->GetAirplaneTemplate(data.typeName);
    if((transportSlot>=0 && info.wingman[transportSlot]!=YSTRUE) || tmpl==nullptr || (0!=data.typeName.Strcmp("UH-60_BLACKHAWK") && 0!=data.typeName.Strcmp("UH-60J_BLACKHAWK") && 0!=data.typeName.Strcmp("V-107")))
    {StartMessageBox(FSGUI_COMMON_ERROR,T("v8/transportError",L"Choose an enabled helicopter as transport in Orders, then prepare the mission again."),FSGUI_COMMON_OK,nullptr,0,0);return;}
    // Create the starting world first; do not launch before attaching mission state.
    const bool fly=info.flyImmediately==YSTRUE;info.flyImmediately=YSFALSE;
    info.fieldName="AOMORI";info.addComputerAircraft=YSFALSE;info.separateWingmanStarts=YSFALSE;
    info.groupAirStart=YSTRUE;info.groupHeight=YsBound(info.groupHeight,80.0,1000.0);
    Sim_CreateFlight_Create(info);auto sim=world->GetSimulation();if(sim==nullptr || sim->GetPlayerAirplane()==nullptr)return;
    auto op=std::make_shared<FsSimExtension_Operation>();op->landing=LandingSite(*world);op->rally=sim->GetPlayerAirplane()->GetPosition();
    op->rally.SetY(world->GetFieldElevation(op->rally.x(),op->rally.z()));op->transportSlot=transportSlot;
    for(int i=0;i<4;++i)op->groupName[i]=dlg->operationGroups[i];
    for(const auto &unit:dlg->operationUnits)if(unit.slot<0 || info.wingman[unit.slot]==YSTRUE)op->units.Append(unit);
    auto transport=op->Aircraft(sim,transportSlot);if(transport!=nullptr)transport->name="OP_TRANSPORT";
    // Stock scenery contains unrelated combat vehicles. They are scenery here;
    // only authored operation defenders are active enemies.
    for(auto g=sim->FindNextGround(nullptr);g!=nullptr;g=sim->FindNextGround(g))
    {g->iff=FS_IFF0;g->SendCommand("INITIGUN 0");g->SendCommand("INITISAM 0");}
    // An actual native anti-aircraft gun, with a short engagement range for the first mission.
    auto guard=world->AddGround("AAA",YSFALSE);
    if(guard==nullptr){StartMessageBox(FSGUI_COMMON_ERROR,L"Cannot load AAA defence.",FSGUI_COMMON_OK,nullptr,0,0);return;}
    guard->iff=FS_IFF1;guard->name="OP_AAA_1";
    YsVec3 position=op->landing+YsVec3(320,0,220);position.SetY(world->GetFieldElevation(position.x(),position.z()));
    world->SettleGround(*guard,position);guard->SendCommand("GUNRANGE 900m");guard->SendCommand("INITIGUN 1200");guard->SendCommand("INITISAM 0");
    op->defenders.Append(guard->name);
    sim->RegisterExtension(op);sim->SetSimulationTitle("Guarded Landing Zone");
    FsMissionGoal goal;goal.SendCommand("MSSNGOAL SURVIVE",L"");goal.SendCommand("MSSNGOAL DESTROYGND OP_AAA_1",L"");
    goal.SendCommand("MSSNGOAL MUSTLAND OP_TRANSPORT",L"");goal.SendCommand("MSSNGOAL DEFAIR OP_TRANSPORT",L"");
    goal.SendCommand("MSSNGOAL ITEXT en \"Destroy the anti-aircraft defence, then land the transport in the green zone for 8 seconds. Enter: commands; F11: tactical map.\"",L"");
    goal.SendCommand("MSSNGOAL ITEXT ru \"Уничтожьте зенитную охрану. Посадите транспорт в зелёной зоне на 8 секунд. Enter: круг команд; F11: карта операции.\"",L"");
    sim->SetMissionGoal(goal);readiness=SIMULATION_INITIAL;
    if(fly)Sim_Fly(nullptr);
}
