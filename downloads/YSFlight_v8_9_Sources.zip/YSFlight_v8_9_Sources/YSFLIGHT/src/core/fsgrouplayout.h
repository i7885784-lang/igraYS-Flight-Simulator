#ifndef FSGROUPLAYOUT_IS_INCLUDED
#define FSGROUPLAYOUT_IS_INCLUDED
#include <cmath>
#include <limits>
#include <vector>
constexpr int FsGroupPatternCount=10;
static const int FsGroupPatternIds[FsGroupPatternCount]={0,1,2,3,4,5,6,7,10,11};
inline bool FsGroupPatternAvailable(int id){for(auto p:FsGroupPatternIds)if(p==id)return true;return false;}
struct FsGroupOffset { double x,z,y;FsGroupOffset(double x=0.0,double z=0.0,double y=0.0):x(x),z(z),y(y){} };
inline FsGroupOffset FsGetGroupOffset(int pattern,int index,double spacing)
{
    static const int diamond[10][2]={{-1,-1},{1,-1},{0,-2},{-2,-2},{2,-2},{-1,-3},{1,-3},{0,-4},{-2,-4},{2,-4}};
    static const int delta[10][2]={{-1,-1},{1,-1},{-2,-2},{0,-2},{2,-2},{-3,-3},{-1,-3},{1,-3},{3,-3},{0,-4}};
    const int rank=index/2+1;FsGroupOffset p;
    switch(pattern)
    {
    case 0:p={double(diamond[index%10][0]),double(diamond[index%10][1])};break;
    case 1:p={double(delta[index%10][0]),double(delta[index%10][1])};break;
    case 2:p={double(index%2==0 ? -rank : rank),double(-rank)};break;
    case 3:p={0.0,double(-index-1)};break;
    case 4:p={double(index%2==0 ? -rank : rank),0.0};break;
    case 5:p={double(-index-1),double(-index-1)};break;
    case 6:p={double(index+1),double(-index-1)};break;
    case 7:p={0.0,double(-index-1),0.4*(index+1)};break;
    case 8:p={double(-index-1),double(-index-1),0.4*(index+1)};break;
    case 9:p={double(index+1),double(-index-1),0.4*(index+1)};break;
    case 10:{const int n=index+1,row=n/2;p={double(n%2)+0.5*(row%2),double(-row)};break;}
    case 11:p={double(index%2==0 ? -rank : rank),double(rank)};break;
    default:p={0.0,double(-index-1)};break;
    }
    p.x*=spacing;p.y*=spacing;p.z*=spacing;return p;
}
// Minimum total travel distance avoids assigning geometrically crossing routes.
// Aircraft identity, smoke colour and squad number stay with the same aircraft.
inline void FsAssignGroupSlots(int count,const FsGroupOffset current[],const FsGroupOffset target[],int assignment[])
{
 if(count<=0)return;
 // Legacy saves may contain more than the current eight-wingman UI limit.
 if(count>12)
 {
  std::vector<bool> used(count,false);
  for(int i=0;i<count;++i){double best=std::numeric_limits<double>::infinity();int selected=0;
   for(int j=0;j<count;++j)if(!used[j]){const double dx=current[i].x-target[j].x,dz=current[i].z-target[j].z,dy=current[i].y-target[j].y;const double d=dx*dx+dz*dz+dy*dy;if(d<best){best=d;selected=j;}}
   assignment[i]=selected;used[selected]=true;}return;
 }
 const int states=1<<count;std::vector<double> cost(states);std::vector<int> previous(states),chosen(states);
 for(int i=0;i<states;++i){cost[i]=std::numeric_limits<double>::infinity();previous[i]=-1;chosen[i]=-1;}cost[0]=0;
 for(int mask=0;mask<states;++mask)
 {
  int row=0;for(int bits=mask;bits;bits>>=1)row+=bits&1;if(row>=count)continue;
  for(int j=0;j<count;++j)if(!(mask&(1<<j)))
  {
   const double dx=current[row].x-target[j].x,dz=current[row].z-target[j].z,dy=current[row].y-target[j].y;
   const double next=cost[mask]+sqrt(dx*dx+dz*dz+dy*dy);const int dest=mask|(1<<j);
   if(next<cost[dest]){cost[dest]=next;previous[dest]=mask;chosen[dest]=j;}
  }
 }
 for(int row=count-1,mask=states-1;row>=0;--row){assignment[row]=chosen[mask];mask=previous[mask];}
}
// Compact a live subset as a complete shape, never as a list with a missing slot.
inline std::vector<FsGroupOffset> FsPackedMainOffsets(int pattern,int count,double spacing)
{
 std::vector<FsGroupOffset> result;
 if(count<=0)return result;
 if(count>=8 || pattern==3 || pattern==5 || pattern==6 || pattern==7 || pattern==10)
 {
  for(int i=0;i<count;++i)result.push_back(FsGetGroupOffset(pattern,i,spacing));
  if(pattern==10 && count<8 && (count+1)%2==1){auto &last=result.back();last.x+=spacing*0.5;}
  return result;
 }
 if(count==1){result.push_back({0.0,pattern==11 ? spacing:-spacing});return result;}
 std::vector<FsGroupOffset> pairs,centres;
 for(int i=0;i<10;++i)
 {
  auto p=FsGetGroupOffset(pattern,i,spacing);
  if(fabs(p.x)<1e-6){centres.push_back(p);continue;}
  if(p.x>0)continue;
  for(int j=0;j<10;++j){auto q=FsGetGroupOffset(pattern,j,spacing);if(fabs(p.x+q.x)<.001 && fabs(p.z-q.z)<.001 && fabs(p.y-q.y)<.001){pairs.push_back(p);break;}}
 }
 auto length=[](const FsGroupOffset &p){return p.x*p.x+p.y*p.y+p.z*p.z;};
 for(int i=0;i<int(pairs.size());++i)for(int j=i+1;j<int(pairs.size());++j)if(length(pairs[j])<length(pairs[i])){auto p=pairs[i];pairs[i]=pairs[j];pairs[j]=p;}
 for(int i=0;i<count/2;++i)
 {auto p=pairs[i%pairs.size()];result.push_back(p);p.x=-p.x;result.push_back(p);}
 if(count%2)
 {if(centres.empty())result.push_back({0.0,pattern==11 ? spacing:-spacing});else result.push_back(centres.front());}
 return result;
}
// Cover is a separate element: pairs, or a three-aircraft front element plus pairs.
// Offsets are x,z,y.  The player remains below and ahead of this upper group.
inline std::vector<FsGroupOffset> FsPackedCoverOffsets(int /*pattern*/,int count,double spacing,double height)
{
 std::vector<FsGroupOffset> result;if(count<=0)return result;
 if(count%2)
 {
  result.push_back({0,-spacing,height});
  for(int row=0;row<count/2;++row)
  {result.push_back({-spacing,-(row+2)*spacing,height});result.push_back({spacing,-(row+2)*spacing,height});}
 }
 else for(int row=0;row<count/2;++row)
 {result.push_back({-spacing*.5,-(row+1)*spacing,height});result.push_back({spacing*.5,-(row+1)*spacing,height});}
 return result;
}
inline double FsInferGroupSpacing(int count,const FsGroupOffset current[],double fallback,int *matchedPattern=nullptr)
{
 double outer=0;for(int i=0;i<count;++i)outer=fmax(outer,sqrt(current[i].x*current[i].x+current[i].y*current[i].y+current[i].z*current[i].z));
 for(auto pattern:FsGroupPatternIds)
 {
  double canonical=0;for(int i=0;i<count;++i){auto p=FsGetGroupOffset(pattern,i,1);canonical=fmax(canonical,sqrt(p.x*p.x+p.y*p.y+p.z*p.z));}
  if(canonical<1e-6)continue;const double scale=outer/canonical;bool match=scale>1;
  for(int i=0;i<count && match;++i)
  {
   auto p=FsGetGroupOffset(pattern,i,scale);bool found=false;
   for(int j=0;j<count;++j)if(fabs(p.x-current[j].x)<.02 && fabs(p.y-current[j].y)<.02 && fabs(p.z-current[j].z)<.02){found=true;break;}
   if(!found)match=false;
  }
  if(match){if(matchedPattern)*matchedPattern=pattern;return scale;}
 }
 return fallback;
}
#endif
