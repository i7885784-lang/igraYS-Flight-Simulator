import metrics
import json,math
from pathlib import Path
s=Path('/workspace/ysflight-work/turn-study')
results=[]
for p in sorted(s.glob('*.rows.json')):
 d=metrics.analyze(p);units=json.loads(p.read_text());leader=units[0]['rows'];start=d['start'];minimum=1e9;maxspeed=0;join=None
 for k,a in enumerate(leader):
  if a['time']<start:continue
  rows=[u['rows'][k] for u in units if len(u['rows'])>k]
  for i,x in enumerate(rows):
   for y in rows[:i]:minimum=min(minimum,math.dist([x[c] for c in ['x','y','z']],[y[c] for c in ['x','y','z']]))
 for u in units[1:]:
  a=[a for a in u['rows'] if start<=a['time']<=start+max(x['time'] or 120 for x in d['units'])]
  for x,y in zip(a,a[1:]):maxspeed=max(maxspeed,3.6*math.dist([x[c] for c in ['x','y','z']],[y[c] for c in ['x','y','z']])/(y['time']-x['time']))
 errors=[]
 for k,a in enumerate(leader):
  if a['time']<start:continue
  err=[]
  for i,u in enumerate(units[1:]):
   b=u['rows'][min(k,len(u['rows'])-1)];dist=50*(i+1);goal=(a['x']+math.sin(a['h'])*dist,a['y'],a['z']-math.cos(a['h'])*dist)
   err.append(math.dist(goal,[b[c] for c in ['x','y','z']]))
  errors.append((a['time']-start,max(err)))
 # First time after which all remain within 15m, at least two seconds of subsequent recording.
 for j,(t,e) in enumerate(errors):
  if t>max(x['time'] or 120 for x in d['units']) and errors[-1][0]-t>=2 and all(x[1]<=15 for x in errors[j:]):join=t;break
 d.update(clearance=minimum,maxspeed=maxspeed,regroup=join,errors=errors,alive=all(x['state'] not in [3,4,5,7] for u in units for x in u['rows'] if x['time']>start));results.append(d)
 print(p.name,'last turn',round(max(x['time'] or 120 for x in d['units']),2),'join',join,'min gap',round(minimum,1),'speed',round(maxspeed),'alive',d['alive'])
(s/'results.json').write_text(json.dumps(results,indent=2))
