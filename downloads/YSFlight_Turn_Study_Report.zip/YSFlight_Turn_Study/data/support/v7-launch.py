from pathlib import Path
import os,sys,subprocess,time,shutil,signal
r=Path('/workspace/ysflight-work');env=os.environ.copy();env['LD_LIBRARY_PATH']=str(r/'toolchain/usr/lib/x86_64-linux-gnu')
if len(sys.argv)>2 and sys.argv[2]=='xvfb':
 p=subprocess.Popen([str(r/'toolchain/usr/bin/Xvfb'),':99','-screen','0','1920x1080x24','-ac','-nolisten','tcp'],env=env,stdout=(r/'v7-xvfb.log').open('w'),stderr=subprocess.STDOUT,start_new_session=True);(r/'v7-xvfb.pid').write_text(str(p.pid));time.sleep(.5)
if (r/'v7-validation.pid').exists():
 pid=int((r/'v7-validation.pid').read_text())
 try:os.kill(pid,signal.SIGTERM);time.sleep(.3)
 except ProcessLookupError:pass
run=r/'run64-centered';shutil.copy2(r/'build64/main/ysflight64_gl1.exe',run/'ysflight64_gl1.exe')
for lang in ['en','ru']:shutil.copy2(r/f'YSFLIGHT/runtime/language/{lang}.uitxt',run/f'language/{lang}.uitxt')
env.update(DISPLAY=':99',WINEPREFIX=str(r/'wine-prefix'),WINEDEBUG='-all',LIBGL_ALWAYS_SOFTWARE='1')
p=subprocess.Popen([str(r/'wine-10.0-amd64-wow64/bin/wine64'),str(run/'ysflight64_gl1.exe'),'-userdir','Z:/workspace/ysflight-work/'+os.environ.get('V7_TEST_USER','v7-user'),'-configdir','Z:/workspace/ysflight-work/'+os.environ.get('V7_TEST_USER','v7-user')+'/config','-script','Z:/workspace/ysflight-work/'+sys.argv[1]],cwd=run,env=env,stdout=(r/('v7-'+sys.argv[1]+'.log')).open('w'),stderr=subprocess.STDOUT,start_new_session=True);(r/'v7-validation.pid').write_text(str(p.pid));print('Launched',p.pid)
