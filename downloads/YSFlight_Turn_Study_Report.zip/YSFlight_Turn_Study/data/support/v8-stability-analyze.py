from pathlib import Path
import re,json,math,sys
r=Path('/workspace/ysflight-work')
def read_record(path):
 units=[]
 for b in re.split(r'(?m)^AIRPLANE ',Path(path).read_text())[1:]:
  h=re.search(r'NUMRECOR (\d+) (\d+)\n',b)
  if not h:continue
  n,cols=int(h[1]),int(h[2]);assert cols==4
  lines=b[h.end():].splitlines();rows=[]
  for k in range(n):
   row=lines[k*4:k*4+4];v=list(map(float,row[1].split()));rows.append(dict(time=float(row[0]),x=v[0],y=v[1],z=v[2],h=v[3],pitch=v[4],bank=v[5],state=int(row[2].split()[0])))
  slot=re.search(r'REM V7SQUAD (\d+) (\d+)',b);mode=re.search(r'FOMSTATE (\w+)',b)
  units.append(dict(player=b.splitlines()[0].split()[1]=='TRUE',slot=int(slot[2]) if slot else None,mode=mode[1] if mode else None,rows=rows))
 return units
if __name__=='__main__':
 units=read_record(sys.argv[1]);followers=[u for u in units if u['slot'] is not None];data=[]
 for u in followers:
  rows=u['rows'];data.append(dict(slot=u['slot'],records=len(rows),min_altitude=min(x['y'] for x in rows),max_bank_degrees=max(abs(math.degrees(x['bank'])) for x in rows),max_pitch_degrees=max(abs(math.degrees(x['pitch'])) for x in rows),states_after_start=sorted(set(x['state'] for x in rows if x['time']>.05)),final_mode=u['mode'],final=rows[-1]))
 assert len(data)==int(sys.argv[2]) and all(x['states_after_start']==[0] for x in data),data
 result=dict(passed=True,duration=data[0]['final']['time'],wingmen=data)
 Path(sys.argv[3]).write_text(json.dumps(result,indent=2));print('PASS',len(data),'aircraft,',result['duration'],'s, min height',min(x['min_altitude'] for x in data),'m; modes',[x['final_mode'] for x in data])
