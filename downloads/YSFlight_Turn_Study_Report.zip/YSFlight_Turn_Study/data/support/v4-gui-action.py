from pathlib import Path
import os,subprocess,time,sys
from PIL import ImageGrab
r=Path('/workspace/ysflight-work');env=dict(os.environ,DISPLAY=':99');env['PATH']=str(r/'toolchain/usr/bin')+':'+env['PATH'];env['LD_LIBRARY_PATH']=str(r/'toolchain/usr/lib/x86_64-linux-gnu')
def command(*args):subprocess.run(['xdotool',*map(str,args)],env=env,check=True,stdout=subprocess.DEVNULL)
def click(x,y):command('mousemove',x,y,'mousedown',1);time.sleep(.14);command('mouseup',1);time.sleep(.35)
def key(k):command('key',k);time.sleep(.35)
def typetext(t):command('type','--delay',120,t);time.sleep(.4)
def screenshot(name):ImageGrab.grab(xdisplay=':99').save(r/name)
if __name__=='__main__':
 if sys.argv[1]=='click':click(int(sys.argv[2]),int(sys.argv[3]))
 elif sys.argv[1]=='key':key(sys.argv[2])
 elif sys.argv[1]=='text':typetext(sys.argv[2])
 if len(sys.argv)>4:screenshot(sys.argv[4])
