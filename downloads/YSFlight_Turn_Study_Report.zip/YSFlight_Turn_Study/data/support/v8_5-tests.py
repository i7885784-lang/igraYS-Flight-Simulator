from pathlib import Path
import subprocess,os,time,re,json,shutil,importlib.machinery,math,sys
r=Path('/workspace/ysflight-work');out=r/'v8_5-validation';out.mkdir(exist_ok=True)
u=importlib.machinery.SourceFileLoader('u',str(r/'v4-gui-action.py')).load_module();parser=importlib.machinery.SourceFileLoader('rec',str(r/'v8-stability-analyze.py')).load_module()
env=dict(os.environ,WINEPREFIX=str(r/'wine-prefix'),WINEDEBUG='-all',DISPLAY=':99',LD_LIBRARY_PATH=str(r/'toolchain/usr/lib/x86_64-linux-gnu'))
wine=str(r/'wine-10.0-amd64-wow64/bin/wine64')
profile=os.environ.get('V85_TEST_USER','v8_5-user')
def window(action):
 x=subprocess.run([wine,str(r/'v8_5-window-test.exe'),action],cwd=r,env=env,capture_output=True,text=True,timeout=12)
 if x.returncode:raise RuntimeError('Window helper '+action+' '+x.stderr[-100:])
 return json.loads(x.stdout.strip().splitlines()[-1])
def write_result(name,checks,**details):
 data=dict(passed=all(checks.values()),checks=checks,**details);(out/(name+'.json')).write_text(json.dumps(data,indent=2));print(name,json.dumps(data),flush=True);assert data['passed'],name
prefix='WAITFOR:GUI\nSLEEP:500\n'+'GUI:CLOSEMODAL\n'*4
fixture='Z:/workspace/ysflight-work/v8_3-baseline-mig50.yfs'
def launch(name,script):
 filename='v8_5-'+name+'-script.txt';(r/filename).write_text(script);started=time.time()
 subprocess.run(['python',str(r/'v7-launch.py'),filename],env=dict(os.environ,V7_TEST_USER=profile),check=True)
 deadline=time.monotonic()+20
 while True:
  try:info=window('info');break
  except Exception:
   if time.monotonic()>deadline:raise
   time.sleep(.3)
 window('resize');return started,info,r/('v7-'+filename+'.log')
def wait(log,needle,timeout=300):
 deadline=time.monotonic()+timeout
 while time.monotonic()<deadline:
  text=log.read_text(errors='replace') if log.exists() else ''
  if needle in text:return text
  time.sleep(.3)
 raise RuntimeError('Timed out '+str(log)+' '+needle)
def finish(name,started,log):
 time.sleep(.3);u.screenshot('v8_5-'+name+'.png');u.command('search','--name','YS FLIGHT','windowfocus','--sync');u.key('alt+F4');time.sleep(1)
 records=[p for p in (r/profile/'FlightHistory').glob('*.record.yfs') if p.stat().st_mtime>started]
 if records:shutil.copy2(max(records,key=lambda p:p.stat().st_mtime),out/(name+'.record.yfs'))
 shutil.copy2(log,out/(name+'.log'));return log.read_text(errors='replace')
def report_times(text):return list(map(float,re.findall(r'V7REPORT time=([\d.]+)',text)))
def common_record(name,expected=8):
 units=parser.read_record(out/(name+'.record.yfs'));followers=[x for x in units if not x['player']];lead=next(x for x in units if x['player']);minimum=1e9
 for k,l in enumerate(lead['rows']):
  rows=[l]+[f['rows'][min(k,len(f['rows'])-1)] for f in followers]
  for i,a in enumerate(rows):
   for b in rows[:i]:minimum=min(minimum,math.sqrt(sum((a[c]-b[c])**2 for c in ['x','y','z'])))
 return dict(eight_wingmen=len(followers)==expected,wingmen_survive=all(v['state']==0 for f in followers for v in f['rows'] if v['time']>.1),physical_clearance=minimum>20),minimum,units

def resume():
 script=prefix+f'FILE:OPEN {fixture}\nGUI:CLICK mainDlg flyNow\nWAITFOR:FLYING\nWAITFOR:SIMTIME 8\nFLIGHTCMD:REPORT\nRAWKEY:ESC\nSLEEP:300\nRAWKEY:ESC\nWAITFOR:GUI\nSLEEP:1200\nGUI:CLICK mainDlg flyNow\nWAITFOR:FLYING\nFLIGHTCMD:REPORT\nWAITFOR:SIMTIME 11\nFLIGHTCMD:REPORT\nBTNFUNC:PAUSESIMULATION\n'
 started,info,log=launch('resume',script);text=wait(log,'Script>>BTNFUNC:PAUSESIMULATION');finish('resume',started,log)
 times=report_times(text);pauses=list(map(float,re.findall(r'V85PAUSE time=([\d.]+)',text)));resumes=list(map(float,re.findall(r'V85RESUME time=([\d.]+)',text)))
 checks,minimum,units=common_record('resume');checks.update(start_maximized=info['maximized']==1,three_reports=len(times)==3,clock_not_reset=len(times)==3 and len(resumes)==1 and times[1]>=times[0] and 0<=times[1]-resumes[0]<.2,exact_suspended_clock=len(pauses)==1 and pauses==resumes,keyboard_default='V85INPUT keyboard=1 arrow_up=1 arrow_left=1' in text)
 write_result('resume',checks,clock_reports=times,pause_clock=pauses,resume_clock=resumes,start_window=info,minimum_distance=minimum)

def focus():
 script=prefix+f'FILE:OPEN {fixture}\nGUI:CLICK mainDlg flyNow\nWAITFOR:FLYING\nWAITFOR:SIMTIME 3\nFLIGHTCMD:REPORT\nWAITFOR:GUI\nSLEEP:2500\nGUI:CLICK mainDlg flyNow\nWAITFOR:FLYING\nFLIGHTCMD:REPORT\nSLEEP:500\nFLIGHTCMD:REPORT\nWAITFOR:GUI\nSLEEP:2500\nGUI:CLICK mainDlg flyNow\nWAITFOR:FLYING\nFLIGHTCMD:REPORT\nSLEEP:500\nFLIGHTCMD:REPORT\nBTNFUNC:PAUSESIMULATION\n'
 started,info,log=launch('focus',script);wait(log,'V7REPORT time=3');window('steal');wait(log,'V85RESUME');
 while len(report_times(log.read_text(errors='replace')))<3:time.sleep(.2)
 window('minimize');text=wait(log,'Script>>BTNFUNC:PAUSESIMULATION');finish('focus',started,log)
 pauses=list(map(float,re.findall(r'V85PAUSE time=([\d.]+)',text)));resumes=list(map(float,re.findall(r'V85RESUME time=([\d.]+)',text)));times=report_times(text)
 checks,minimum,_=common_record('focus');checks.update(two_focus_pauses=len(pauses)==2,two_resumes=len(resumes)==2,clock_frozen_in_both=pauses==resumes and len(pauses)==2,no_reset=len(times)==5 and times[1]>=times[0] and times[3]>=times[2])
 write_result('focus',checks,pause_clock=pauses,resume_clock=resumes,reports=times,minimum_distance=minimum)

def scatter():
 script=prefix+f'FILE:OPEN {fixture}\nGUI:CLICK mainDlg flyNow\nWAITFOR:FLYING\nFLIGHTCMD:SQUAD 103\nWAITFOR:SIMTIME 5\nFLIGHTCMD:SQUAD 2\nWAITFOR:SIMTIME 35\nFLIGHTCMD:REPORT\nWAITFOR:SIMTIME 40\nFLIGHTCMD:SQUAD 1\nWAITFOR:SIMTIME 120\nFLIGHTCMD:REPORT\nBTNFUNC:PAUSESIMULATION\n'
 started,_,log=launch('scatter',script);text=wait(log,'Script>>BTNFUNC:PAUSESIMULATION',450);finish('scatter',started,log)
 checks,minimum,_=common_record('scatter');reports=text.split('V7REPORT ')[1:];first=reports[0];last=reports[-1];starts=[(float(t),int(i)) for t,i in re.findall(r'V82BREAK start time=([\d.]+) slot=(\d+)',text)];returns=[float(t) for t in re.findall(r'V82BREAK return time=([\d.]+)',text)]
 firsttasks=re.findall(r'V7MEMBER .*task=(\d+) autopilot=(\d+)',first);lasttasks=re.findall(r'V7MEMBER .*task=(\d+) autopilot=(\d+)',last);errors=list(map(float,re.findall(r'V7MEMBER .*error=([\d.]+)',last)))
 checks.update(sequential_departures=[i for t,i in starts]==list(range(8)),no_auto_return_before_recall=len(returns)==8 and min(returns)>=40,outgoing_independent=len(firsttasks)==8 and all(t=='1' and ap!='4' for t,ap in firsttasks),formation_after_recall=len(lasttasks)==8 and all(ap=='4' for t,ap in lasttasks),regroup_error=max(errors)<15)
 write_result('scatter',checks,minimum_distance=minimum,return_times=returns,final_error=max(errors))

def death():
 script=prefix+f'FILE:OPEN {fixture}\nGUI:CLICK mainDlg flyNow\nWAITFOR:FLYING\nWAITFOR:SIMTIME 4\nFLIGHTCMD:DAMAGE 1 10000\nWAITFOR:SIMTIME 5\nFLIGHTCMD:REPORT\nBTNFUNC:PAUSESIMULATION\n'
 started,_,log=launch('death',script);text=wait(log,'Script>>BTNFUNC:PAUSESIMULATION');finish('death',started,log)
 units=parser.read_record(out/'death.record.yfs');followers=[x for x in units if not x['player']];departures=re.findall(r'V85DEPART id=(\d+)',text)
 write_result('death',dict(eight_departures=len(set(departures))==8,detached_from_player='V7SQUAD count=0' in text,wingmen_alive=len(followers)==8 and all(v['state']==0 for f in followers for v in f['rows'] if v['time']>.1),not_diving_after_wreck=all(f['rows'][-1]['y']>990 for f in followers)),departures=departures)

if __name__=='__main__':
 cases={'resume':resume,'focus':focus,'scatter':scatter,'death':death}
 for name in sys.argv[1:] or cases:cases[name]()
