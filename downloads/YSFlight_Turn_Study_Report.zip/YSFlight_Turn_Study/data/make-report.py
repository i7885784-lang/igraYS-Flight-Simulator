from pathlib import Path
import json,math,base64,html
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch
s=Path('/workspace/ysflight-work/turn-study');o=s/'report'
res=json.loads((s/'results.json').read_text());lookup={d['file'].replace('.rows.json',''):d for d in res}
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':13,'figure.facecolor':'#f4f7fb','axes.facecolor':'#f4f7fb','text.color':'#172b45','axes.labelcolor':'#172b45'})
b=lookup['before-n8-a180'];a=lookup['speed-only-n8-a180']
def last(d):return max(x['time'] for x in d['units'])
def val(x):return f'{x:.1f}'.replace('.',',')
fig=plt.figure(figsize=(14,10));gs=fig.add_gridspec(3,2,height_ratios=[.65,3.2,.7],hspace=.26,wspace=.15)
fig.suptitle('Разворот на 180°: ведомые делают меньший круг',fontsize=23,fontweight='bold',y=.97)
limits=[];panels=[]
for c,(ver,d,title,color) in enumerate([('before',b,'СЕЙЧАС • v8.6.1','#df5a44'),('speed-only',a,'ПРОБА • исправление скорости','#168b69')]):
 ax=fig.add_subplot(gs[1,c]);units=json.loads((s/f'{ver}-n8-a180.rows.json').read_text());start=d['start'];lead=units[0]['rows'];origin=next(x for x in lead if x['time']>=start)
 for i,u in enumerate(units):
  end=start+d['units'][i]['time'];rows=[x for x in u['rows'] if start<=x['time']<=end]
  xs=[(x['x']-origin['x'])/1000 for x in rows];zs=[(x['z']-origin['z'])/1000 for x in rows];limits.extend(zip(xs,zs));col='#296dc0' if i==0 else color
  ax.plot(xs,zs,color=col,alpha=1 if i in [0,8] else .2,lw=3 if i in [0,8] else 1)
  if i in [0,8]:
   ax.scatter(xs[-1],zs[-1],marker='v',s=90,color=col,zorder=6);ax.scatter(xs[0],zs[0],marker='o',s=25,color=col,zorder=6)
 ax.set_title(title,fontweight='bold',fontsize=15,pad=14);ax.set_aspect('equal');ax.grid(alpha=.13);ax.set_xlabel('Расстояние в километрах');ax.tick_params(labelsize=10);panels.append(ax)
 ax=fig.add_subplot(gs[0,c]);ax.axis('off')
 ax.text(.02,.7,f'{val(last(d))} с',fontsize=31,fontweight='bold',color=color);ax.text(.52,.7,f'{val(d["units"][-1]["path"]/1000)} км',fontsize=31,fontweight='bold',color=color)
 ax.text(.02,.12,'сменили курс все 8',fontsize=12);ax.text(.52,.12,'путь последнего ведомого',fontsize=12)
for ax in panels:
 ax.set_xlim(min(x for x,z in limits)-.25,max(x for x,z in limits)+.25);ax.set_ylim(min(z for x,z in limits)-.25,max(z for x,z in limits)+.25)
fig.text(.5,.15,'Синий — игрок. Красный / зелёный — последний ведомый.\nБледные линии — остальные ведомые. Масштаб одинаковый.',ha='center',fontsize=13)
fig.text(.5,.055,'Реальные записи полётов • МиГ-29 • 8 ведомых • интервал 50 м • высота 1000 м\nПоказан путь до завершения поворота каждым самолётом. Проба ещё не игровое обновление.',ha='center',fontsize=11,color='#526379')
fig.savefig(o/'01-trajectories.png',dpi=145,bbox_inches='tight');plt.close(fig)
fig,axs=plt.subplots(1,3,figsize=(15,4.5));fig.suptitle('Повернуть и собраться — разные задачи',fontsize=22,fontweight='bold')
for ax,(title,x,y,unit) in zip(axs,[('Все сменили курс',last(b),last(a),'с'),('Все заняли свои места',b['regroup'],a['regroup'],'с'),('Максимальная скорость\nведомого за разворот группы',b['maxspeed'],a['maxspeed'],'км/ч')]):
 ax.barh([1,0],[x,y],color=['#df5a44','#168b69'],height=.45);ax.set_yticks([1,0],['Сейчас','Проба']);ax.set_xlim(0,max(x,y)*1.35);ax.set_xticks([]);ax.set_title(title,pad=20,fontsize=14)
 for pos,v in [(1,x),(0,y)]:ax.text(v+max(x,y)*.03,pos,f'{val(v)} {unit}',va='center',fontweight='bold',fontsize=15)
 for sp in ax.spines.values():sp.set_visible(False)
fig.text(.5,.015,'8 ведомых, разворот 180°. Быстрый поворот уже получился; сбор строя ещё можно улучшить.',ha='center',fontsize=12);fig.tight_layout(rect=[0,.08,1,.9]);fig.savefig(o/'02-times.png',dpi=145,bbox_inches='tight');plt.close(fig)
fig,ax=plt.subplots(figsize=(14,4));ax.axis('off');ax.set_xlim(0,3);ax.set_ylim(0,1)
for i,(title,txt) in enumerate([('1. ПОВЕРНУТЬ','Не разгоняться без меры.\nСохранить тягу и скорость,\nнужные для плотного поворота.'),('2. ДОГНАТЬ','После поворота дать ускорение.\nОтставшие догоняют одновременно,\nкаждый своё место.'),('3. ЗАНЯТЬ МЕСТО','Плавно погасить сближение.\nНе перелететь позицию\nи не задеть соседей.')]):
 ax.add_patch(FancyBboxPatch((i+.04,.15),.9,.66,boxstyle='round,pad=.025',facecolor='white',edgecolor='#cfdae8'))
 ax.text(i+.49,.67,title,ha='center',fontweight='bold',fontsize=15);ax.text(i+.49,.4,txt,ha='center',va='center',fontsize=12)
fig.suptitle('Как предлагаю улучшать дальше',fontsize=23,fontweight='bold',y=.98);fig.savefig(o/'03-plan.png',dpi=145,bbox_inches='tight');plt.close(fig)
text=f'''# Почему ведомые слишком широко разворачиваются

**Баг воспроизведён. Проведено {len(res)} полётов в движке игры.** Это исследование и пробные настройки, а не готовая новая версия. Твоя v8.6.1 сохранена.

![Реальные траектории до и после](01-trajectories.png)

Кружок — начало поворота, треугольник — самолёт вышел на новый курс. Чем длиннее цветная линия, тем больше пути потратил ведомый. Обе половины нарисованы в одном масштабе. Это линии из записи игры.

## Главный результат

![Понятные замеры](02-times.png)

Разворот 180° с восемью ведомыми:

- Вся группа меняет курс: **{val(last(b))} → {val(last(a))} секунды**.
- Последний ведомый проходит до выхода на новый курс: **{val(b['units'][-1]['path']/1000)} → {val(a['units'][-1]['path']/1000)} км**.
- Все возвращаются в свои места: **{val(b['regroup'])} → {val(a['regroup'])} секунды**. Это время от начала поворота, его не надо прибавлять к предыдущему.
- В обоих полётах все самолёты сохранились. Наименьший записанный промежуток: **{val(b['clearance'])} → {val(a['clearance'])} м**.

## Что не так в нынешнем коде

Ведомый видит, что отстал, и хочет догнать движущуюся позицию. Контроллер добавляет скорость сразу, даже пока самолёт ещё поворачивает. В этом тесте ведомые разгонялись примерно до **{round(b['maxspeed'])} км/ч**, тогда как игрок летел около **650 км/ч**. На большой скорости для того же крена нужен гораздо больший круг.

Это не просто «слишком маленький крен»: в записи ведомые и так доходят примерно до 75–77°. Первоначальная гипотеза о дополнительном ограничении крена объясняет только часть поведения, особенно небольшие довороты. Основной выигрыш в этих тестах дала работа со скоростью.

Простой пример по физике: при одинаковом крене 75° на 650 км/ч радиус установившегося горизонтального разворота около 0,9 км, на 960 км/ч — около 1,9 км. Это расчёт для объяснения, не замер радиуса каждого самолёта.

## Что попробовала

Только для категории **истребитель** ограничила лишний разгон, когда ведомому нужен заметный доворот или ведущий активно меняет курс. После выхода из поворота догонное ускорение снова доступно. Физика, характеристики самолётов, защита от земли и соседей сохранены. Самолёты не переставляются координатами.

Отдельно проверила усиление доворота и снятие дополнительного ограничения малого крена. Само по себе это помогло меньше. Сочетание обеих правок тоже не во всех случаях лучше. Поэтому на главной картинке показан более простой вариант **только с управлением скоростью**.

## Что ещё не устраивает

С одним ведомым после поворота 90° полный сбор в пробе стал **{val(lookup['before-n1-a90']['regroup'])} → {val(lookup['speed-only-n1-a90']['regroup'])} секунды**: это ухудшение. Курс он меняет быстрее, но точное место занимает позже. Выдавать пробу за полностью готовое исправление нельзя.

На больших группах улучшение есть, но полного результата «быстро и сразу красиво» ещё нет. Следующий шаг — отдельно настроить догон и гашение скорости возле своего места, сохранив выигрыш в повороте.

![План улучшения](03-plan.png)

Начало поворота должно быть немедленным. Сбор идёт одновременно для всех, без ожидания впереди идущего. На малой высоте и при риске столкновения остаются ограничения безопасности.

## Как проверяла

Одинаковые сценарии: МиГ-29, океан, 1000 м, начальная скорость 180 м/с (648 км/ч), колонна с интервалом 50 м, одинаковое топливо. После 10 секунд ровного полёта ведущий получает новое направление; затем идут 120 секунд симуляции. Ведущий управляется одним и тем же автопилотом во всех вариантах. Его параметры не улучшались.

1, 4 и 8 ведомых, повороты 90° и 180°: исходник и проба со скоростью — 12 полётов. Ещё 8 полётов — отдельный доворот и сочетание правок. Всего 20 полётов. Это не проверка всех количеств, моделей, высот и строёв.

Время поворота: от начала крена ведущего более 5° до выхода на новый курс с погрешностью менее 5° на протяжении примерно 2 секунд. Время всей группы — по последнему самолёту. Сбор: все ведомые ближе 15 м к своим назначенным местам и остаются в пределах допуска до конца записи (минимум ещё 2 секунды). Это не расстояние 15 м между самолётами.

Шаг физики — 0,025 с, записи — примерно через 0,075 с. Расстояния проверены по синхронным отметкам времени, плюс состояния самолётов. Проверка выполнялась Windows x64-сборкой того же кода под Wine. Windows 10 x86 и запуск двойным щелчком в этом исследовании не проверялись: игровое обновление не собиралось.

## Полные результаты
'''
for n in [1,4,8]:
 text+=f'\n### {n} ведомых\n\n'
 for ang in [90,180]:
  old=lookup[f'before-n{n}-a{ang}'];new=lookup[f'speed-only-n{n}-a{ang}']
  text+=f'- Поворот {ang}°: смена курса **{val(last(old))} → {val(last(new))} с**; полный сбор **{val(old["regroup"])} → {val(new["regroup"])} с**.\n'
text+='''
## Что сохранено

В архиве: отчёт с картинками, данные results.json, сценарии, исходные записи полётов и исследованные версии файла. Пробные правки не установлены в основную игру. Исходная версия управления и исходный проверочный EXE восстановлены побайтно; опубликованные игровые ZIP не менялись.

Для разработчика: SafeFormationControl в src/autopilot/fsformationsafety.cpp. wantedVelocity объединяет скорость места в строю и догонную поправку; desiredSpeed берётся из длины этого вектора. Проба меняет только ограничение desiredSpeed при активном повороте для FSAC_FIGHTER. Это ограниченное исследование; нужны дальнейшие проверки перестроений, потерь, прикрытия, малых высот и других моделей.
'''
(o/'ОТЧЁТ.md').write_text(text)
import markdown
body=markdown.markdown(text,extensions=['extra'])
for p in o.glob('*.png'):
 body=body.replace(f'src="{p.name}"',f'src="data:image/png;base64,{base64.b64encode(p.read_bytes()).decode()}"')
(o/'ОТКРЫТЬ_ОТЧЁТ.html').write_text('<!doctype html><html lang="ru"><meta charset="utf-8"><title>YSFlight — исследование поворотов</title><style>body{font:19px/1.6 Arial,sans-serif;background:#f4f7fb;color:#172b45;max-width:1080px;margin:30px auto;padding:20px}img{max-width:100%;height:auto;border-radius:10px}h1,h2,h3{line-height:1.2}li{margin:10px 0}</style>'+body+'</html>')
print('Report generated',len(res))
