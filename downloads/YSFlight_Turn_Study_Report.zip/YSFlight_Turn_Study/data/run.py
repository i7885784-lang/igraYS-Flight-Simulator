from pathlib import Path
import sys,os,importlib.machinery,json,math,time,shutil
r=Path('/workspace/ysflight-work');s=r/'turn-study'
os.environ['V85_TEST_USER']='turn-study-user'
t=importlib.machinery.SourceFileLoader('turnt',str(r/'v8_5-tests.py')).load_module()
profile=r/'turn-study-user';(profile/'config').mkdir(parents=True,exist_ok=True);(profile/'config/option.cfg').write_text('OPENDEMO FALSE\nFONTHEIGHT 18\nLANGUAGE "FILE:ru.uitxt"\n')
version=sys.argv[1]
for n in ([1] if os.environ.get("TURN_SINGLE") else [4,8] if os.environ.get("TURN_GROUP") else [1,4,8]):
 for angle in [90,180]:
  name=f'{version}-n{n}-a{angle}';fixture=s/f'{name}.yfs';blocks=(r/'v8_3-baseline-mig50.yfs').read_text().split('AIRPLANE ');fixture.write_text('AIRPLANE '.join(blocks[:n+2]))
  x,z=(100000,1800) if angle==90 else (0,-100000)
  script=t.prefix+f'FILE:OPEN Z:{fixture}\nGUI:CLICK mainDlg flyNow\nWAITFOR:FLYING\nFLIGHTCMD:TESTADVANCE 10\nFLIGHTCMD:LEADERGOAL {x} 1000 {z} 180\nFLIGHTCMD:TESTADVANCE 120\nFLIGHTCMD:REPORT\nBTNFUNC:PAUSESIMULATION\nSLEEP:5000\n'
  started,_,log=t.launch(name,script);text=t.wait(log,'Script>>SLEEP:5000',180)
  t.u.key('alt+F4');time.sleep(.7)
  files=[p for p in (profile/'FlightHistory').glob('*.record.yfs') if p.stat().st_mtime>started]
  dst=s/f'{name}.record.yfs';shutil.copy2(max(files,key=lambda p:p.stat().st_mtime),dst);shutil.copy2(log,s/f'{name}.log')
  units=t.parser.read_record(dst);(s/f'{name}.rows.json').write_text(json.dumps(units))
  print('DONE',name,len(units),units[0]['rows'][-1]['time'],flush=True)
