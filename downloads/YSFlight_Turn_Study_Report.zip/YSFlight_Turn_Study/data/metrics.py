from pathlib import Path
import json,math
s=Path('/workspace/ysflight-work/turn-study')
def angle(a,b):return abs(math.atan2(math.sin(a-b),math.cos(a-b)))
def analyze(path):
 units=json.loads(path.read_text());leader=units[0]['rows'];turnstart=next(a['time'] for a in leader if abs(a['bank'])>math.radians(5) and a['time']>8)
 target=leader[-1]['h'];out=[]
 for i,u in enumerate(units):
  a=[a for a in u['rows'] if a['time']>=turnstart];ts=next((x['time'] for k,x in enumerate(a) if angle(x['h'],target)<math.radians(5) and all(angle(y['h'],target)<math.radians(5) for y in a[k:k+30])),None)
  done=[x for x in a if ts is None or x['time']<=ts]
  distance=sum(math.dist((x['x'],x['z']),(y['x'],y['z'])) for x,y in zip(done,done[1:]))
  out.append(dict(id=i,time=None if ts is None else ts-turnstart,path=distance,maxbank=max(abs(math.degrees(x['bank'])) for x in a),minheight=min(x['y'] for x in a),states=sorted(set(x['state'] for x in a))))
 return dict(file=path.name,start=turnstart,units=out)
if __name__=='__main__':
 for p in sorted(s.glob('*.rows.json')):print(json.dumps(analyze(p)))
