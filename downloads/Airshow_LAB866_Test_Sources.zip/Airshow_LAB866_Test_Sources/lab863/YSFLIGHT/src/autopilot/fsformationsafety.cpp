#include "fs.h"
#include "fsformationautopilot.h"

YSRESULT FsFormation::SafeFormationControl(FsAirplane &air,FsSimulation *sim,double dt)
{
 auto &p=air.Prop();YsVec3 velocity,leadVelocity;p.GetVelocity(velocity);if(independentDeparture)leadVelocity=departureVelocity;else leader->Prop().GetVelocity(leadVelocity);
 const bool fighter=p.GetAirplaneCategory()==FSAC_FIGHTER;
 const double margin=YsGreater(18.0,air.GetApproximatedCollideRadius()*0.8);
 safeTerrain=sim->GetFieldElevation(air.GetPosition().x(),air.GetPosition().z());
 for(int i=1;i<=8;++i){auto sample=air.GetPosition()+velocity*(i*0.5);safeTerrain=YsGreater(safeTerrain,sim->GetFieldElevation(sample.x(),sample.z()));}
 goal.SetY(YsGreater(goal.y(),sim->GetFieldElevation(goal.x(),goal.z())+margin));
 // Follow current leader motion immediately; never wait for another wingman.
 safeGoal=goal;safeGoalValid=true;
 const double heading=independentDeparture ? air.GetAttitude().h() : leader->GetAttitude().h();
 if(!independentDeparture && headingTracked && dt>YsTolerance)
 {
  const double rate=atan2(sin(heading-lastLeaderHeading),cos(heading-lastLeaderHeading))/dt;
  formationTurnRate+=(YsBound(rate,-0.35,0.35)-formationTurnRate)*dt/(0.15+dt);
  auto accel=(leadVelocity-previousLeaderVelocity)/dt;
  if(accel.GetLength()>40.0){accel.Normalize();accel*=40.0;}
  leaderAcceleration+=(accel-leaderAcceleration)*dt/(0.25+dt);
 }
 previousLeaderVelocity=leadVelocity;lastLeaderHeading=heading;headingTracked=true;
 bool turnEscape=false;
 if(fighter && !independentDeparture)
 {
  auto horizontal=safeGoal-air.GetPosition();horizontal.SetY(0.0);
  // An abreast line cannot swing through its inside members at full bank.
  // Open distinct physical height lanes early, keep them until horizontal
  // places are recaptured, then return to the requested formation height.
  const bool abreast=YsAbs(shouldBe.z())<1.0 && YsAbs(shouldBe.x())>1.0;
  if(abreast && YsAbs(leader->GetAttitude().b())>YsDegToRad(25.0))
  {
   if(turnEscapeHeight==0.0)
   {
    turnEscapeHeight=(shouldBe.x()<0.0 ? -1.0:1.0)*(20.0+16.0*(YsGreater(0,air.squadSlot)+1));
    if(safeGoal.y()+turnEscapeHeight<safeTerrain+margin+12.0)turnEscapeHeight=160.0+16.0*(YsGreater(0,air.squadSlot)+1);
   }
   turnEscapeUntil=sim->GetClock()+2.0;
  }
  const double directionError=atan2(sin(heading-air.GetAttitude().h()),cos(heading-air.GetAttitude().h()));
  bool corridorClear=true;
  if(turnEscapeHeight!=0.0 && horizontal.GetLength()<120.0)
  {
   for(auto other=sim->FindNextAirplane(nullptr);other;other=sim->FindNextAirplane(other))
    if(other!=&air && other->IsAlive()==YSTRUE)
   {
    const double clearance=(air.GetApproximatedCollideRadius()+other->GetApproximatedCollideRadius())*1.2+8.0;
    if(other->GetPosition().y()<YsSmaller(air.GetPosition().y(),goal.y())-clearance ||
       other->GetPosition().y()>YsGreater(air.GetPosition().y(),goal.y())+clearance)continue;
    auto rel=other->GetPosition()-air.GetPosition();rel.SetY(0.0);
    YsVec3 otherVelocity;other->Prop().GetVelocity(otherVelocity);
    auto rv=otherVelocity-velocity;rv.SetY(0.0);
    const double ahead=YsBound(-(rel*rv)/YsGreater(1.0,rv.GetSquareLength()),0.0,3.0);
    if((rel+rv*ahead).GetLength()<clearance){corridorClear=false;break;}
   }
  }
  // A distant return is allowed only in an open traffic corridor.
  // Do not extrapolate a neighbour's current vertical speed through its next
  // turn or descent. Retain the proven close-formation gate around traffic.
  bool openDistantCorridor=turnEscapeHeight!=0.0 && horizontal.GetLength()>=120.0 &&
      YsAbs(air.GetAttitude().b())<YsDegToRad(10.0) && YsAbs(formationTurnRate)<0.02;
  if(openDistantCorridor)
  {
   for(auto other=sim->FindNextAirplane(nullptr);other && openDistantCorridor;other=sim->FindNextAirplane(other))
    if(other!=&air && other->IsAlive()==YSTRUE)
   {
    auto rel=other->GetPosition()-air.GetPosition();rel.SetY(0.0);
    if(rel.GetLength()<1200.0 && YsAbs(other->GetAttitude().b())>YsDegToRad(10.0))
    {openDistantCorridor=false;break;}
    YsVec3 ov;other->Prop().GetVelocity(ov);auto rv=ov-velocity;rv.SetY(0.0);
    const double t=YsBound(-(rel*rv)/YsGreater(1.0,rv.GetSquareLength()),0.0,6.0);
    if((rel+rv*t).GetLength()<200.0)openDistantCorridor=false;
   }
  }
  const bool horizontalReady=horizontal.GetLength()<12.0 ||
      (horizontal.GetLength()<120.0 && corridorClear) || openDistantCorridor;
  const bool recaptured=sim->GetClock()>turnEscapeUntil && horizontalReady &&
       YsAbs(directionError)<YsDegToRad(25.0) && YsAbs(leader->GetAttitude().b())<YsDegToRad(20.0);
  if(recaptured)turnEscapeHeight=0.0;
  turnEscape=turnEscapeHeight!=0.0;
  if(turnEscape)safeGoal.SetY(YsGreater(safeTerrain+margin,safeGoal.y()+turnEscapeHeight));
 }
 auto slot=independentDeparture ? YsOrigin() : safeGoal-leader->GetPosition();
 YsVec3 slotVelocity=leadVelocity+YsVec3(-slot.z()*formationTurnRate,0.0,slot.x()*formationTurnRate);
 // Determine group geometry before choosing the long-intercept approach.
 bool narrowColumn=!independentDeparture && YsAbs(shouldBe.x())<1.0;
 if(narrowColumn)for(auto other=sim->FindNextAirplane(nullptr);other;other=sim->FindNextAirplane(other))
  if(other!=&air && other!=leader && other->IsAlive()==YSTRUE && air.squadSlot>=0 && other->squadSlot>=0 &&
     air.squadLeaderKey==other->squadLeaderKey && YsAbs(other->squadOffset.x())>1.0){narrowColumn=false;break;}
 auto error=safeGoal-air.GetPosition();auto horizontalError=error;horizontalError.SetY(0.0);
 const double velocityError=(slotVelocity-velocity).GetLength();
 // Long-distance interception keeps energy until the native controller has
 // brought relative speed down. Switch to precise capture only near the slot.
 if(horizontalError.GetLength()>800.0)longRangeIntercept=true;
 if(longRangeIntercept && horizontalError.GetLength()<(narrowColumn ? 35.0:120.0) && velocityError<12.0)longRangeIntercept=false;
 if(horizontalError.GetLength()>25.0 || YsAbs(error.y())>8.0 || velocityError>8.0){rejoining=true;joinStableSeconds=0.0;}
 if(horizontalError.GetLength()<8.0 && YsAbs(error.y())<3.0 && velocityError<4.0)
 {joinStableSeconds+=dt;if(joinStableSeconds>0.8)rejoining=false;}else joinStableSeconds=0.0;
 // Hybrid: feed forward the manoeuvre now, use stronger interception while displaced.
 // Normal tracking and recapture share one continuous flight controller.
 const double courseError=atan2(sin(heading-air.GetAttitude().h()),cos(heading-air.GetAttitude().h()));
 const bool captureAligned=fighter && !independentDeparture && YsAbs(formationTurnRate)<0.06 &&
    YsAbs(courseError)<YsDegToRad(12.0) && YsAbs(leader->GetAttitude().b())<YsDegToRad(25.0);
 // Accelerate a distant capture, retain the proven damping near the slot.
 const double captureBase=(captureAligned ? 2.2-(longRangeIntercept ? 0.6:1.0)*YsBound((horizontalError.GetLength()-100.0)/200.0,0.0,1.0):2.2);
 // Speed up the final few metres only after vertical/velocity capture is safe.
 // Do not apply aggressive near-slot gains during a high-speed crossing.
 const double terminalWeight=(captureAligned && !turnEscape ?
    YsBound((45.0-horizontalError.GetLength())/20.0,0.0,1.0)*
    YsBound((10.0-velocityError)/4.0,0.0,1.0)*YsBound((5.0-YsAbs(error.y()))/3.0,0.0,1.0):0.0);
 const double captureResponse=captureBase*(1.0-terminalWeight)+1.2*terminalWeight;
 const double response=(rejoining ? captureResponse:1.8);
 auto steeringError=independentDeparture ? YsOrigin() : horizontalError;
 if(!independentDeparture && rejoining && YsAbs(shouldBe.x())<1.0)
 {
  YsAtt3 leadYaw=leader->GetAttitude();leadYaw.SetP(0.0);leadYaw.SetB(0.0);YsVec3 localError;leadYaw.MulInverse(localError,horizontalError);
  // Distant intercepts pass beside occupied slots before merging.
  // Keep the normal near-turn lane unchanged.
  const bool passingColumn=longRangeIntercept && narrowColumn;
  const double laneWidth=passingColumn ? 85.0:40.0;
  const double laneLength=passingColumn ? YsBound((YsAbs(localError.z())-10.0)/30.0,0.0,1.0):YsBound((YsAbs(localError.z())-15.0)/100.0,0.0,1.0);
  const double lane=laneWidth*laneLength*YsBound((YsAbs(localError.x())-10.0)/20.0,0.0,1.0);
  YsVec3 offset(localError.x()>0.0 ? -lane:lane,0.0,0.0);leadYaw.Mul(offset,offset);steeringError+=offset;
 }
 // Increase damping smoothly near the slot to settle without crossing it again.
 const double settling=YsBound((0.015-YsAbs(formationTurnRate))/0.010,0.0,1.0);
 const double velocityDamping=1.2+0.8*settling*YsBound((60.0-horizontalError.GetLength())/60.0,0.0,1.0);
 YsVec3 correction=steeringError/response+(slotVelocity-velocity)*velocityDamping;correction.SetY(0.0);
 const double correctionLimit=YsBound(leadVelocity.GetLength()*0.7,40.0,150.0);
 if(correction.GetLength()>correctionLimit){correction.Normalize();correction*=correctionLimit;}
 // Predict stopping distance relative to the moving slot. Account for
 // throttle/brake response before allowing a high closing speed near it.
 if(captureAligned && rejoining && !longRangeIntercept)
 {
  auto forward=leadVelocity;forward.SetY(0.0);
  if(forward.Normalize()==YSOK)
  {
   const double along=horizontalError*forward;
   const double closing=(velocity-slotVelocity)*forward;
   const double brakeCd=(p.GetHasSpoiler()==YSTRUE ? p.GetCdSpoiler():0.0);
   const double drag=p.GetDrag(p.GetAOA(),p.GetVelocity())/YsGreater(1.0,1.0+brakeCd*p.GetSpoiler());
   const double brakeAuthority=YsBound(drag*(1.0+brakeCd)/YsGreater(1.0,p.GetTotalWeight())*0.65,1.0,8.0);
   const double remaining=YsGreater(0.0,YsAbs(along)-8.0-YsAbs(closing)*1.5);
   // A low-speed terminal creep removes the old 8 m dead zone.
   // It fades out during a fast or vertically displaced approach.
   const double closingLimit=sqrt(2.0*brakeAuthority*remaining)+terminalWeight*YsSmaller(2.0,YsAbs(along)*0.25);
   const double demanded=correction*forward;
   // Limit approach speed, but never suppress an opposite braking demand.
   const double allowed=(along>=0.0 ? YsSmaller(demanded,closingLimit):YsGreater(demanded,-closingLimit));
   correction+=forward*(allowed-demanded);
  }
 }
 auto wantedVelocity=independentDeparture ? departureVelocity : slotVelocity+correction;wantedVelocity.SetY(0.0);
 double configuredSeparation=shouldBe.GetLength();
 // A narrow column can turn on its own height lanes without sweeping
 // through an abreast neighbour. Mixed/abreast layouts retain lift reserve.

 const bool leaderSettled=!independentDeparture && YsAbs(formationTurnRate)<0.02 && YsAbs(leader->GetAttitude().b())<YsDegToRad(15.0);
 const bool holdingPlace=leaderSettled && turnEscapeHeight==0.0 && (goal-air.GetPosition()).GetLength()<12.0 && (velocity-leadVelocity).GetLength()<6.0;
 double closestPrediction=1.0e9,closestPhysical=0.0;
 double avoidanceTarget=0.0,closestTime=7.0;YsVec3 avoidVelocity=YsOrigin();collisionRisk=false;
 for(auto other=sim->FindNextAirplane(nullptr);other;other=sim->FindNextAirplane(other))if(other!=&air && other->IsAlive()==YSTRUE)
 {
  if(!independentDeparture && other!=leader && air.squadSlot>=0 && other->squadSlot>=0 && air.squadLeaderKey==other->squadLeaderKey)
   {
   configuredSeparation=YsSmaller(configuredSeparation,(air.squadOffset-other->squadOffset).GetLength());

  }
  auto relative=other->GetPosition()-air.GetPosition();const double distance=relative.GetLength();
  if(distance>1200.0)continue;
  YsVec3 ov;other->Prop().GetVelocity(ov);const auto rv=ov-velocity;
  double t=YsBound(-(relative*rv)/YsGreater(1.0,rv.GetSquareLength()),0.0,6.0);
  double closing=YsGreater(0.0,-(relative*rv)/YsGreater(1.0,distance));
  // One physical clearance for both tracking and avoidance. Parallel aircraft
  // 50m apart must not be permanently pushed into slot-indexed altitude steps.
  // Fighter recapture needs room for the finite roll/throttle response, not only the mesh radius.
  const double physical=YsGreater(fighter && other->Prop().GetAirplaneCategory()==FSAC_FIGHTER ? 22.0:6.0,(air.GetApproximatedCollideRadius()+other->GetApproximatedCollideRadius())*1.2+3.0);
  // Add manoeuvring room only while converging. Parallel tight formations
  // keep their original physical clearance, without a permanent altitude step.
  double predicted=(relative+rv*t).GetLength();
  const double separation=physical+YsSmaller(45.0,closing*0.35+(closing>1.0 ? 5.0:0.0));
  // A settled member keeps its place; the joining aircraft plans the approach.
  // Both still escape if that approach becomes an imminent physical conflict.
  if(holdingPlace && t>2.0 && distance>physical*2.0 && other!=leader &&
     other->squadLeaderKey==air.squadLeaderKey)
   if(auto otherFormation=dynamic_cast<FsFormation *>(other->GetAutopilot()))
    if(!otherFormation->independentDeparture && otherFormation->rejoining)continue;
  if(predicted<separation && ((t>0.05 && closing>0.5) || distance<physical))
  {
   if(t<closestTime)
   {
    collisionRisk=true;closestTime=t;closestPrediction=predicted;closestPhysical=physical;
    const double sign=(FsExistence::GetSearchKey(&air)<FsExistence::GetSearchKey(other) ? -1.0:1.0);
    auto away=-relative;away.SetY(0.0);
    if(away.GetLength()<1.0)away.Set(sign,0.0,0.0);
    away.Normalize();avoidVelocity=away*YsBound((separation-predicted)*1.2,12.0,55.0);
    // Short-lived vertical separation only for an imminent crossing; never
    // a permanent altitude assigned by wingman number.
    if(t<4.0)avoidanceTarget=sign*YsBound(separation*0.85,18.0,32.0);
   }
  }
 }
 // Keep a consistent squad traffic lane throughout a close recapture.
 // Choosing up/down anew for each nearest neighbour makes a middle aircraft
 // reverse its escape as a different neighbour becomes the closest threat.
 const bool needsHeightEscape=!leaderSettled || !holdingPlace ||
    (closestTime<3.5 && closestPrediction<closestPhysical+6.0);
 if(leaderSettled && !needsHeightEscape)avoidanceTarget=0.0;
 if(fighter && !independentDeparture && collisionRisk && needsHeightEscape && air.squadSlot>=0)
 {
  if(turnEscapeHeight==0.0)
  {
   turnEscapeHeight=(air.squadSlot%2==0 ? -1.0:1.0)*(20.0+16.0*(air.squadSlot+1));
   if(goal.y()+turnEscapeHeight<safeTerrain+margin+12.0)turnEscapeHeight=160.0+16.0*(air.squadSlot+1);
   safeGoal.SetY(YsGreater(safeTerrain+margin,goal.y()+turnEscapeHeight));
  }
  turnEscapeUntil=sim->GetClock()+2.0;turnEscape=true;
 }
 if(turnEscape)avoidanceTarget=0.0;
 // Safety wins over the desire to occupy the requested slot. Otherwise a
 // large interception correction can overpower the avoidance vector.
 if(collisionRisk && !independentDeparture)wantedVelocity=slotVelocity+correction*0.35;
 avoidanceHeight+=(avoidanceTarget-avoidanceHeight)*dt/(0.25+dt);
 // Closely spaced aircraft must brake with the leader, before positional error
 // develops. This affects only requested target gaps below 45m, not normal 50m formations.
 auto leadDirection=leadVelocity;leadDirection.SetY(0.0);
 if(!independentDeparture && leadDirection.Normalize()==YSOK)
  wantedVelocity+=leadDirection*(leaderAcceleration*leadDirection)*(2.5*YsBound((45.0-configuredSeparation)/5.0,0.0,1.0));
 wantedVelocity+=avoidVelocity;
 const double clearance=air.GetPosition().y()-safeTerrain;
 const double down=YsGreater(0.0,-velocity.y()),bank=air.GetAttitude().b();
 // Extra authority is safe only in a narrow column. Wide layouts retain
 // their proven authority: an inside neighbour can cross a tighter turn.
 const bool agileFighter=fighter && narrowColumn && !independentDeparture;
 const double gLimit=YsBound(agileFighter ? 7.0:GetDefaultGLimit(air),2.0,7.0);
 const double rollRateLimit=(fighter ? YsSmaller(p.GetMaxRollRate(),YsDegToRad(240.0)):YsDegToRad(90.0));
 const double rollTime=YsAbs(bank)/YsDegToRad(90.0);
 // Keep the previous conservative terrain reserve despite extra turn authority.
 const double terrainG=YsBound(GetDefaultGLimit(air),2.0,6.0);
 const double reserve=margin+down*(1.5+rollTime)+down*down/(2.0*YsGreater(3.0,(terrainG-1.0)*FsGravityConst*0.5));
 if((clearance<reserve && (down>1.0 || clearance<margin)) || cos(bank)<-0.15)recovering=true;
 if(recovering && velocity.y()>-1.0 && clearance>reserve+10.0 && YsAbs(bank)<YsDegToRad(25.0))recovering=false;
 p.NeutralDirectAttitudeControl();p.SetBrake(0.0);
 const double weight=p.GetTotalWeight()*FsGravityConst;
 const double liftAt100=YsGreater(1.0,p.GetLift(p.GetCriticalAOA()*0.7,100.0));
 const double levelSpeed=YsGreater(25.0,100.0*sqrt(weight*1.15/liftAt100));
 const double availableG=p.GetLift(p.GetCriticalAOA()*0.8,p.GetVelocity())/YsGreater(1.0,weight);
 const double minSpeed=levelSpeed/sqrt(YsGreater(0.4,cos(bank)));
 if(recovering)
 {
  p.BankController(0.0,(fighter ? rollRateLimit:YsDegToRad(100.0)));p.SetSpoiler(0.0);
  p.GController(cos(bank)>0.3 ? YsBound(1.6+down*0.18,1.6,gLimit) : cos(bank)<-0.3 ? -0.5 : 0.0);
  commandedSpeed=YsGreater(minSpeed,leadVelocity.GetLength());commandedClimb=0.0;
  p.SpeedController(commandedSpeed);mode=FSFOMMODE_RECOVER_FROM_LOWALT;
 }
 else
 {
  YsAtt3 yaw=air.GetAttitude();yaw.SetP(0.0);yaw.SetB(0.0);YsVec3 local;yaw.MulInverse(local,wantedVelocity);
  const double bearing=atan2(-local.x(),local.z());
  double altitudeBank=(clearance<120.0 ? 35.0 : clearance<200.0 ? 55.0 : (agileFighter ? 80.0:75.0));
  if(fighter && !independentDeparture && leadVelocity.y()>-5.0)
  {
   // A level fighter turn at 100m is not a low-altitude dive. Retain the
   // predictive terrain recovery, but do not impose the transport-like
   // 35-degree bank on a fighter with lift/roll authority in reserve.
   const double levelBank=(clearance<60.0 ? 45.0 : clearance<120.0 ? 65.0 : clearance<200.0 ? 70.0:(agileFighter ? 80.0:75.0));
   altitudeBank+=(levelBank-altitudeBank)*YsBound((velocity.y()+10.0)/10.0,0.0,1.0);
  }
  double bankLimit=YsSmaller(acos(1.0/(gLimit-0.3)),YsDegToRad(altitudeBank));
  if(gLimit<3.1)bankLimit=YsSmaller(bankLimit,YsDegToRad(35.0));
  // Do not force a wide 45-degree turn merely because a height lane is active.
  // Keep normal fighter turn authority in a narrow column; mixed layouts
  // retain the existing height-escape reserve. Physical lift/G limits below
  // and imminent-crossing bank limit still apply on every frame.
  if(turnEscape && YsAbs(safeGoal.y()-air.GetPosition().y())>24.0)
   bankLimit=YsSmaller(bankLimit,YsDegToRad(narrowColumn ? 80.0:45.0));
  if(collisionRisk && closestTime<4.0)bankLimit=YsSmaller(bankLimit,YsDegToRad(closestTime<2.5 ? 45.0:60.0));
  bankLimit=YsSmaller(bankLimit,acos(1.0/YsGreater(1.01,availableG*0.85)));
  if(p.GetVelocity()<minSpeed*1.05)bankLimit=YsSmaller(bankLimit,YsDegToRad(20.0));
  double feedforward=atan2(wantedVelocity.GetLength()*formationTurnRate,FsGravityConst);
  // Bank is observable before heading has changed. Anticipate the leader's
  // roll instead of waiting for lateral position error to develop.
  if(fighter && !independentDeparture)
   feedforward=feedforward*0.35+leader->GetAttitude().b()*0.65;
  if(YsAbs(formationTurnRate)<0.015 && horizontalError.GetLength()<120.0)
   bankLimit=YsSmaller(bankLimit,YsDegToRad(25.0+horizontalError.GetLength()*0.25));
  p.BankController(YsBound(bearing*2.4+feedforward,-bankLimit,bankLimit),rollRateLimit);
  const double targetHeight=YsGreater(safeGoal.y()+avoidanceHeight,safeTerrain+margin);
  const double descent=YsBound((clearance-margin)/4.0,2.0,50.0);
  commandedClimb=YsBound(leadVelocity.y()+(targetHeight-air.GetPosition().y())/2.0+leaderAcceleration.y()*0.3,-descent,45.0);
  // With the leader level, finish a height escape without a dive that
  // consumes forward speed and repeatedly projects a new crossing.
  if(fighter && !independentDeparture && YsAbs(leadVelocity.y())<3.0 &&
     YsAbs(courseError)<YsDegToRad(12.0) && YsAbs(leader->GetAttitude().b())<YsDegToRad(20.0))
   commandedClimb=YsBound(commandedClimb,-15.0,15.0);
  const double requestedG=(1.0+(commandedClimb-velocity.y())*0.20+YsBound(leaderAcceleration.y()/FsGravityConst,-0.4,0.8)*0.4)/YsGreater(0.25,cos(bank));
  const double minimumG=(clearance>200.0 ? 0.15:0.6);
  p.GController(YsBound(requestedG,minimumG,YsGreater(minimumG,YsSmaller(gLimit,availableG*0.9))));
  // Acceleration is available during capture, not disabled at 45 degrees.
  // Slow only when the desired track is actually behind the aircraft.
  double desiredSpeed=(YsAbs(bearing)>YsDegToRad(100.0) ? YsSmaller(leadVelocity.GetLength(),wantedVelocity.GetLength()) : wantedVelocity.GetLength());
  // Compensate vertical motion once capture is aligned. During a hard
  // crossing keep the conservative turn-speed demand and lift reserve.
  if(captureAligned)desiredSpeed=sqrt(desiredSpeed*desiredSpeed+commandedClimb*commandedClimb);
  if(fighter && !independentDeparture && !collisionRisk)
  {
   // Keep interception throttle from inflating the fighter turn radius.
   // This changes speed demand, not aircraft physics or traffic avoidance.
   const double headingError=atan2(sin(heading-air.GetAttitude().h()),cos(heading-air.GetAttitude().h()));
   const double turning=YsGreater(YsAbs(bearing)/YsDegToRad(25.0),YsAbs(formationTurnRate)/0.08);
   const double cap=leadVelocity.GetLength()*(turning>1.0 ? 1.02 : turning>0.5 ? 1.10:1.50);
   // Once headings settle, release capture acceleration even if the slot is off to one side.
   const bool aligned=YsAbs(formationTurnRate)<0.06 && YsAbs(headingError)<YsDegToRad(12.0) && YsAbs(leader->GetAttitude().b())<YsDegToRad(25.0);
   if(!aligned)desiredSpeed=YsSmaller(desiredSpeed,cap);
  }
  commandedSpeed=YsGreater(minSpeed,desiredSpeed);p.SpeedController(commandedSpeed);
  mode=(!rejoining && error.GetLength()<10.0 ? FSFOMMODE_INPOSITION:FSFOMMODE_LOSTPOSITION);
 }
 p.SetGControllerAOALimit(-p.GetCriticalAOA()*0.4,p.GetCriticalAOA()*(recovering ? 0.95:0.8));
 if(!independentDeparture){p.SetGear(leader->Prop().GetLandingGear());p.SetFlap(leader->Prop().GetFlap());}p.SetRudder(0.0);p.SmartRudder(dt);
 return YSOK;
}
