#include "fs.h"
#include "fsformationautopilot.h"

YSRESULT FsFormation::SafeFormationControl(FsAirplane &air,FsSimulation *sim,double dt)
{
 auto &p=air.Prop();YsVec3 velocity,leadVelocity;p.GetVelocity(velocity);leader->Prop().GetVelocity(leadVelocity);
 const double margin=YsGreater(18.0,air.GetApproximatedCollideRadius()*0.8);
 safeTerrain=sim->GetFieldElevation(air.GetPosition().x(),air.GetPosition().z());
 for(int i=1;i<=8;++i){auto sample=air.GetPosition()+velocity*(i*0.5);safeTerrain=YsGreater(safeTerrain,sim->GetFieldElevation(sample.x(),sample.z()));}
 const double groundAtSlot=sim->GetFieldElevation(goal.x(),goal.z());goal.SetY(YsGreater(goal.y(),groundAtSlot+margin));
 if(!safeGoalValid){safeGoal=goal;safeGoalValid=true;}
 else {auto move=goal-safeGoal;const double maxMove=YsGreater(80.0,leadVelocity.GetLength()*2.0)*dt;if(move.GetLength()>maxMove){move.Normalize();move*=maxMove;}safeGoal+=move;}
 // A turning slot has its own velocity. Never copy the leader's pitch or roll.
 const double heading=leader->GetAttitude().h();
 if(headingTracked && dt>YsTolerance)
 {
  const double rate=atan2(sin(heading-lastLeaderHeading),cos(heading-lastLeaderHeading))/dt;
  formationTurnRate+=(YsBound(rate,-0.25,0.25)-formationTurnRate)*dt/(0.7+dt);
 }
 lastLeaderHeading=heading;headingTracked=true;
 auto slot=safeGoal-leader->GetPosition();
 YsVec3 slotVelocity=leadVelocity+YsVec3(-slot.z()*formationTurnRate,0.0,slot.x()*formationTurnRate);
 YsVec3 error=safeGoal-air.GetPosition(),correction=error/3.0+(slotVelocity-velocity)*0.65;correction.SetY(0.0);
 const double correctionLimit=YsBound(leadVelocity.GetLength()*0.55,35.0,120.0);
 if(correction.GetLength()>correctionLimit){correction.Normalize();correction*=correctionLimit;}
 auto wantedVelocity=slotVelocity+correction;wantedVelocity.SetY(0.0);
 // Keep moving toward the slot while separating intersecting approach paths.
 double avoidance=0.0,closestTime=7.0;YsVec3 avoidVelocity=YsOrigin();
 for(auto other=sim->FindNextAirplane(nullptr);other;other=sim->FindNextAirplane(other))if(other!=&air && other->IsAlive()==YSTRUE)
 {
  const auto relative=other->GetPosition()-air.GetPosition();if(relative.GetSquareLength()>1000000.0)continue;
  YsVec3 ov;other->Prop().GetVelocity(ov);const auto rv=ov-velocity;
  const double t=YsBound(-(relative*rv)/YsGreater(1.0,rv.GetSquareLength()),0.0,6.0);
  const double separation=YsGreater(65.0,(air.GetApproximatedCollideRadius()+other->GetApproximatedCollideRadius())*2.5);
  if((relative+rv*t).GetLength()<separation && (t>0.1 || relative.GetLength()<separation*0.75))
  {
   if(t<closestTime)
   {
    closestTime=t;
    const double sign=(FsExistence::GetSearchKey(&air)<FsExistence::GetSearchKey(other) ? -1.0:1.0);
    avoidance=sign*(55.0+5.0*YsGreater(0,air.squadSlot));
    auto away=-relative;away.SetY(0.0);
    if(away.GetLength()<1.0)away.Set(sign,0.0,0.0);
    away.Normalize();avoidVelocity=away*YsBound((separation-(relative+rv*t).GetLength())*0.9,15.0,55.0);
   }
  }
 }
 wantedVelocity+=avoidVelocity;
 const double clearance=air.GetPosition().y()-safeTerrain;
 const double down=YsGreater(0.0,-velocity.y()),bank=air.GetAttitude().b();
 const double gLimit=YsBound(GetDefaultGLimit(air),2.0,6.0);
 const double rollTime=YsAbs(bank)/YsDegToRad(70.0);
 const double reserve=margin+down*(1.5+rollTime)+down*down/(2.0*YsGreater(3.0,(gLimit-1.0)*FsGravityConst*0.5));
 if((clearance<reserve && (down>1.0 || clearance<margin)) || cos(bank)<0.2)recovering=true;
 if(recovering && velocity.y()>0.0 && clearance>margin+20.0 && YsAbs(bank)<YsDegToRad(20.0))recovering=false;
 p.NeutralDirectAttitudeControl();p.SetBrake(0.0);
 const double weight=p.GetTotalWeight()*FsGravityConst;
 // Reference landing speed alone is not a safe true-airspeed limit at altitude.
 const double liftAt100=YsGreater(1.0,p.GetLift(p.GetCriticalAOA()*0.7,100.0));
 const double levelSpeed=YsGreater(25.0,100.0*sqrt(weight*1.15/liftAt100));
 const double availableG=p.GetLift(p.GetCriticalAOA()*0.8,p.GetVelocity())/YsGreater(1.0,weight);
 const double minSpeed=levelSpeed/sqrt(YsGreater(0.4,cos(bank)));
 if(recovering)
 {
  p.BankController(0.0,YsDegToRad(100.0));p.SetSpoiler(0.0);
  p.GController(cos(bank)>0.3 ? YsBound(1.6+down*0.18,1.6,gLimit) : cos(bank)<-0.3 ? -0.5 : 0.0);
  p.SpeedController(YsGreater(minSpeed,leadVelocity.GetLength()));mode=FSFOMMODE_RECOVER_FROM_LOWALT;
 }
 else
 {
  YsAtt3 yaw=air.GetAttitude();yaw.SetP(0.0);yaw.SetB(0.0);YsVec3 local;yaw.MulInverse(local,wantedVelocity);
  const double bearing=atan2(-local.x(),local.z());
  double bankLimit=YsSmaller(acos(1.0/(gLimit-0.3)),YsDegToRad(clearance<120.0 ? 35.0 : clearance<200.0 ? 55.0 : 75.0));
  if(gLimit<3.1)bankLimit=YsSmaller(bankLimit,YsDegToRad(35.0));
  bankLimit=YsSmaller(bankLimit,acos(1.0/YsGreater(1.01,availableG*0.85)));
  if(p.GetVelocity()<minSpeed*1.05)bankLimit=YsSmaller(bankLimit,YsDegToRad(20.0));
  const double feedforward=atan2(wantedVelocity.GetLength()*formationTurnRate,FsGravityConst);
  p.BankController(YsBound(bearing*2.4+feedforward,-bankLimit,bankLimit),YsDegToRad(60.0));
  const double targetHeight=YsGreater(safeGoal.y()+avoidance,safeTerrain+margin);
  const double descent=YsBound((clearance-margin)/4.0,2.0,45.0);
  const double desiredClimb=YsBound(leadVelocity.y()+(targetHeight-air.GetPosition().y())/3.0,-descent,35.0);
  // Positive lift throughout normal following. The old pursuit path allowed -3G.
  const double requestedG=(1.0+(desiredClimb-velocity.y())*0.15)/YsGreater(0.25,cos(bank));
  const double minimumG=(clearance>200.0 ? 0.25 : 0.6);
  p.GController(YsBound(requestedG,minimumG,YsGreater(minimumG,YsSmaller(gLimit,availableG*0.9))));
  const double desiredSpeed=(YsAbs(bearing)>YsDegToRad(45.0) ? YsSmaller(leadVelocity.GetLength(),wantedVelocity.GetLength()) : wantedVelocity.GetLength());
  p.SpeedController(YsGreater(minSpeed,desiredSpeed));
  mode=(error.GetLength()<YsGreater(30.0,air.GetApproximatedCollideRadius()*1.5) && YsAbs(bearing)<YsDegToRad(12.0) ? FSFOMMODE_INPOSITION : FSFOMMODE_LOSTPOSITION);
 }
 p.SetGControllerAOALimit(-p.GetCriticalAOA()*0.4,p.GetCriticalAOA()*(recovering ? 0.95 : 0.8));
 p.SetGear(leader->Prop().GetLandingGear());p.SetFlap(leader->Prop().GetFlap());p.SetRudder(0.0);p.SmartRudder(dt);
 return YSOK;
}
