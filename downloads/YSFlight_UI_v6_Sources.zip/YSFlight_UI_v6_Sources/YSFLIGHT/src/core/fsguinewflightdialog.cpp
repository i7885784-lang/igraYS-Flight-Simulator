#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stddef.h>
#include <time.h>

#include <ysclass.h>
#include <ysport.h>
#define FSSIMPLEWINDOW_DONT_INCLUDE_OPENGL_HEADERS
#include <fssimplewindow.h>

#include "fsconfig.h"

#include "fs.h"
#include "fsfilename.h"
#include "platform/common/fswindow.h"
#include "graphics/common/fsopengl.h"

#include "graphics/common/fsopengl.h"
#include "fswirefont.h"

#include "ysunitconv.h"


#ifdef WIN32
#include <float.h>
#include <direct.h>
#else
#include <unistd.h>
#endif

#include <ysbitmap.h>

#include "fsgui.h"
#include <fsguifiledialog.h>
#include "fsguiselectiondialogbase.h"
#include "fschoose.h"

#include "fstextresource.h"

#include "fsguinewflightdialog.h"


FsNewFlightDialogOption::FsNewFlightDialogOption()
{
	canSelectField=YSTRUE;
	canSelectStartPosition=YSTRUE;
	canSelectLoading=YSTRUE;
	canSelectEnvironment=YSTRUE;
	canSelectWingmen=YSTRUE;
	canChooseNight=YSTRUE;
	canChooseFomType=YSTRUE;
	flyNowButton=YSTRUE;
	forRacingMode=YSFALSE;
	nextStartPos=YSFALSE;
}


////////////////////////////////////////////////////////////



FsNewSimulationDialogTemplate::FsNewSimulationDialogTemplate()
{
	world=NULL;

	fieldLabel=NULL;
	field=NULL;

	addComputerAircraft=NULL;

	specifyEnvironment=NULL;

	dayNight[0]=NULL;
	dayNight[1]=NULL;
	windDir=NULL;
	windSpd=NULL;
	visibility=NULL;
}

void FsNewSimulationDialogTemplate::AddFieldSelector(YSBOOL forRacingMode)
{
	fieldLabel=AddStaticText(1,FSKEY_NULL,FSGUI_COMMON_FIELD,YSTRUE);
	fieldLabel->SetDrawFrame(YSFALSE);
	fieldLabel->SetFill(YSFALSE);

	field=AddEmptyListBox(MkId("fieldList"),FSKEY_NULL,"",6,32,YSTRUE);
	fieldSearch=AddTextBox(MkId("fieldSearch"),FSKEY_NULL,FSGUI_AIRDLG_SEARCH,"",32,YSTRUE);

	PopulateFieldList(world,field,"",forRacingMode);

	addComputerAircraft=AddTextButton(0,FSKEY_NULL,FSGUI_CHECKBOX,FSGUI_NEWFLTDLG_ADDCOMPUTERAIRCRAFT,YSTRUE);
	addComputerAircraft->SetCheck(YSTRUE);
}

void FsNewSimulationDialogTemplate::AddDayNightSelector(void)
{
	if(NULL==specifyEnvironment)
	{
		specifyEnvironment=AddTextButton(1,FSKEY_NULL,FSGUI_CHECKBOX,FSGUI_NEWFLTDLG_SPECIFYENVIRON,YSTRUE);
	}

	dayNight[0]=AddTextButton(1,FSKEY_NULL,FSGUI_RADIOBUTTON,FSGUI_NEWFLTDLG_DAY  ,YSTRUE);
	dayNight[1]=AddTextButton(1,FSKEY_NULL,FSGUI_RADIOBUTTON,FSGUI_NEWFLTDLG_NIGHT,YSFALSE);
	SetRadioButtonGroup(2,dayNight);
}

void FsNewSimulationDialogTemplate::AddWeatherSelector(void)
{
	if(NULL==specifyEnvironment)
	{
		specifyEnvironment=AddTextButton(1,FSKEY_NULL,FSGUI_CHECKBOX,FSGUI_NEWFLTDLG_SPECIFYENVIRON,YSTRUE);
	}

	AddStaticText(1,FSKEY_NULL,FSGUI_NEWFLTDLG_WEATHER,YSTRUE);
	windDir=AddNumberBox(1,FSKEY_NULL,FSGUI_NEWFLTDLG_WINDDIR,16,0,-360,360,10,YSTRUE);
	windSpd=AddNumberBox(1,FSKEY_NULL,FSGUI_NEWFLTDLG_WINDSPD,16,0,0,50,1,YSTRUE);
	visibility=AddNumberBox(1,FSKEY_NULL,FSGUI_NEWFLTDLG_VISIBILITY,16,20,0,20,1,YSTRUE);


	AddStaticText(1,FSKEY_NULL,FSGUI_NEWFLTDLG_OVERCASTLAYER,YSTRUE);
	for(int i=0; i<MAXNUMCLOUDLAYER; i++)
	{
		overCastLayerSw[i]=AddTextButton(1,FSKEY_NULL,FSGUI_CHECKBOX,"",YSTRUE);
		AddStaticText(1,FSKEY_NULL,FSGUI_NEWFLTDLG_OVERCASTFLOOR,YSFALSE);
		overCastLayerFloor[i]=AddNumberBox(1,FSKEY_NULL,"",6,0,0,25000,200,YSFALSE);
		overCastLayerFloor[i]->SetNumber(800+i*3000);
		AddStaticText(1,FSKEY_NULL,FSGUI_NEWFLTDLG_OVERCASTTHICKNESS,YSFALSE);
		overCastLayerThickness[i]=AddNumberBox(1,FSKEY_NULL,"",6,0,0,5000,100,YSFALSE);
		overCastLayerThickness[i]->SetNumber(300);
	}
}

void FsNewSimulationDialogTemplate::ResetStpListBySearchKeyword(FsWorld *world,FsGuiDropList *stpList,FsGuiTextBox *stpSearch)
{
	YsString fieldName;
	if(nullptr!=field)
	{
		fieldName=field->GetSelectedString();

		YsString curSel;
		if(nullptr!=stpList)
		{
			curSel=stpList->GetSelectedString();
		}

		YsArray <YsString,16> searchKeyWord;
		if(nullptr!=stpSearch)
		{
			YsString str=stpSearch->GetString();
			if(0<str.Strlen())
			{
				str.Capitalize();
				str.Arguments(searchKeyWord);
			}
		}


		YsString stp;
		YsArray <YsString> stpCandidate;
		for(int i=0; world->GetFieldStartPositionName(stp,fieldName,i)==YSOK; i++)
		{
			for(auto kw : searchKeyWord)
			{
				if(YSTRUE!=stp.FINDWORD(nullptr,kw))
				{
					goto SKIP;
				}
			}
			stpCandidate.Append(stp);

		SKIP:
			;
		}

		if(0<stpCandidate.GetN())
		{
			stpList->SetChoice(stpCandidate);
			stpList->SelectByString(curSel);
			if(0>stpList->GetSelection())
			{
				stpList->Select(0);
			}
		}
	}
}

void FsNewSimulationDialogTemplate::OnListBoxSelChange(FsGuiListBox *lbx,int /*prevSel*/)
{
	if(lbx==field)
	{
		FieldSelectionChanged();
	}
}

void FsNewSimulationDialogTemplate::OnButtonClick(FsGuiButton *btn)
{
	YSBOOL envButton=YSFALSE;

	if(btn==dayNight[0] || btn==dayNight[1])
	{
		envButton=YSTRUE;
	}

	for(int i=0; i<MAXNUMCLOUDLAYER; i++)
	{
		if(btn==overCastLayerSw[i])
		{
			envButton=YSTRUE;
		}
	}
	
	if(YSTRUE==envButton && NULL!=specifyEnvironment)
	{
		specifyEnvironment->SetCheck(YSTRUE);
	}
}

void FsNewSimulationDialogTemplate::OnNumberBoxChange(FsGuiNumberBox *nbx,int /*prevNum*/)
{
	YSBOOL envButton=YSFALSE;

	if(nbx==windDir ||
	   nbx==windSpd ||
	   nbx==visibility)
	{
		envButton=YSTRUE;
	}

	enum
	{
		MAXNUMCLOUDLAYER=3
	};

	for(int i=0; i<MAXNUMCLOUDLAYER; i++)
	{
		if(nbx==overCastLayerFloor[i] || nbx==overCastLayerThickness[i])
		{
			envButton=YSTRUE;
		}
	}
	
	if(YSTRUE==envButton && NULL!=specifyEnvironment)
	{
		specifyEnvironment->SetCheck(YSTRUE);
	}
}



////////////////////////////////////////////////////////////


FsGuiNewFlightDialogClass::FsGuiNewFlightDialogClass()
{
	chooseAircraftDialog=new FsGuiChooseAircraft;
}

FsGuiNewFlightDialogClass::FsGuiNewFlightDialogClass(YSBOOL canSelectWingmen,YSBOOL canChooseNight,YSBOOL canChooseFomType,YSBOOL canChooseFlyNow)
{
	chooseAircraftDialog=new FsGuiChooseAircraft;

	FsNewFlightDialogOption opt;
	opt.canSelectWingmen=canSelectWingmen;
	opt.canChooseNight=canChooseNight;
	opt.canChooseFomType=canChooseFomType;
	opt.flyNowButton=canChooseFlyNow;
	InitialSetUp(opt);
}

FsGuiNewFlightDialogClass::FsGuiNewFlightDialogClass(const FsNewFlightDialogOption &opt)
{
	chooseAircraftDialog=new FsGuiChooseAircraft;

	InitialSetUp(opt);
}

FsGuiNewFlightDialogClass::~FsGuiNewFlightDialogClass()
{
	if(NULL!=chooseAircraftDialog)
	{
		delete chooseAircraftDialog;
		chooseAircraftDialog=NULL;
	}
}

void FsGuiNewFlightDialogClass::InitialSetUp(const FsNewFlightDialogOption &opt)
{
	this->option=opt;

	playerAir=NULL;
	changePlayerAir=NULL;

	playerStpLabel=NULL;
	playerStp=NULL;
	playerStpFilter=nullptr;
    interactiveMapPreview=true;
    mapDragging=false;customStartAllowed=false;mapLastX=mapLastY=0;
    customStartCheck=nullptr;mapResetButton=nullptr;
    wingmanCount=wingmanSlot=nullptr;wingmanTabId=-1;
    groupFormationCheck=groupStartCheck=groupMissionCheck=nullptr;
    groupPatternChoice=groupTaskChoice=nullptr;
    groupSpacingBox=groupHeightBox=groupHeadingBox=groupSpeedBox=groupRadiusBox=nullptr;
    for(int i=0;i<MAXNUMWINGMAN;++i) wingmanEnabled[i]=nullptr;
    customHeightBox=nullptr;customHeadingBox=nullptr;customPositionLabel=nullptr;

	for(int i=0; i<MAXNUMWINGMAN; i++)
	{
		wingmanAir[i]=NULL;
		wingmanStpLabel[i]=NULL;
		wingmanStp[i]=NULL;
		changeWingman[i]=NULL;
		removeWingman[i]=NULL;
	}

	okBtn=NULL;
	cancelBtn=NULL;
	flyNowButton=NULL;

	fomType=NULL;

	info.Initialize();
}

void FsGuiNewFlightDialogClass::Make(FsWorld *world)
{
	int i;
	FsGuiGroupBox *grpBox;

	this->world=world;

	// ? FsGuiDialog dlg;
	SetTopLeftCorner(0,0);

	int wid,hei;
	FsGetWindowSize(wid,hei);

	SetSize(wid,hei);

	autoNewColumn=YSFALSE;


	SetTextMessage(FSGUI_NEWFLTDLG_CREATENEWFLIGHT);


	mainTab=AddTabControl(0,FSKEY_NULL,YSTRUE);

	int tabId;
	tabId=AddTab(mainTab,FSGUI_COMMON_GENERAL);
	BeginAddTabItem(mainTab,tabId);
	{
		AddFieldSelector(option.forRacingMode);
		if(YSTRUE!=option.canSelectField)
		{
			field->Disable();
			fieldSearch->Disable();
		}

		playerAir=AddStaticText(1,FSKEY_NULL,"Airplane:",32,1,YSTRUE);
		playerAir->SetDrawFrame(YSFALSE);
		playerAir->SetFill(YSFALSE);
		changePlayerAir=AddTextButton(MkId("playerAirBtn"),FSKEY_NULL,FSGUI_PUSHBUTTON,FSGUI_NEWFLTDLG_SELAIR,YSTRUE);

    }
    EndAddTabItem();

    tabId=AddTab(mainTab,FsGetTextResource("startdlg/tab",L"Start"));
    BeginAddTabItem(mainTab,tabId);
    {
		playerStpLabel=AddStaticText(1,FSKEY_NULL,FSGUI_COMMON_STP,YSTRUE);
		playerStpLabel->SetDrawFrame(YSFALSE);
		playerStpLabel->SetFill(YSFALSE);
		playerStp=AddEmptyDropList(MkId("playerStpList"),FSKEY_NULL,"",16,16,32,YSFALSE);
		playerStpFilter=AddTextBox(0,FSKEY_NULL,"","",32,YSTRUE);

		if(YSTRUE!=option.canSelectStartPosition)
		{
			playerStp->Disable();
			playerStpFilter->Disable();
		}

        customStartCheck=AddTextButton(MkId("customStart"),FSKEY_NULL,FSGUI_CHECKBOX,FsGetTextResource("startdlg/custom",L"Custom point on map"),YSTRUE);
        AddStaticText(0,FSKEY_NULL,FsGetTextResource("startdlg/pickhint",L"Click on the map to choose your position."),YSTRUE);
        customHeightBox=AddTextBox(MkId("customHeight"),FSKEY_NULL,FsGetTextResource("startdlg/height",L"Height AGL (m)"),"0",6,YSTRUE);
        customHeightBox->SetTextType(FSGUI_INTEGER);customHeightBox->SetLengthLimit(5);customHeightBox->SetSelectAllWhenGetFocus(YSTRUE);
        customHeadingBox=AddTextBox(MkId("customHeading"),FSKEY_NULL,FsGetTextResource("startdlg/heading",L"Heading (deg)"),"0",6,YSTRUE);
        customHeadingBox->SetTextType(FSGUI_INTEGER);customHeadingBox->SetLengthLimit(3);customHeadingBox->SetSelectAllWhenGetFocus(YSTRUE);
        customPositionLabel=AddStaticText(0,FSKEY_NULL,L"",32,2,YSTRUE);
        AddStaticText(0,FSKEY_NULL,FsGetTextResource("startdlg/groundhint",L"0 m: ground start. Choose a clear, level area."),YSTRUE);
        mapResetButton=AddTextButton(MkId("mapReset"),FSKEY_NULL,FSGUI_PUSHBUTTON,FsGetTextResource("startdlg/resetmap",L"Show entire map"),YSTRUE);
    }
    EndAddTabItem();



    if(option.canSelectWingmen==YSTRUE)
    {
        wingmanTabId=AddTab(mainTab,FSGUI_NEWFLTDLG_WINGMAN);
        BeginAddTabItem(mainTab,wingmanTabId);
        const wchar_t *counts[]={L"0",L"1",L"2",L"3",L"4",L"5",L"6",L"7",L"8"};
        AddStaticText(0,FSKEY_NULL,FsGetTextResource("v4/count",L"Wingmen"),YSTRUE);
        wingmanCount=AddDropList(MkId("wingmanCount"),FSKEY_NULL,L"",9,counts,9,3,3,YSFALSE);
        wingmanCount->Select(0);
        AddStaticText(0,FSKEY_NULL,FsGetTextResource("v4/slot",L"Edit wingman"),YSTRUE);
        wingmanSlot=AddDropList(MkId("wingmanSlot"),FSKEY_NULL,L"",8,counts+1,8,3,3,YSFALSE);
        wingmanSlot->Select(0);
        // All slots occupy the same area. Only the selected slot is shown.
        const int rowY=wingmanSlot->y0+wingmanSlot->hei+8;
        for(i=0;i<MAXNUMWINGMAN;++i)
        {
            SetNextTabItemY(rowY);
            wingmanEnabled[i]=AddTextButton(0,FSKEY_NULL,FSGUI_CHECKBOX,FsGetTextResource("v4/enabled",L"Include this wingman"),YSTRUE);
            wingmanAir[i]=AddStaticText(0,FSKEY_NULL,L"",36,1,YSTRUE);
            wingmanAir[i]->SetDrawFrame(YSFALSE);wingmanAir[i]->SetFill(YSFALSE);
            changeWingman[i]=AddTextButton(0,FSKEY_NULL,FSGUI_PUSHBUTTON,FsGetTextResource("v4/airweapons",L"Aircraft and weapons..."),YSTRUE);
            removeWingman[i]=AddTextButton(0,FSKEY_NULL,FSGUI_PUSHBUTTON,FSGUI_COMMON_DELETE,YSFALSE);
            wingmanStpLabel[i]=AddStaticText(0,FSKEY_NULL,FSGUI_COMMON_STP,YSTRUE);
            wingmanStp[i]=AddEmptyDropList(0,FSKEY_NULL,"",12,16,26,YSTRUE);
        }
        AddStaticText(0,FSKEY_NULL,FsGetTextResource("v4/winghint",L"Each number has its own aircraft, weapons and start position."),YSTRUE);
        EndAddTabItem();
    }

    if(YSTRUE==option.canSelectWingmen && YSTRUE==option.canChooseFomType)
    {
        tabId=AddTab(mainTab,FSGUI_NEWFLTDLG_FORMATION);
        BeginAddTabItem(mainTab,tabId);
        groupFormationCheck=AddTextButton(MkId("groupFormation"),FSKEY_NULL,FSGUI_CHECKBOX,FsGetTextResource("v4/formation",L"Customize formation (air start)"),YSTRUE);
        const wchar_t *patterns[]={FsGetTextResource("v4/pattern0",L"Diamond"),FsGetTextResource("v4/pattern1",L"Delta"),FsGetTextResource("v4/pattern2",L"V formation"),FsGetTextResource("v4/pattern3",L"Column"),FsGetTextResource("v4/pattern4",L"Line abreast"),FsGetTextResource("v4/pattern5",L"Echelon left"),FsGetTextResource("v4/pattern6",L"Echelon right")};
        groupPatternChoice=AddDropList(MkId("groupPattern"),FSKEY_NULL,L"",7,patterns,7,18,18,YSTRUE);groupPatternChoice->Select(0);
        groupSpacingBox=AddTextBox(MkId("groupSpacing"),FSKEY_NULL,FsGuiTextBox::HORIZONTAL,FsGetTextResource("v4/spacing",L"Spacing, m (50-5000)"),"150",6,YSTRUE);
        groupFormationCheck->SetCheck(YSFALSE);
        groupStartCheck=AddTextButton(MkId("groupStart"),FSKEY_NULL,FSGUI_CHECKBOX,FsGetTextResource("v4/groupstart",L"Common airborne start"),YSTRUE);
        groupHeightBox=AddTextBox(MkId("groupHeight"),FSKEY_NULL,FsGuiTextBox::HORIZONTAL,FsGetTextResource("v4/groupheight",L"Height above terrain, m"),"1000",5,YSTRUE);
        groupHeadingBox=AddTextBox(MkId("groupHeading"),FSKEY_NULL,FsGuiTextBox::HORIZONTAL,FsGetTextResource("v4/groupheading",L"Heading, deg (0-359)"),"0",5,YSTRUE);
        groupSpeedBox=AddTextBox(MkId("groupSpeed"),FSKEY_NULL,FsGuiTextBox::HORIZONTAL,FsGetTextResource("v4/groupspeed",L"Speed, km/h (0 = automatic)"),"0",5,YSTRUE);
        groupMissionCheck=AddTextButton(MkId("groupMission"),FSKEY_NULL,FSGUI_CHECKBOX,FsGetTextResource("v4/mission",L"Wingman mission (air start)"),YSTRUE);
        const wchar_t *tasks[]={FsGetTextResource("v4/task0",L"Follow player"),FsGetTextResource("v4/task1",L"Patrol"),FsGetTextResource("v4/task2",L"Attack hostile aircraft"),FsGetTextResource("v4/task3",L"Attack hostile ground targets")};
        groupTaskChoice=AddDropList(MkId("groupTask"),FSKEY_NULL,L"",4,tasks,4,30,30,YSTRUE);groupTaskChoice->Select(0);
        groupRadiusBox=AddTextBox(MkId("groupRadius"),FSKEY_NULL,FsGuiTextBox::HORIZONTAL,FsGetTextResource("v4/patrolradius",L"Patrol radius, km (1-50)"),"5",5,YSTRUE);
        AddStaticText(0,FSKEY_NULL,FsGetTextResource("v4/grouphint",L"Unchecked = standard settings. Formation/missions start in the air.\nDefault height: 1000 m. Attack needs enemies and suitable weapons."),YSTRUE);
        for(auto box : {groupSpacingBox,groupHeightBox,groupHeadingBox,groupSpeedBox,groupRadiusBox})
        { box->SetTextType(FSGUI_INTEGER);box->SetLengthLimit(5);box->SetSelectAllWhenGetFocus(YSTRUE); }
        EndAddTabItem();
    }



	tabId=AddTab(mainTab,FSGUI_NEWFLTDLG_ENVIRON);
	BeginAddTabItem(mainTab,tabId);
	{
		if(option.canChooseNight==YSTRUE)
		{
			AddDayNightSelector();
			InsertVerticalSpace(4);
		}
		else
		{
			dayNight[0]=NULL;
			dayNight[1]=NULL;
		}

		AddWeatherSelector();
	}
	EndAddTabItem();

	if(YSTRUE!=option.canSelectEnvironment)
	{
		mainTab->DisableTab(tabId);
	}
	mainTab->SelectFirstTab();

	StepToNextColumn();

	okBtn=AddTextButton(MakeIdent("ok"),FSKEY_NULL,FSGUI_PUSHBUTTON,FSGUI_COMMON_OK,YSTRUE);
	cancelBtn=AddTextButton(MakeIdent("cancel"),FSKEY_ESC,FSGUI_PUSHBUTTON,FSGUI_COMMON_CANCEL,YSFALSE);

	flyNowButton=AddTextButton(MakeIdent("flynow"),FSKEY_ESC,FSGUI_PUSHBUTTON,FSGUI_NEWFLTDLG_FLYNOW,YSTRUE);
	if(YSTRUE!=option.flyNowButton)
	{
		flyNowButton->Disable();
	}

	ExpandTab(mainTab);
	Fit();
	SetBackgroundAlpha(1.0);
    UpdateStartControls();
    UpdateWingmanControls();UpdateGroupControls();
}

void FsGuiNewFlightDialogClass::FieldSelectionChanged(void)
{
    info.customStart=YSFALSE;
    mapDragging=false;

	int i;
	YsString str;

	field->GetSelectedString(info.fieldName);

	if(playerStp!=NULL)
	{
		ResetStartPosChoice(playerStp,world,info.fieldName);
		playerStp->SelectByString(info.playerAirInfo.startPos,YSTRUE);
		playerStp->GetSelectedString(info.playerAirInfo.startPos);
	}


	YsString wingmanPos[MAXNUMWINGMAN];
	MakeDefaultWingmanPosition(wingmanPos);
	for(i=0; i<MAXNUMWINGMAN; i++)
	{
		info.wingmanInfo[i].startPos=wingmanPos[i];
		if(wingmanStp[i]!=NULL)
		{
			wingmanStp[i]->SelectByString(wingmanPos[i]);
		}
	}


	ReloadField(world,info.fieldName);
	ReloadStartPos(world,info.fieldName,info.playerAirInfo.startPos);
    UpdateStartControls();
    UpdateWingmanControls();UpdateGroupControls();
}

void FsGuiNewFlightDialogClass::ResetStartPosChoice(FsGuiDropList *dropList,FsWorld *world,const char fldName[])
{
	YsString stp;
	YsArray <YsString> stpList;

	for(int i=0; world->GetFieldStartPositionName(stp,fldName,i)==YSOK; i++)
	{
		stpList.Append(stp);
	}

	dropList->SetChoice(stpList.GetN(),stpList);
}

void FsGuiNewFlightDialogClass::InitializeDialog(FsWorld *world,const FsNewFlightDialogInfo &info)
{
	int i;
	YsString str;
	char buf[256];


	this->info=info;
	this->world=world;

	this->info.envInfo.specifyEnvironment=YSFALSE;  // By default, turn it off.

	if(field!=NULL)
	{
		field->SelectByString(info.fieldName,YSTRUE);
	}

	YsString selectedFieldName=info.fieldName,selectedStp=info.playerAirInfo.startPos;
	if(nullptr!=field)
	{
		selectedFieldName=field->GetSelectedString();
	}

	if(playerStp!=NULL)
	{
		ResetStartPosChoice(playerStp,world,selectedFieldName);
		playerStp->SelectByString(info.playerAirInfo.startPos,YSTRUE);  // selectFirstIfNoMatch=YSTRUE
		if(YSTRUE==info.nextStartPos)
		{
			const int newSel=playerStp->GetSelection()+1;
			if(newSel<playerStp->GetNumChoice())
			{
				playerStp->Select(newSel);
				playerStp->GetSelectedString(this->info.playerAirInfo.startPos);
			}
		}
	}

	if(playerAir!=NULL)
	{
		YsWString label(FSGUI_AIRDLG_AIRCRAFT),name;
        name.SetUTF8String(info.playerAirInfo.typeName);
        label.Append(L": ");
        label.Append(name);
        playerAir->SetText(label);
	}

	if(nullptr!=playerStp)
	{
		selectedStp=playerStp->GetSelectedString();
	}
	ReloadField(world,selectedFieldName);
	ReloadStartPos(world,selectedFieldName,selectedStp);

	for(i=0; i<MAXNUMWINGMAN; i++)
	{
		if(info.wingmanInfo[i].typeName[0]!=0)
		{
			if(wingmanAir[i]!=NULL)
			{
				sprintf(buf,"Wingman %d:%s",i+1,(const char *)info.wingmanInfo[i].typeName);
				wingmanAir[i]->SetText(buf);
			}
			if(wingmanStp[i]!=NULL)
			{
				ResetStartPosChoice(wingmanStp[i],world,info.fieldName);
				wingmanStp[i]->SelectByString(info.wingmanInfo[i].startPos);
				wingmanStp[i]->Enable();
			}
		}
		else
		{
			if(wingmanAir[i]!=NULL)
			{
				sprintf(buf,"Wingman %d:None",i+1);
				wingmanAir[i]->SetText(buf);
			}
			if(wingmanStp[i]!=NULL)
			{
				wingmanStp[i]->Disable();
			}
		}
	}



	if(dayNight[0]!=NULL && dayNight[1]!=NULL)
	{
		if(info.envInfo.dayOrNight==FSDAYLIGHT)
		{
			dayNight[0]->SetCheck(YSTRUE);
			dayNight[1]->SetCheck(YSFALSE);
		}
		else
		{
			dayNight[0]->SetCheck(YSFALSE);
			dayNight[1]->SetCheck(YSTRUE);
		}
	}



	if(windDir!=NULL)
	{
		i=(int)(info.envInfo.windDir*180.0/YsPi);
		if(i<0)
		{
			i+=360;
		}
		windDir->SetNumber(i);
	}
	if(windSpd!=NULL)
	{
		double v;
		v=info.envInfo.windSpd;
		v=v*3600.0/1852.0;
		windSpd->SetNumber((int)v);
	}
	if(visibility!=NULL)
	{
		double v;
		if(info.envInfo.fog==YSTRUE)
		{
			v=info.envInfo.fogVisibility;
			v/=1609.0;
			visibility->SetNumber((int)v);
		}
		else
		{
			visibility->SetNumber(20);
		}
	}
    if(nullptr!=customHeightBox) customHeightBox->SetInteger(int(this->info.customStartHeight));
    if(nullptr!=customHeadingBox) customHeadingBox->SetInteger(int(this->info.customStartHeading));
    UpdateStartControls();
    UpdateWingmanControls();UpdateGroupControls();
}

void FsGuiNewFlightDialogClass::MakeDefaultWingmanPosition(YsString str[])
{
	int i,j;
	YsString idName;

	for(i=0; i<MAXNUMWINGMAN; i++)
	{
		str[i].Set("");
	}

	for(i=0; world->GetFieldStartPositionName(idName,info.fieldName,i)==YSOK; i++)
	{
		if(strcmp(info.playerAirInfo.startPos,idName)==0)
		{
			break;
		}
	}

	j=0;
	for(i=i+1; j<MAXNUMWINGMAN && world->GetFieldStartPositionName(idName,info.fieldName,i)==YSOK; i++)
	{
		str[j++]=idName;
	}
    // If the player chose a late entry, use the earlier unused positions as well.
    for(i=0;j<MAXNUMWINGMAN && world->GetFieldStartPositionName(idName,info.fieldName,i)==YSOK;++i)
    {
        if(idName==info.playerAirInfo.startPos) continue;
        bool used=false;for(int k=0;k<j;++k) if(str[k]==idName) used=true;
        if(!used) str[j++]=idName;
    }
}

void FsGuiNewFlightDialogClass::RefreshCloudLayer(void)
{
	info.envInfo.cloudLayer.Clear();
	for(int i=0; i<MAXNUMCLOUDLAYER; i++)
	{
		if(YSTRUE==overCastLayerSw[i]->GetCheck())
		{
			double flr,top;
			flr=(double)overCastLayerFloor[i]->GetNumber();
			top=flr+(double)overCastLayerThickness[i]->GetNumber();

			flr=YsUnitConv::FTtoM(flr);
			top=YsUnitConv::FTtoM(top);

			info.envInfo.cloudLayer.Append(flr);
			info.envInfo.cloudLayer.Append(top);
		}
	}
}

void FsGuiNewFlightDialogClass::Show(const FsGuiDialog *excludeFromDrawing) const
{
    int width,height;FsGetWindowSize(width,height);
    YsColor background,panel,border;
    background.SetIntRGB(30,39,50);panel.SetIntRGB(43,58,74);border.SetIntRGB(104,128,150);
    FsDrawRect(0,0,width-1,height-1,background,YSTRUE);
    int x,y,w,h;GetPreviewArea(x,y,w,h,YSTRUE);
    FsDrawRect(x-1,y-1,x+w,y+h,panel,YSTRUE);
    FsDrawRect(x-1,y-1,x+w,y+h,border,YSFALSE);
    FsDrawString(x,y-28,FSGUI_AIRDLG_AIRCRAFT,YsWhite());
    GetPreviewArea(x,y,w,h,YSFALSE);
    FsDrawRect(x-1,y-1,x+w,y+h,border,YSFALSE);
    FsDrawString(x,y-28,FSGUI_COMMON_FIELD,YsWhite());
    DrawField(world,YSTRUE,YSTRUE,YSFALSE,YsOrigin());
    YsAtt3 att;att.Set(YsPi/2.0,0.0,YsPi/2.0);
    DrawAirplane(world,info.playerAirInfo.typeName,att,info.playerAirInfo.weaponConfig.GetN(),info.playerAirInfo.weaponConfig,YSTRUE);
    FsDrawString(x,y+h+20,FsGetTextResource("startdlg/maphelp",L"Wheel: zoom | Right drag: pan"),YsWhite());
    FsDrawString(x,y+h+40,(customStartAllowed ? FsGetTextResource("startdlg/maphelp2",L"Middle: reset | Left: start point") : FsGetTextResource("startdlg/maphelp2disabled",L"Middle: reset")),YsWhite());
    if(info.customStart==YSTRUE)
    {
        YsWString status(FsGetTextResource("startdlg/selected",L"Custom start"));
        YsString value;if(w>=600) value.Printf("  X %.0f / Z %.0f  |  %.0f m AGL",info.customStartPosition.x(),info.customStartPosition.z(),info.customStartHeight);
        else value.Printf(" | %.0f m AGL",info.customStartHeight);
        YsWString wide;wide.SetUTF8String(value);status.Append(wide);
        FsDrawString(x,y+h+60,status,YsYellow());
    }
    FsNewSimulationDialogTemplate::Show(excludeFromDrawing);
}

void FsGuiNewFlightDialogClass::UpdateStartControls(void)
{
    if(nullptr==customStartCheck) return;
    const bool custom=(info.customStart==YSTRUE);
    customStartCheck->SetCheck(info.customStart);
    customStartCheck->Enable();
    if(custom) { customHeightBox->Enable();customHeadingBox->Enable();playerStp->Disable();playerStpFilter->Disable(); }
    else { customHeightBox->Disable();customHeadingBox->Disable();playerStp->Enable();playerStpFilter->Enable(); }
    if(!customStartAllowed)
    {
        customStartCheck->Disable();customHeightBox->Disable();customHeadingBox->Disable();
    }
    if(option.canSelectStartPosition!=YSTRUE)
    {
        customStartCheck->Disable();customHeightBox->Disable();customHeadingBox->Disable();
        playerStp->Disable();playerStpFilter->Disable();
    }
    if(nullptr!=fomType)
    {
        if(custom) { info.fomType=FSFOM_NONE;fomType->Select(0);fomType->Disable(); }
        else fomType->Enable();
    }
    YsString number;number.Printf("X: %.0f m\nZ: %.0f m",info.customStartPosition.x(),info.customStartPosition.z());
    customPositionLabel->SetText(number);
    if(custom) { stpPos=info.customStartPosition;stpLoaded=YSTRUE; }
    SetNeedRedraw(YSTRUE);
}

void FsGuiNewFlightDialogClass::SelectCustomStart(const YsVec3 &pos)
{
    if(option.canSelectStartPosition!=YSTRUE || !customStartAllowed) return;
    info.customStart=YSTRUE;info.customStartPosition=pos;
    info.customStartHeight=customHeightBox->GetInteger();
    info.customStartHeading=customHeadingBox->GetInteger();
    UpdateStartControls();
    UpdateWingmanControls();UpdateGroupControls();
}

void FsGuiNewFlightDialogClass::HandlePreviewMouse(int eventType,YSBOOL,YSBOOL,YSBOOL rb,int mx,int my)
{
    const auto view=GetMapPreviewTransform();
    if(FSMOUSEEVENT_RBUTTONDOWN==eventType && view.Contains(mx,my)) mapDragging=true;
    if(mapDragging && rb==YSTRUE && FSMOUSEEVENT_MOVE==eventType)
    {
        PanMapPreview(mx-mapLastX,my-mapLastY);
    }
    if(rb!=YSTRUE) mapDragging=false;
    if(FSMOUSEEVENT_MBUTTONDOWN==eventType && view.Contains(mx,my))
    {
        ResetMapPreview();SetNeedRedraw(YSTRUE);
    }
    if(FSMOUSEEVENT_LBUTTONDOWN==eventType && view.Contains(mx,my))
    {
        YsVec3 pos;if(PickMapPoint(pos,mx,my)) SelectCustomStart(pos);
    }
    mapLastX=mx;mapLastY=my;
}

void FsGuiNewFlightDialogClass::OnButtonClick(FsGuiButton *btn)
{
    if(btn!=nullptr && (btn==groupFormationCheck || btn==groupStartCheck || btn==groupMissionCheck))
    { CaptureGroupOptions();UpdateGroupControls();UpdateWingmanControls();return; }
    for(int i=0;i<MAXNUMWINGMAN;++i)
    {
        if(btn!=nullptr && btn==wingmanEnabled[i])
        {
            info.wingman[i]=wingmanEnabled[i]->GetCheck();
            if(info.wingman[i]==YSTRUE && info.wingmanInfo[i].typeName.Strlen()==0)
            {
                info.wingmanInfo[i]=info.playerAirInfo;
                YsString positions[MAXNUMWINGMAN];MakeDefaultWingmanPosition(positions);info.wingmanInfo[i].startPos=positions[i];
            }
            UpdateWingmanControls();return;
        }
    }
	FsNewSimulationDialogTemplate::OnButtonClick(btn);
    if(btn==mapResetButton) { ResetMapPreview();SetNeedRedraw(YSTRUE);return; }
    if(btn==customStartCheck)
    {
        if(customStartCheck->GetCheck()==YSTRUE)
        {
            YsVec3 point=stpPos;
            if(stpLoaded!=YSTRUE)
            {
                const auto view=GetMapPreviewTransform();PickMapPoint(point,int(view.cx),int(view.cy));
            }
            SelectCustomStart(point);
        }
        else
        {
            info.customStart=YSFALSE;
            ReloadStartPos(world,info.fieldName,info.playerAirInfo.startPos);
            UpdateStartControls();
        }
        return;
    }


	/* if(btn!=NULL && btn==changePlayerStp)
	{
		FsGuiChooseField chooseFld;

		YsString fld,stp,str;
		if(chooseFld.SelectFieldAndStp(fld,stp,world,info.fieldName,info.playerAirInfo.startPos)==YSOK)
		{
			info.fieldName.Set(chooseFld.GetSelectedField());
			info.playerAirInfo.startPos.Set(chooseFld.GetSelectedStartPos());

			if(field!=NULL)
			{
				str.Set("Field:");
				str.Append(info.fieldName);
				field->SetText(str);
			}

			if(playerStp!=NULL)
			{
				str.Set("StartPos:");
				str.Append(info.playerAirInfo.startPos);
				playerStp->SetText(str);
			}

			YsString wingmanPos[MAXNUMWINGMAN];
			MakeDefaultWingmanPosition(wingmanPos);
			for(i=0; i<MAXNUMWINGMAN; i++)
			{
				info.wingmanInfo[i].startPos=wingmanPos[i];
				if(wingmanStp[i]!=NULL)
				{
					str.Set("StartPos:");
					str.Append(wingmanPos[i]);
					wingmanStp[i]->SetText(str);
				}
			}

			ReloadField(world,info.fieldName);
			ReloadStartPos(world,info.fieldName,info.playerAirInfo.startPos);
		}
		return;
	} */

	if(btn!=NULL && btn==changePlayerAir)
	{
		FsGuiChooseAircraftOption opt;
		opt.canSelectLoading=this->option.canSelectLoading;

		chooseAircraftDialog->Initialize();
		chooseAircraftDialog->Create(world,opt,NEWFLIGHT_NEXTACTION_SELECTPLAYERAIRPLANE);
		chooseAircraftDialog->SetDefault(info.playerAirInfo.typeName);

		AttachModalDialog(chooseAircraftDialog);

		return;
	}


	info.envInfo.specifyEnvironment=specifyEnvironment->GetCheck();  // Do it all the time.  It may have changed from other buttons/number box.

	if(btn!=NULL && btn==dayNight[0])
	{
		info.envInfo.dayOrNight=FSDAYLIGHT;
		return;
	}
	if(btn!=NULL && btn==dayNight[1])
	{
		info.envInfo.dayOrNight=FSNIGHT;
		return;
	}

	if(NULL!=btn && btn==addComputerAircraft)
	{
		info.addComputerAircraft=addComputerAircraft->GetCheck();
	}

	for(int i=0; i<MAXNUMCLOUDLAYER; i++)
	{
		if(btn==overCastLayerSw[i])
		{
			RefreshCloudLayer();
		}
	}

	for(int i=0; i<MAXNUMWINGMAN; i++)
	{
		FsGuiChooseField chooseFld;
		YsString defStp,defAir;

		if(info.wingmanInfo[i].typeName.Strlen()>0)
		{
			defAir=info.wingmanInfo[i].typeName;
		}
		else
		{
			defAir=info.playerAirInfo.typeName;
		}

		if(info.wingmanInfo[i].startPos.Strlen()>0)
		{
			defStp=info.wingmanInfo[i].startPos;
		}
		else
		{
			YsString wingmanPos[MAXNUMWINGMAN];
			MakeDefaultWingmanPosition(wingmanPos);
			defStp=wingmanPos[i];
		}

		if(btn!=NULL && btn==changeWingman[i])
		{
			FsGuiChooseAircraftOption opt;
			opt.canSelectLoading=this->option.canSelectLoading;

			chooseAircraftDialog->Initialize();
			chooseAircraftDialog->Create(world,opt,NEWFLIGHT_NEXTACTION_SELECTWINGMAN);
			chooseAircraftDialog->SetDefault(defAir);

			chooseWingmanIdx=i;

			AttachModalDialog(chooseAircraftDialog);
		}
		if(btn!=NULL && btn==removeWingman[i])
		{
			info.wingman[i]=YSFALSE;
			if(wingmanAir[i]!=NULL)
			{
				char buf[256];
				sprintf(buf,"Wingman %d: None",i+1);
				wingmanAir[i]->SetText(buf);
				wingmanStp[i]->Disable();
			}
		}
	}

	UpdateWingmanControls();
	field->GetSelectedString(info.fieldName);
	playerStp->GetSelectedString(info.playerAirInfo.startPos);

    if(btn==flyNowButton || btn==okBtn)
    {
        CaptureGroupOptions();
        // Capture typed values too, even when focus has not moved off a number box.
        info.customStartHeight=YsBound(double(customHeightBox->GetInteger()),0.0,20000.0);
        info.customStartHeading=YsBound(double(customHeadingBox->GetInteger()),0.0,359.0);
    }

	if(btn!=NULL && btn==flyNowButton)
	{
		info.flyImmediately=YSTRUE;
		CloseModalDialog((int)YSOK);
	}

	if(NULL!=btn && btn==okBtn)
	{
		info.flyImmediately=YSFALSE;
		CloseModalDialog((int)YSOK);
	}

	if(NULL!=btn && btn==cancelBtn)
	{
		CloseModalDialog((int)YSERR);
	}
}

void FsGuiNewFlightDialogClass::OnListBoxSelChange(FsGuiListBox *lbx,int prevSel)
{
	FsNewSimulationDialogTemplate::OnListBoxSelChange(lbx,prevSel);
	if(lbx!=NULL && lbx==fomType)
	{
		int sel;
		sel=lbx->GetSelection();
		switch(sel)
		{
		case 0:
			info.fomType=FSFOM_NONE;
			break;
		case 1:
			info.fomType=FSFOM_DIAMOND;
			break;
		case 2:
			info.fomType=FSFOM_DELTA;
			break;
		}
	}
}

void FsGuiNewFlightDialogClass::OnDropListSelChange(FsGuiDropList *drp,int /*prevSel*/)
{
    if(nullptr!=drp && drp==wingmanSlot) { UpdateWingmanControls();return; }
    if(nullptr!=drp && drp==wingmanCount)
    {
        YsString positions[MAXNUMWINGMAN];MakeDefaultWingmanPosition(positions);
        for(int i=0;i<MAXNUMWINGMAN;++i)
        {
            info.wingman[i]=(i<wingmanCount->GetSelection() ? YSTRUE : YSFALSE);
            if(info.wingman[i]==YSTRUE && info.wingmanInfo[i].typeName.Strlen()==0)
            {
                info.wingmanInfo[i]=info.playerAirInfo;
                info.wingmanInfo[i].startPos=positions[i];
            }
        }
        UpdateWingmanControls();return;
    }
    if(nullptr!=drp && (drp==groupTaskChoice || drp==groupPatternChoice))
    { CaptureGroupOptions();UpdateGroupControls();UpdateWingmanControls();return; }
	if(drp==playerStp)
	{
		drp->GetSelectedString(info.playerAirInfo.startPos);
		ReloadStartPos(world,info.fieldName,info.playerAirInfo.startPos);
        info.customStart=YSFALSE;UpdateStartControls();
	}
	else
	{
		int i;
		for(i=0; i<MAXNUMWINGMAN; i++)
		{
			if(drp==wingmanStp[i])
			{
				wingmanStp[i]->GetSelectedString(info.wingmanInfo[i].startPos);
			}
		}
	}
}

void FsGuiNewFlightDialogClass::OnNumberBoxChange(FsGuiNumberBox *nbx,int prevNum)
{
	FsNewSimulationDialogTemplate::OnNumberBoxChange(nbx,prevNum);

	if(nbx!=NULL)
	{
		if(nbx==windDir)
		{
			info.envInfo.windDir=(double)nbx->GetNumber()*YsPi/180.0;
		}
		if(nbx==windSpd)
		{
			info.envInfo.windSpd=(double)nbx->GetNumber()*1852.0/3600.0;
		}
		if(nbx==visibility)
		{
			info.envInfo.fog=YSTRUE;
			info.envInfo.fogVisibility=(double)nbx->GetNumber()*1609.0;
		}


		for(int i=0; i<MAXNUMCLOUDLAYER; i++)
		{
			if(nbx==overCastLayerFloor[i] || nbx==overCastLayerThickness[i])
			{
				RefreshCloudLayer();
			}
		}
	}
}

void FsGuiNewFlightDialogClass::OnTextBoxChange(FsGuiTextBox *txt)
{
    if(txt==customHeightBox || txt==customHeadingBox)
    {
        info.customStartHeight=YsBound(double(customHeightBox->GetInteger()),0.0,20000.0);
        info.customStartHeading=YsBound(double(customHeadingBox->GetInteger()),0.0,359.0);
        SetNeedRedraw(YSTRUE);
    }

	if(txt==fieldSearch)
	{
		ResetFieldListBySearchKeyword(world,field,fieldSearch,option.forRacingMode);
	}
	if(txt==playerStpFilter)
	{
		ResetStpListBySearchKeyword(world,playerStp,playerStpFilter);
	}
}

void FsGuiNewFlightDialogClass::OnModalDialogClosed(int /*dialogIdent*/,class FsGuiDialog *closedModalDialog,int nextActionCode)
{
	switch(nextActionCode)
	{
	case NEWFLIGHT_NEXTACTION_NULL:
		break;
	case NEWFLIGHT_NEXTACTION_SELECTPLAYERAIRPLANE:
		if(chooseAircraftDialog==closedModalDialog)
		{
			info.playerAirInfo.typeName=chooseAircraftDialog->selAir;
			info.playerAirInfo.weaponConfig=chooseAircraftDialog->selWeaponConfig;
			info.playerAirInfo.fuel=chooseAircraftDialog->selFuel;

			if(playerAir!=NULL)
			{
				YsWString label(FSGUI_AIRDLG_AIRCRAFT),name;
                name.SetUTF8String(chooseAircraftDialog->selAir);
                label.Append(L": ");
                label.Append(name);
                playerAir->SetText(label);
			}
		}
		break;
	case NEWFLIGHT_NEXTACTION_SELECTWINGMAN:
		if(chooseAircraftDialog==closedModalDialog)
		{
			const int i=chooseWingmanIdx;

			info.wingman[i]=YSTRUE;
			info.wingmanInfo[i].typeName=chooseAircraftDialog->selAir;
			info.wingmanInfo[i].weaponConfig=chooseAircraftDialog->selWeaponConfig;
			info.wingmanInfo[i].fuel=chooseAircraftDialog->selFuel;

			if(wingmanAir[i]!=NULL)
			{
				YsString buf;
				buf.Printf("Wingman %d: %s",i+1,(const char *)chooseAircraftDialog->selAir);
				wingmanAir[i]->SetText(buf);

				if(info.wingmanInfo[i].startPos.Strlen()==0)
				{
					YsString wingmanPos[MAXNUMWINGMAN];
					MakeDefaultWingmanPosition(wingmanPos);
					info.wingmanInfo[i].startPos=wingmanPos[i];
				}

				ResetStartPosChoice(wingmanStp[i],world,info.fieldName);
				wingmanStp[i]->SelectByString(info.wingmanInfo[i].startPos);
				wingmanStp[i]->Enable();
			}
		}
		break;
	}
    UpdateWingmanControls();
}

////////////////////////////////////////////////////////////



FsCreateNewSimulationInGroundObjectDialogClass::FsCreateNewSimulationInGroundObjectDialogClass()
{
	gndListBox=NULL;
}

void FsCreateNewSimulationInGroundObjectDialogClass::Make(FsWorld *world,YSBOOL forAirDefenseMissionIn)
{
	FsGuiDialog::Initialize();

	this->world=world;
	this->forAirDefenseMission=forAirDefenseMissionIn;

	mainTab=AddTabControl(0,FSKEY_NULL,YSTRUE);

	{
		const int tabId=AddTab(mainTab,FSGUI_COMMON_GENERAL);
		BeginAddTabItem(mainTab,tabId);

		AddFieldSelector(/*forRacingMode=*/YSFALSE);
		unavailableMessageStatic=AddStaticText(1,FSKEY_NULL,FSGUI_NEWFLTDLG_NOUSABLEGNDOBJ,YSTRUE);
		unavailableMessageStatic->SetText("");

		gndListBox=AddEmptyListBox(0,FSKEY_NULL,"",6,32,YSTRUE);

		EndAddTabItem();
	}

	if(YSTRUE==forAirDefenseMissionIn)
	{
		const int tabId=AddTab(mainTab,FSGUI_GNDTOAIRDLG_ENEMYTAB);
		BeginAddTabItem(mainTab,tabId);

		allowStealth=AddTextButton(5,FSKEY_NULL,FSGUI_CHECKBOX,FSGUI_NEWFLTDLG_ALLOWSTEALTH,YSTRUE);
		allowHeavyBomber=AddTextButton(7,FSKEY_NULL,FSGUI_CHECKBOX,FSGUI_NEWFLTDLG_ALLOWHEAVYBOMBER,YSTRUE);
		allowBomb=AddTextButton(6,FSKEY_NULL,FSGUI_CHECKBOX,FSGUI_NEWFLTDLG_ALLOWBOMB,YSTRUE);
		allowAGM=AddTextButton(6,FSKEY_NULL,FSGUI_CHECKBOX,FSGUI_NEWFLTDLG_ALLOWAGM,YSTRUE);


		maxNumAttacker=AddNumberBox(0,FSKEY_NULL,FSGUI_NEWFLTDLG_MAXNUMATTACKER,24,3,1,5,1,YSTRUE);

		jet=AddTextButton(0,FSKEY_NULL,FSGUI_RADIOBUTTON,FSGUI_NEWFLTDLG_JET,YSTRUE);
		ww2=AddTextButton(0,FSKEY_NULL,FSGUI_RADIOBUTTON,FSGUI_NEWFLTDLG_WW2,YSFALSE);

		FsGuiButton *jetww2[2]={jet,ww2};
		SetRadioButtonGroup(2,jetww2);


		EndAddTabItem();
	}

	mainTab->SelectFirstTab();

	okBtn=AddTextButton(1,FSKEY_NULL,FSGUI_PUSHBUTTON,FSGUI_COMMON_OK,YSTRUE);
	cancelBtn=AddTextButton(1,FSKEY_ESC,FSGUI_PUSHBUTTON,FSGUI_COMMON_CANCEL,YSFALSE);

	flyNowButton=AddTextButton(1,FSKEY_ESC,FSGUI_PUSHBUTTON,FSGUI_NEWFLTDLG_FLYNOW,YSTRUE);

	Fit();
}

void FsCreateNewSimulationInGroundObjectDialogClass::Initialize(const FsFlightConfig &cfg)
{
	if(field!=NULL)
	{
		field->SelectByString(cfg.defField);
		ReloadField(world,cfg.defField);
		ReloadUserControllableGroundObject();
	}

	okBtn->Disable();
	flyNowButton->Disable();
}

void FsCreateNewSimulationInGroundObjectDialogClass::Initialize(
    const FsFlightConfig &cfg,const FsGroundToAirDefenseMissionInfo &info)
{
	Initialize(cfg);

	allowStealth->SetCheck(info.attackerInfo.allowStealth);
	allowBomb->SetCheck(info.attackerInfo.allowBomb);
	allowAGM->SetCheck(info.attackerInfo.allowAGM);
	allowHeavyBomber->SetCheck(info.attackerInfo.allowHeavyBomber);

	maxNumAttacker->SetNumber(info.attackerInfo.maxNumAttacker);

	jet->SetCheck(info.attackerInfo.jet);
	ww2->SetCheck(info.attackerInfo.ww2);
}

void FsCreateNewSimulationInGroundObjectDialogClass::ReloadUserControllableGroundObject(void)
{
	if(NULL!=scn)
	{
		YsArray <YsSceneryGndObj *> gobList;
		scn->MakeListOfGndObj(gobList);

		gndListBox->ClearChoice();

		int nUsable=0;
		for(int i=0; i<gobList.GetN(); i++)
		{
			if(YSTRUE==forAirDefenseMission && 0==(gobList[i]->GetFlag()&FSGNDFLAG_CANBEUSEDINANTIAIRMISSION))
			{
				continue;
			}
			if(0!=(gobList[i]->GetFlag()&FSGNDFLAG_CANBEUSEROBJECT))
			{
				YsString str;
				str.Printf("%s(%d)",(const char *)gobList[i]->GetObjName(),i);

				int id=gndListBox->AddString(str,YSFALSE);
				gndListBox->SetIntAttrib(id,i);


				YsMatrix4x4 tfm;
				scn->GetTransformation(tfm,gobList[i]);

				YsVec3 pos=YsOrigin();
				tfm.Mul(pos,pos,1.0);

				printf("%s\n",pos.Txt());

				nUsable++;
			}
		}

		if(0<nUsable)
		{
			unavailableMessageStatic->SetText("");
		}
		else
		{
			unavailableMessageStatic->SetText(FSGUI_NEWFLTDLG_NOUSABLEGNDOBJ);
		}
	}
}

void FsCreateNewSimulationInGroundObjectDialogClass::Show(const FsGuiDialog *excludeFromDrawing) const
{
	YsVec3 gobPos;
	YSBOOL needToDrawGndObjCursor=NeedToDrawGndObjCursor(gobPos);

	YsAtt3 att;
	att.Set(YsPi/2.0,0.0,YsPi/2.0);
	DrawField(world,YSTRUE,YSTRUE,needToDrawGndObjCursor,gobPos);

	FsGuiDialogWithFieldAndAircraft::Show(excludeFromDrawing);
}

YSBOOL FsCreateNewSimulationInGroundObjectDialogClass::NeedToDrawGndObjCursor(YsVec3 &pos) const
{
	const int sel=gndListBox->GetSelection();
	if(NULL!=scn && 0<=sel)
	{
		const int gobId=gndListBox->GetIntAttrib(sel);

		YsArray <YsSceneryGndObj *> gobList;
		scn->MakeListOfGndObj(gobList);

		if(YSTRUE==gobList.IsInRange(gobId))
		{
			const YsSceneryGndObj *gob=gobList[gobId];

			YsMatrix4x4 tfm;
			scn->GetTransformation(tfm,gob);

			tfm.Mul(pos,YsOrigin(),1.0);

			return YSTRUE;
		}
	}
	return YSFALSE;
}

void FsCreateNewSimulationInGroundObjectDialogClass::Retrieve(class FsNewDriveDialogInfo &info)
{
	info.Initialize();
	field->GetSelectedString(info.fieldName);
	info.gobId=gndListBox->GetIntAttrib(gndListBox->GetSelection());
	info.driveNow=flyNow;
}

void FsCreateNewSimulationInGroundObjectDialogClass::Retrieve(class FsGroundToAirDefenseMissionInfo &info)
{
	info.Initialize();

	field->GetSelectedString(info.fieldName);
	info.gobId=gndListBox->GetIntAttrib(gndListBox->GetSelection());

	info.attackerInfo.allowStealth=allowStealth->GetCheck();
	info.attackerInfo.allowHeavyBomber=allowHeavyBomber->GetCheck();
	info.attackerInfo.allowBomb=allowBomb->GetCheck();
	info.attackerInfo.allowAGM=allowAGM->GetCheck();

	info.attackerInfo.maxNumAttacker=maxNumAttacker->GetNumber();

	info.attackerInfo.jet=jet->GetCheck();
	info.attackerInfo.ww2=ww2->GetCheck();
}

void FsCreateNewSimulationInGroundObjectDialogClass::FieldSelectionChanged(void)
{
	YsString fldSel;
	field->GetSelectedString(fldSel);
	ReloadField(world,fldSel);
	ReloadUserControllableGroundObject();

	okBtn->Disable();
	flyNowButton->Disable();
}

void FsCreateNewSimulationInGroundObjectDialogClass::OnButtonClick(FsGuiButton *btn)
{
	if(btn==okBtn || btn==flyNowButton)
	{
		res=YSOK;
		if(0<=field->GetSelection() &&
		   0<=gndListBox->GetSelection())
		{
			if(btn==flyNowButton)
			{
				flyNow=YSTRUE;
			}
			else
			{
				flyNow=YSFALSE;
			}
			CloseModalDialog((int)YSOK);
		}
	}
	else if(btn==cancelBtn)
	{
		res=YSERR;
		CloseModalDialog((int)YSERR);
	}
}

void FsCreateNewSimulationInGroundObjectDialogClass::OnListBoxSelChange(FsGuiListBox *lbx,int prevSel)
{
	FsNewSimulationDialogTemplate::OnListBoxSelChange(lbx,prevSel);

	if(lbx==gndListBox)
	{
		if(0<=gndListBox->GetSelection())
		{
			okBtn->Enable();
			flyNowButton->Enable();
		}
		else
		{
			okBtn->Disable();
			flyNowButton->Disable();
		}
	}
}

void FsCreateNewSimulationInGroundObjectDialogClass::OnDropListSelChange(FsGuiDropList *,int /*prevSel*/)
{
}

void FsCreateNewSimulationInGroundObjectDialogClass::OnNumberBoxChange(FsGuiNumberBox *,int /*prevNum*/)
{
}

void FsCreateNewSimulationInGroundObjectDialogClass::OnTextBoxChange(FsGuiTextBox *txt)
{
	if(txt==fieldSearch)
	{
		ResetFieldListBySearchKeyword(world,field,fieldSearch,/*forRacingMode=*/YSFALSE);
	}
}

////////////////////////////////////////////////////////////

FsGuiEnduranceModeDialog::FsGuiEnduranceModeDialog()
{
	playerAirName=NULL;
	changePlayer=NULL;
	fieldList=NULL;
	fieldSearch=NULL;
	allowAAM=NULL;
	numWingman=NULL;
	wingmanLevel=NULL;
	jet=NULL;
	ww2=NULL;
	okBtn=NULL;
	cancelBtn=NULL;

	lastCursorMoveClock=0;

	chooseAircraftDialog=new FsGuiChooseAircraft;
}

FsGuiEnduranceModeDialog::~FsGuiEnduranceModeDialog()
{
	if(NULL!=chooseAircraftDialog)
	{
		delete chooseAircraftDialog;
		chooseAircraftDialog=NULL;
	}
}

void FsGuiEnduranceModeDialog::Make(FsWorld *world,int nextActionCode)
{
	this->world=world;
	this->nextActionCode=nextActionCode;

	SetTextMessage("--- Endurance Mode ---");

	playerAirName=AddStaticText(0,FSKEY_NULL,"(AirTypeName)",32,1,YSTRUE);
	playerAirName->SetDrawFrame(YSFALSE);
	changePlayer=AddTextButton(0,FSKEY_NULL,FSGUI_PUSHBUTTON,"Change Aircraft",YSTRUE);


	int i;
	const char *fldName;
	YsArray <const char *> fldList;
	for(i=0; NULL!=(fldName=world->GetFieldTemplateName(i)); i++)
	{
		fldList.Append(fldName);
	}
	fieldList=AddListBox(0,FSKEY_NULL,"Field",fldList.GetN(),fldList,5,32,YSTRUE);
	fieldSearch=AddTextBox(0,FSKEY_NULL,FSGUI_AIRDLG_SEARCH,"",32,YSTRUE);


	numWingman=AddNumberBox(0,FSKEY_NULL,"Number of Wingmen",24,0,0,2,1,YSTRUE);

	const char *const wingmanLevelStr[]=
	{
		"VETERAN","ACE","TOP-ACE"
	};
	wingmanLevel=AddListBox(0,FSKEY_NULL,"Wingman Level",3,wingmanLevelStr,5,32,YSTRUE);

	jet=AddTextButton(0,FSKEY_NULL,FSGUI_CHECKBOX,"Jet Fighters",YSTRUE);
	ww2=AddTextButton(0,FSKEY_NULL,FSGUI_CHECKBOX,"WW2 Fighters",YSFALSE);
	allowAAM=AddTextButton(0,FSKEY_NULL,FSGUI_CHECKBOX,"Use AAM",YSFALSE);

	okBtn=AddTextButton(MkId("ok"),FSKEY_ENTER,FSGUI_PUSHBUTTON,"OK",YSTRUE);
	cancelBtn=AddTextButton(MkId("cancel"),FSKEY_ESC,FSGUI_PUSHBUTTON,"Cancel",YSFALSE);

	Fit();
}

void FsGuiEnduranceModeDialog::FieldSelectionChanged(void)
{
	lastCursorMoveClock=FsGuiClock();
}

void FsGuiEnduranceModeDialog::Initialize(FsWorld *world,FsFlightConfig &cfg)
{
	YsString str;

	str.Set("Aircraft: ");
	str.Append(cfg.defAirplane);
	playerAirName->SetText(str);

	info.playerAirInfo.typeName.Set(cfg.defAirplane);
	const FsAirplaneTemplate *tmpl;
	if((tmpl=world->GetAirplaneTemplate(cfg.defAirplane))!=NULL)
	{
		tmpl->GetProperty()->GetWeaponConfig(info.playerAirInfo.weaponConfig);
	}
	info.playerAirInfo.fuel=100;

	fieldList->SelectByString(cfg.defField);

	allowAAM->SetCheck(YSTRUE);
	numWingman->SetNumber(0);
	wingmanLevel->Select(0);
	jet->SetCheck(YSTRUE);
	ww2->SetCheck(YSFALSE);

	ReloadField(world,cfg.defField);
}

void FsGuiEnduranceModeDialog::Retrieve(void)
{
	if(fieldList->GetSelection()>=0)
	{
		fieldList->GetSelectedString(info.fieldName);
	}

	info.allowAAM=allowAAM->GetCheck();
	info.numWingman=numWingman->GetNumber();
	info.wingmanLevel=wingmanLevel->GetSelection();

	info.jet=jet->GetCheck();
	info.ww2=ww2->GetCheck();
}

void FsGuiEnduranceModeDialog::Show(const FsGuiDialog *excludeFromDrawing) const
{
	DrawSelectedFieldAndAircraft();
	FsSet2DDrawing();
	FsGuiDialogWithFieldAndAircraft::Show(excludeFromDrawing);
}

void FsGuiEnduranceModeDialog::DrawSelectedFieldAndAircraft(void) const
{
	unsigned clk;
	clk=FsGuiClock();
	if(lastCursorMoveClock!=0 && (clk<lastCursorMoveClock || (clk-lastCursorMoveClock)>500))
	{
		YsString fldName;
		if(YSOK==fieldList->GetSelectedString(fldName))
		{
			FsGuiEnduranceModeDialog *nonConstPtr=(FsGuiEnduranceModeDialog *)this;
			nonConstPtr->ReloadField(world,fldName);
		}
		lastCursorMoveClock=0;
	}

	DrawField(world,YSFALSE,YSTRUE,YSFALSE,YsOrigin());

	YsAtt3 att;
	att.Set(YsPi/2.0,0.0,YsPi/2.0);
	DrawAirplane(world,info.playerAirInfo.typeName,att,info.playerAirInfo.weaponConfig.GetN(),info.playerAirInfo.weaponConfig,YSTRUE);

}

void FsGuiEnduranceModeDialog::OnButtonClick(FsGuiButton *btn)
{
	if(btn==changePlayer)
	{
		FsGuiChooseAircraftOption opt;
		chooseAircraftDialog->Initialize();

		chooseAircraftDialog->allowAam=allowAAM->GetCheck();
		chooseAircraftDialog->allowAgm=YSFALSE;
		chooseAircraftDialog->allowBomb=YSFALSE;

		chooseAircraftDialog->Create(world,opt,ENDURANCEDLG_NEXTACTION_SELECTPLAYERAIRCRAFT);
		chooseAircraftDialog->SetDefault(info.playerAirInfo.typeName);

		AttachModalDialog(chooseAircraftDialog);
	}
	else if(btn==okBtn)
	{
		Retrieve();
		CloseModalDialog(nextActionCode);
	}
	else if(btn==cancelBtn)
	{
		CloseModalDialog(0);
	}
}

void FsGuiEnduranceModeDialog::OnListBoxSelChange(FsGuiListBox *lbx,int /*prevSel*/)
{
	if(lbx==fieldList)
	{
		lastCursorMoveClock=FsGuiClock();
	}
}

void FsGuiEnduranceModeDialog::OnTextBoxChange(FsGuiTextBox *txt)
{
	if(txt==fieldSearch)
	{
		ResetFieldListBySearchKeyword(world,fieldList,fieldSearch,/*forRacingMode=*/YSFALSE); // Call base-class service function.
	}
}

void FsGuiEnduranceModeDialog::OnModalDialogClosed(int /*dialogIdent*/,class FsGuiDialog *closedModalDialog,int nextActionCode)
{
	if(closedModalDialog==chooseAircraftDialog)
	{
		if(nextActionCode==ENDURANCEDLG_NEXTACTION_SELECTPLAYERAIRCRAFT)
		{
			info.playerAirInfo.typeName=chooseAircraftDialog->selAir;
			info.playerAirInfo.weaponConfig=chooseAircraftDialog->selWeaponConfig;
			info.playerAirInfo.fuel=chooseAircraftDialog->selFuel;

			YsString str;
			str.Set("Aircraft: ");
			str.Append(chooseAircraftDialog->selAir);
			playerAirName->SetText(str);
		}
	}
}

////////////////////////////////////////////////////////////

FsGuiInterceptMissionDialog::FsGuiInterceptMissionDialog()
{
	chooseAircraftDialog=new FsGuiChooseAircraft;
}

FsGuiInterceptMissionDialog::~FsGuiInterceptMissionDialog()
{
	if(NULL!=chooseAircraftDialog)
	{
		delete chooseAircraftDialog;
		chooseAircraftDialog=NULL;
	}
}

void FsGuiInterceptMissionDialog::Make(FsWorld *world,int nextActionCode)
{
	this->world=world;
	this->nextActionCode=nextActionCode;

	SetTextMessage("--- Intercept Mission ---");

	playerAirName=AddStaticText(0,FSKEY_NULL,"(AirTypeName)",32,1,YSTRUE);
	playerAirName->SetDrawFrame(YSFALSE);
	changePlayer=AddTextButton(0,FSKEY_NULL,FSGUI_PUSHBUTTON,"Change Aircraft",YSTRUE);

	numWingman=AddNumberBox(0,FSKEY_NULL,"Number of Wingmen",24,0,1,3,1,YSTRUE);

	int i;
	const char *fldName;
	YsArray <const char *> fldList;
	for(i=0; NULL!=(fldName=world->GetFieldTemplateName(i)); i++)
	{
		fldList.Append(fldName);
	}
	fieldList=AddListBox(0,FSKEY_NULL,"Field",fldList.GetN(),fldList,5,32,YSTRUE);
	fieldSearch=AddTextBox(0,FSKEY_NULL,FSGUI_AIRDLG_SEARCH,"",32,YSTRUE);

	allowEnemyFighter=AddTextButton(4,FSKEY_NULL,FSGUI_CHECKBOX,"Enemy Fighter Escort",YSTRUE);
	allowStealth=AddTextButton(5,FSKEY_NULL,FSGUI_CHECKBOX,"Allow Stealth",YSTRUE);
	allowBomb=AddTextButton(6,FSKEY_NULL,FSGUI_CHECKBOX,"Allow Bomb",YSTRUE);
	allowHeavyBomber=AddTextButton(7,FSKEY_NULL,FSGUI_CHECKBOX,"Allow Heavy Bomber",YSTRUE);


	maxNumAttacker=AddNumberBox(0,FSKEY_NULL,"Max Number of Attackers",24,3,1,5,1,YSTRUE);

	jet=AddTextButton(0,FSKEY_NULL,FSGUI_RADIOBUTTON,"Jet",YSTRUE);
	ww2=AddTextButton(0,FSKEY_NULL,FSGUI_RADIOBUTTON,"Ww2",YSFALSE);

	FsGuiButton *group[2];
	group[0]=jet;
	group[1]=ww2;
	SetRadioButtonGroup(2,group);

	okBtn=AddTextButton(MkId("ok"),FSKEY_ENTER,FSGUI_PUSHBUTTON,FSGUI_COMMON_OK,YSTRUE);
	cancelBtn=AddTextButton(MkId("cancel"),FSKEY_ESC,FSGUI_PUSHBUTTON,FSGUI_COMMON_CANCEL,YSFALSE);

	Fit();
}

void FsGuiInterceptMissionDialog::Show(const FsGuiDialog *excludeFromDrawing) const
{
	DrawSelectedFieldAndAircraft();
	FsSet2DDrawing();
	FsGuiDialogWithFieldAndAircraft::Show(excludeFromDrawing);
}

void FsGuiInterceptMissionDialog::Initialize(FsWorld *world,FsFlightConfig &cfg)
{
	YsString str;

	str.Set("Aircraft: ");
	str.Append(cfg.defAirplane);
	playerAirName->SetText(str);

	info.playerAirInfo.typeName.Set(cfg.defAirplane);
	const FsAirplaneTemplate *tmpl;
	if((tmpl=world->GetAirplaneTemplate(cfg.defAirplane))!=NULL)
	{
		tmpl->GetProperty()->GetWeaponConfig(info.playerAirInfo.weaponConfig);
	}
	info.playerAirInfo.fuel=100;


	fieldList->SelectByString(cfg.defField);

	numWingman->SetNumber(0);
	jet->SetCheck(YSTRUE);
	ww2->SetCheck(YSFALSE);

	ReloadField(world,cfg.defField);
}

void FsGuiInterceptMissionDialog::Retrieve(void)
{
	fieldList->GetSelectedString(info.fieldName);

	info.attackerInfo.allowAirCover=allowEnemyFighter->GetCheck();
	info.attackerInfo.allowStealth=allowStealth->GetCheck();
	info.attackerInfo.allowBomb=allowBomb->GetCheck();
	info.attackerInfo.allowHeavyBomber=allowHeavyBomber->GetCheck();
	info.numWingman=numWingman->GetNumber();
	info.attackerInfo.maxNumAttacker=maxNumAttacker->GetNumber();
	info.attackerInfo.jet=jet->GetCheck();
	info.attackerInfo.ww2=ww2->GetCheck();
}

void FsGuiInterceptMissionDialog::DrawSelectedFieldAndAircraft(void) const
{
	unsigned clk;
	clk=FsGuiClock();
	if(lastCursorMoveClock!=0 && (clk<lastCursorMoveClock || (clk-lastCursorMoveClock)>500))
	{
		YsString fldName;
		if(YSOK==fieldList->GetSelectedString(fldName))
		{
			FsGuiEnduranceModeDialog *nonConstPtr=(FsGuiEnduranceModeDialog *)this;
			nonConstPtr->ReloadField(world,fldName);
		}
		lastCursorMoveClock=0;
	}

	DrawField(world,YSFALSE,YSTRUE,YSFALSE,YsOrigin());

	YsAtt3 att;
	att.Set(YsPi/2.0,0.0,YsPi/2.0);
	DrawAirplane(world,info.playerAirInfo.typeName,att,info.playerAirInfo.weaponConfig.GetN(),info.playerAirInfo.weaponConfig,YSTRUE);
}

void FsGuiInterceptMissionDialog::FieldSelectionChanged(void)
{
	lastCursorMoveClock=FsGuiClock();
}

void FsGuiInterceptMissionDialog::OnButtonClick(FsGuiButton *btn)
{
	if(btn==changePlayer)
	{
		FsGuiChooseAircraftOption opt;
		chooseAircraftDialog->Initialize();

		chooseAircraftDialog->allowAam=YSTRUE;
		chooseAircraftDialog->allowAgm=YSFALSE;
		chooseAircraftDialog->allowBomb=YSFALSE;

		chooseAircraftDialog->Create(world,opt,INTERCEPTDLG_NEXTACTION_SELECTPLAYERAIRCRAFT);
		chooseAircraftDialog->SetDefault(info.playerAirInfo.typeName);

		AttachModalDialog(chooseAircraftDialog);
	}
	else if(btn==okBtn)
	{
		Retrieve();
		CloseModalDialog(nextActionCode);
	}
	else if(btn==cancelBtn)
	{
		CloseModalDialog(0);
	}
	else if(btn==ww2 && YSTRUE==ww2->GetCheck())
	{
		allowBomb->SetCheck(YSTRUE);
		allowHeavyBomber->SetCheck(YSTRUE);
	}

}

void FsGuiInterceptMissionDialog::OnListBoxSelChange(FsGuiListBox *lbx,int /*prevSel*/)
{
	if(lbx==fieldList)
	{
		lastCursorMoveClock=FsGuiClock();
	}
}

void FsGuiInterceptMissionDialog::OnTextBoxChange(FsGuiTextBox *txt)
{
	if(txt==fieldSearch)
	{
		ResetFieldListBySearchKeyword(world,fieldList,fieldSearch,/*forRacingMode=*/YSFALSE);
	}
}

void FsGuiInterceptMissionDialog::OnModalDialogClosed(int /*dialogIdent*/,class FsGuiDialog *closedModalDialog,int nextActionCode)
{
	if(closedModalDialog==chooseAircraftDialog)
	{
		if(INTERCEPTDLG_NEXTACTION_SELECTPLAYERAIRCRAFT==nextActionCode)
		{
			info.playerAirInfo.typeName=chooseAircraftDialog->selAir;
			info.playerAirInfo.weaponConfig=chooseAircraftDialog->selWeaponConfig;
			info.playerAirInfo.fuel=chooseAircraftDialog->selFuel;

			YsString str;
			str.Set("Aircraft: ");
			str.Append(chooseAircraftDialog->selAir);
			playerAirName->SetText(str);
		}
	}
}



FsGuiCloseAirSupportMissionDialog::FsGuiCloseAirSupportMissionDialog()
{
	lastCursorMoveClock=0;
	chooseAircraftDialog=new FsGuiChooseAircraft;
}

FsGuiCloseAirSupportMissionDialog::~FsGuiCloseAirSupportMissionDialog()
{
	if(NULL!=chooseAircraftDialog)
	{
		delete chooseAircraftDialog;
		chooseAircraftDialog=NULL;
	}
}

void FsGuiCloseAirSupportMissionDialog::Make(FsWorld *world,FsFlightConfig &cfg,int nextActionCode)
{
	this->world=world;
	this->nextActionCode=nextActionCode;

	SetTextMessage("--- Close Air Support Mission ---");

	playerAirName=AddStaticText(0,FSKEY_NULL,"(AirTypeName)",32,1,YSTRUE);
	playerAirName->SetDrawFrame(YSFALSE);

	YsString str("Aircraft: ");
	str.Append(cfg.defAirplane);
	playerAirName->SetText(str);
	playerAirNameString=cfg.defAirplane;

	changePlayer=AddTextButton(0,FSKEY_NULL,FSGUI_PUSHBUTTON,"Change Aircraft",YSTRUE);

	const char *fldName;
	YsArray <const char *> fldList;
	for(int i=0; NULL!=(fldName=world->GetFieldTemplateName(i)); i++)
	{
		fldList.Append(fldName);
	}
	fieldList=AddListBox(0,FSKEY_NULL,"Field",fldList.GetN(),fldList,5,32,YSTRUE);
	fieldSearch=AddTextBox(0,FSKEY_NULL,FSGUI_AIRDLG_SEARCH,"",32,YSTRUE);

	okBtn=AddTextButton(MkId("ok"),FSKEY_ENTER,FSGUI_PUSHBUTTON,FSGUI_COMMON_OK,YSTRUE);
	cancelBtn=AddTextButton(MkId("cancel"),FSKEY_ESC,FSGUI_PUSHBUTTON,FSGUI_COMMON_CANCEL,YSFALSE);


	const FsAirplaneTemplate *tmpl;
	if((tmpl=world->GetAirplaneTemplate(cfg.defAirplane))!=NULL)
	{
		tmpl->GetProperty()->GetWeaponConfig(playerWeaponConfig);
	}
	playerFuel=100;

	fieldList->SelectByString(cfg.defField);

	ReloadField(world,cfg.defField);

	Fit();
}


void FsGuiCloseAirSupportMissionDialog::Show(const FsGuiDialog *excludeFromDrawing) const
{
	unsigned clk;
	clk=FsGuiClock();
	if(lastCursorMoveClock!=0 && (clk<lastCursorMoveClock || (clk-lastCursorMoveClock)>500))
	{
		YsString fldName;
		if(YSOK==fieldList->GetSelectedString(fldName))
		{
			FsGuiEnduranceModeDialog *nonConstPtr=(FsGuiEnduranceModeDialog *)this;
			nonConstPtr->ReloadField(world,fldName);
		}
		lastCursorMoveClock=0;
	}

	DrawField(world,YSFALSE,YSTRUE,YSFALSE,YsOrigin());

	YsAtt3 att;
	att.Set(YsPi/2.0,0.0,YsPi/2.0);
	DrawAirplane(world,playerAirNameString,att,playerWeaponConfig.GetN(),playerWeaponConfig,YSTRUE);

	FsSet2DDrawing();
	FsGuiDialogWithFieldAndAircraft::Show(excludeFromDrawing);
}

void FsGuiCloseAirSupportMissionDialog::FieldSelectionChanged(void)
{
	lastCursorMoveClock=FsGuiClock();
}

void FsGuiCloseAirSupportMissionDialog::OnButtonClick(FsGuiButton *btn)
{
	if(btn==changePlayer)
	{
		FsGuiChooseAircraftOption opt;
		chooseAircraftDialog->Initialize();
		chooseAircraftDialog->Create(world,opt,CLOSEAIRDIALOG_NEXTACTION_SELECTPLAYERAIRCRAFT);
		chooseAircraftDialog->SetDefault(playerAirNameString);

		AttachModalDialog(chooseAircraftDialog);
	}
	else if(btn==okBtn)
	{
		// playerAirNameString is updated from OnModalDialogClosed
		fieldList->GetSelectedString(fieldString);
		CloseModalDialog(nextActionCode);
	}
	else if(btn==cancelBtn)
	{
		CloseModalDialog(0);
	}
}

void FsGuiCloseAirSupportMissionDialog::OnListBoxSelChange(FsGuiListBox *lbx,int /*prevSel*/)
{
	if(lbx==fieldList)
	{
		lastCursorMoveClock=FsGuiClock();
	}
}

void FsGuiCloseAirSupportMissionDialog::OnTextBoxChange(FsGuiTextBox *txt)
{
	if(txt==fieldSearch)
	{
		ResetFieldListBySearchKeyword(world,fieldList,fieldSearch,/*forRacingMode=*/YSFALSE);
	}
}

void FsGuiCloseAirSupportMissionDialog::OnModalDialogClosed(int /*dialogIdent*/,class FsGuiDialog *closedModalDialog,int nextActionCode)
{
	if(closedModalDialog==chooseAircraftDialog)
	{
		if(CLOSEAIRDIALOG_NEXTACTION_SELECTPLAYERAIRCRAFT==nextActionCode)
		{
			playerAirNameString=chooseAircraftDialog->selAir;
			playerWeaponConfig=chooseAircraftDialog->selWeaponConfig;
			playerFuel=chooseAircraftDialog->selFuel;

			YsString str;
			str.Set("Aircraft: ");
			str.Append(chooseAircraftDialog->selAir);
			playerAirName->SetText(str);
		}
	}
}

////////////////////////////////////////////////////////////


void FsGuiNewFlightDialogClass::OnSelectTab(FsGuiTabControl *,int)
{
    UpdateWingmanControls();UpdateGroupControls();
}

void FsGuiNewFlightDialogClass::UpdateWingmanControls(void)
{
    if(nullptr==wingmanSlot || nullptr==wingmanCount) return;
    const int selected=YsBound(wingmanSlot->GetSelection(),0,MAXNUMWINGMAN-1);
    int total=0;
    for(int i=0;i<MAXNUMWINGMAN;++i)
    {
        if(info.wingman[i]==YSTRUE) ++total;
        wingmanEnabled[i]->SetCheck(info.wingman[i]);
        YsWString title;YsString number;number.Printf("%d: ",i+1);title.SetUTF8String(number);
        YsWString name;
        if(info.wingmanInfo[i].typeName.Strlen()>0) name.SetUTF8String(info.wingmanInfo[i].typeName);
        else name=FsGetTextResource("v4/playerair",L"Player aircraft (default)");
        title.Append(name);wingmanAir[i]->SetText(title);
        wingmanStp[i]->SetEnabled(info.wingman[i]==YSTRUE && !(info.groupFormation==YSTRUE || info.groupAirStart==YSTRUE || info.groupMission==YSTRUE) ? YSTRUE : YSFALSE);
        if(world!=nullptr && 0==wingmanStp[i]->GetNumChoice()) ResetStartPosChoice(wingmanStp[i],world,info.fieldName);
        if(info.wingmanInfo[i].startPos.Strlen()>0) wingmanStp[i]->SelectByString(info.wingmanInfo[i].startPos);
        const bool show=(mainTab->GetCurrentTab()==wingmanTabId && i==selected);
        for(FsGuiDialogItem *item : {static_cast<FsGuiDialogItem *>(wingmanEnabled[i]),static_cast<FsGuiDialogItem *>(wingmanAir[i]),
            static_cast<FsGuiDialogItem *>(wingmanStpLabel[i]),static_cast<FsGuiDialogItem *>(wingmanStp[i]),
            static_cast<FsGuiDialogItem *>(changeWingman[i]),static_cast<FsGuiDialogItem *>(removeWingman[i])})
        { if(show) item->Show();else item->Hide(); }
    }
    wingmanCount->Select(total);SetNeedRedraw(YSTRUE);
}

void FsGuiNewFlightDialogClass::CaptureGroupOptions(void)
{
    if(nullptr==groupFormationCheck) return;
    info.groupFormation=groupFormationCheck->GetCheck();
    info.groupAirStart=groupStartCheck->GetCheck();
    info.groupMission=groupMissionCheck->GetCheck();
    info.groupPattern=YsBound(groupPatternChoice->GetSelection(),0,6);
    info.groupTask=YsBound(groupTaskChoice->GetSelection(),0,3);
    info.groupSpacing=YsBound(double(groupSpacingBox->GetInteger()),50.0,5000.0);
    info.groupHeight=YsBound(double(groupHeightBox->GetInteger()),50.0,20000.0);
    info.groupHeading=YsBound(double(groupHeadingBox->GetInteger()),0.0,359.0);
    info.groupSpeed=YsBound(double(groupSpeedBox->GetInteger()),0.0,3000.0)/3.6;
    info.groupPatrolRadius=YsBound(double(groupRadiusBox->GetInteger()),1.0,50.0)*1000.0;
}

void FsGuiNewFlightDialogClass::UpdateGroupControls(void)
{
    if(nullptr==groupFormationCheck) return;
    for(auto check : {groupFormationCheck,groupStartCheck,groupMissionCheck}) check->SetEnabled(customStartAllowed ? YSTRUE : YSFALSE);
    groupPatternChoice->SetEnabled(groupFormationCheck->GetCheck());groupSpacingBox->SetEnabled(groupFormationCheck->GetCheck());
    for(auto item : {groupHeightBox,groupHeadingBox,groupSpeedBox}) item->SetEnabled(groupStartCheck->GetCheck());
    groupTaskChoice->SetEnabled(groupMissionCheck->GetCheck());
    groupRadiusBox->SetEnabled(groupMissionCheck->GetCheck()==YSTRUE && groupTaskChoice->GetSelection()==1 ? YSTRUE : YSFALSE);
}
