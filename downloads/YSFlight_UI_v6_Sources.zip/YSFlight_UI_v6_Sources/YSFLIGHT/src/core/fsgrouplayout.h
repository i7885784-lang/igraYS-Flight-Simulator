#ifndef FSGROUPLAYOUT_IS_INCLUDED
#define FSGROUPLAYOUT_IS_INCLUDED
struct FsGroupOffset { double x,z; };
inline FsGroupOffset FsGetGroupOffset(int pattern,int index,double spacing)
{
    static const int diamond[8][2]={{-1,-1},{1,-1},{0,-2},{-2,-2},{2,-2},{-1,-3},{1,-3},{0,-4}};
    static const int delta[8][2]={{-1,-1},{1,-1},{-2,-2},{0,-2},{2,-2},{-3,-3},{-1,-3},{1,-3}};
    const int rank=index/2+1;
    FsGroupOffset p;
    switch(pattern)
    {
    case 0:p={double(diamond[index%8][0]),double(diamond[index%8][1])};break;
    case 1:p={double(delta[index%8][0]),double(delta[index%8][1])};break;
    case 2:p={double(index%2==0 ? -rank : rank),double(-rank)};break;
    case 3:p={0.0,double(-index-1)};break;
    case 4:p={double(index%2==0 ? -rank : rank),0.0};break;
    case 5:p={double(-index-1),double(-index-1)};break;
    default:p={double(index+1),double(-index-1)};break;
    }
    p.x*=spacing;p.z*=spacing;return p;
}
#endif
