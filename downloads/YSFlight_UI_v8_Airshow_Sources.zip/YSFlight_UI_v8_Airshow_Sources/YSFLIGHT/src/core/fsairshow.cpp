#define FSSIMPLEWINDOW_DONT_INCLUDE_OPENGL_HEADERS
#include <fssimplewindow.h>
#include "fs.h"
#include "fsairshow.h"
#include "fsafterburnervisual.h"
#include "fstextresource.h"
#include "graphics/common/fsopengl.h"
namespace{const wchar_t *T(const char *k,const wchar_t *s){return FsGetTextResource(k,s);}YsColor C(int r,int g,int b){YsColor c;c.SetIntRGB(r,g,b);return c;}}
std::shared_ptr<FsSimExtension_Airshow> FsGetAirshow(const FsSimulation *sim)
{return sim ? std::dynamic_pointer_cast<FsSimExtension_Airshow>(sim->FindExtension(FsSimExtension_Airshow::Ident())) : nullptr;}
std::function<std::shared_ptr<FsSimExtensionBase>(void)> FsSimExtension_Airshow::Generator()
{return [](){return std::make_shared<FsSimExtension_Airshow>();};}
FsAirplane *FsSimExtension_Airshow::Aircraft(const FsSimulation *sim,int i) const
{
 auto player=sim->GetPlayerAirplane();if(i==0)return player;
 for(auto a=sim->FindNextAirplane(nullptr);a;a=sim->FindNextAirplane(a))if(a!=player && a->squadSlot==i-1 && a->squadLeaderKey==FsExistence::GetSearchKey(player))return a;
 return nullptr;
}
YsArray<YsString> FsSimExtension_Airshow::Serialize(const FsSimulation *)
{
 YsArray<YsString> rows;YsString s;s.Printf("EXTENSIO %s CONFIG %d %d %d %d %.3f %.3f",Ident(),config.supply,config.synchronized,config.autoAfterburner,config.burst,config.interval,config.cameraSensitivity);rows.Append(s);
 for(int i=0;i<9;++i){s.Printf("EXTENSIO %s COLOR %d %d %d %d",Ident(),i,config.rgb[i][0],config.rgb[i][1],config.rgb[i][2]);rows.Append(s);}
 return rows;
}
YSRESULT FsSimExtension_Airshow::ProcessCommand(FsSimulation *,const YsConstArrayMask<YsString> &a)
{
 if(a.GetN()>=9 && 0==a[2].Strcmp("CONFIG")){config.supply=atoi(a[3])!=0;config.synchronized=atoi(a[4])!=0;config.autoAfterburner=atoi(a[5])!=0;config.burst=YsBound(atoi(a[6]),1,64);config.interval=YsBound(atof(a[7]),0.1,2.0);config.cameraSensitivity=YsBound(atof(a[8]),0.05,2.0);return YSOK;}
 if(a.GetN()>=7 && 0==a[2].Strcmp("COLOR")){int i=atoi(a[3]);if(i>=0 && i<9)for(int c=0;c<3;++c)config.rgb[i][c]=YsBound(atoi(a[4+c]),0,255);return YSOK;}return YSERR;
}
void FsSimExtension_Airshow::StartSimulation(FsSimulation *sim)
{
 replaying=false;sim->GetPlayerSquad();SetupAircraft(sim,true);
 sim->AddTimedMessage(T("show/keys",L"F10: airshow | F2: orbit camera | right drag: rotate | wheel: zoom"));
}
void FsSimExtension_Airshow::StartReplay(FsSimulation *sim){replaying=true;sim->GetPlayerSquad();SetupAircraft(sim,false);}
void FsSimExtension_Airshow::SetupAircraft(FsSimulation *sim,bool resupply)
{
 for(int i=0;i<9;++i)if(auto a=Aircraft(sim,i))
 {
  if(config.supply && resupply){a->SendCommand("MAXNMFLR 500");a->Prop().SetNumWeapon(FSWEAPON_FLARE_INTERNAL,500);a->SendCommand("LOADWEPN IFLR 500");YsString oil;oil.Printf("SMOKEOIL %.3fkg",YsGreater(100.0,a->Prop().GetSmokeOil()));a->SendCommand(oil);}
  if(a->Prop().GetNumSmokeGenerator()==0){YsString s;s.Printf("SMOKEGEN 0m 0m %.3fm",-a->GetApproximatedCollideRadius()*0.5);a->SendCommand(s);}
  YsString s;s.Printf("SMOKECOL ALL %d %d %d",config.rgb[i][0],config.rgb[i][1],config.rgb[i][2]);a->SendCommand(s);
 }

}
void FsSimExtension_Airshow::ApplyControls(FsSimulation *sim)
{
 if(replaying)return;
 for(int i=0;i<9;++i)if(auto a=Aircraft(sim,i))if(a->IsAlive()==YSTRUE)
 {
  if(smoke[i]){a->Prop().SetSmokeSelector(255);a->Prop().SetSmokeButton(YSTRUE);}
  // Auto reheat uses the native engine, fuel consumption and plume visibility.
  if(i==0 && FsAfterburnerVisual::RealEngineAllowsFlame(a->Prop().GetIdentifier()) && config.autoAfterburner && a->GetAutopilot()==nullptr && a->Prop().IsJet()==YSTRUE && a->Prop().GetHasAfterburner()==YSTRUE && a->Prop().GetAircraftClass()!=FSCL_HELICOPTER)
   a->Prop().SetAfterburner(a->Prop().GetThrottle()>0.98 ? YSTRUE : YSFALSE);
 }
}
void FsSimExtension_Airshow::OnInterval(FsSimulation *sim,double dt)
{
 if(replaying || dt<=0)return;
 if(sim->GetClock()>=nextFlare)
 {
  for(int i=0;i<9;++i)if(remaining[i]>0)
  {
   if(auto a=Aircraft(sim,i))if(a->IsAlive()==YSTRUE){YSBOOL blocked=YSFALSE;a->Prop().FireWeapon(blocked,sim,sim->GetClock(),sim->GetWeaponStore(),a,FSWEAPON_FLARE);}
   --remaining[i];
  }
  nextFlare=sim->GetClock()+config.interval;
 }
}
void FsSimExtension_Airshow::Command(FsSimulation *sim,int action)
{
 if(replaying)return;
 if(action==0){for(int i=0;i<9;++i)if(config.synchronized || i==selected){if(auto a=Aircraft(sim,i)){if(a->Prop().GetNumWeapon(FSWEAPON_FLARE)>0)remaining[i]=config.burst;else sim->AddTimedMessage(T("show/noFlares",L"No flares: enable show equipment before departure."));}}nextFlare=sim->GetClock();}
 if(action==1){bool on=!smoke[selected];for(int i=0;i<9;++i)if(config.synchronized || i==selected){smoke[i]=on;if(auto a=Aircraft(sim,i)){if(on && a->Prop().GetSmokeOil()<=0.0){smoke[i]=false;sim->AddTimedMessage(T("show/noOil",L"No smoke oil: enable show equipment before departure."));}a->Prop().SetSmokeButton(smoke[i] ? YSTRUE : YSFALSE);}}}
 if(action==2){for(int n=0;n<9;++n){selected=(selected+1)%9;if(Aircraft(sim,selected))break;}}
 if(action==3)config.synchronized=!config.synchronized;
 if(action==4){for(int n=0;n<9;++n){cameraUnit=(cameraUnit+1)%9;if(Aircraft(sim,cameraUnit))break;}}
 if(action==5){const int values[]={4,8,16,32,64};int n=0;while(n<5 && values[n]<=config.burst)++n;config.burst=values[n%5]; }
 if(action==6)for(auto &n:remaining)n=0;
}
void FsSimExtension_Airshow::DrawMenu(const FsSimulation *sim) const
{
 int w,h;FsGetWindowSize(w,h);FsDrawRect(0,0,w,h,C(13,23,35),YSTRUE);FsDrawString(35,35,T("show/title",L"AIRSHOW - FLIGHT PAUSED"),YsWhite());
 const wchar_t *names[]={T("show/flare",L"Release flare burst"),T("show/smoke",L"Toggle smoke"),T("show/unit",L"Select aircraft"),T("show/sync",L"All / selected"),T("show/camera",L"Camera target"),T("show/burst",L"Burst length"),T("show/stop",L"Stop flare burst"),T("show/close",L"Close (F10 / Esc)")};
 for(int i=0;i<8;++i){FsDrawRect(35,85+i*49,510,126+i*49,C(36,72,92),YSTRUE);YsString n;n.Printf("%d: ",i+1);YsWString line;line.SetUTF8String(n);line.Append(names[i]);FsDrawString(48,96+i*49,line,YsWhite());}
 YsString state;state.Printf("#%d | %d | #%d",selected,config.burst,cameraUnit);YsWString line(T(config.synchronized ? "show/allState" : "show/oneState",L"Aircraft / burst / camera: "));YsWString tail;tail.SetUTF8String(state);line.Append(tail);FsDrawString(550,95,line,YsYellow());
 int y=145;for(int i=0;i<9;++i)if(auto a=Aircraft(sim,i)){YsString s;s.Printf("#%d  %s   RGB %d/%d/%d   FLR %d",i,a->Prop().GetIdentifier(),config.rgb[i][0],config.rgb[i][1],config.rgb[i][2],a->Prop().GetNumWeapon(FSWEAPON_FLARE));FsDrawRect(530,y,542,y+15,C(config.rgb[i][0],config.rgb[i][1],config.rgb[i][2]),YSTRUE);FsDrawString(550,y,s,YsWhite());y+=32;}
 FsDrawString(35,h-70,T("show/cameraHelp",L"F2: orbit camera; right drag: rotate 360 degrees; wheel: zoom. F1: cockpit."),YsWhite());
 int l,m,rr,x,y2;FsGetMouseState(l,m,rr,x,y2);FsDrawCircle(x,y2,5,YsWhite(),YSFALSE);
}
void FsSimExtension_Airshow::Click(FsSimulation *sim,int x,int y)
{if(x>=35 && x<=510 && y>=85 && y<85+8*49){int i=(y-85)/49;if(i==7)menuOpen=false;else Command(sim,i);}}
void FsSimExtension_Airshow::CameraInput(int key,bool right,int x,int y)
{
 if(key==FSKEY_WHEELUP)distance=YsBound(distance/1.12,10.0,10000.0);
 if(key==FSKEY_WHEELDOWN)distance=YsBound(distance*1.12,10.0,10000.0);
 if(right && !dragging){restoreX=x;restoreY=y;}
 if(!right && dragging){FsSetMousePosition(restoreX,restoreY);x=restoreX;y=restoreY;}
 if(right && dragging){heading+=(x-lastX)*YsDegToRad(config.cameraSensitivity);pitch=YsBound(pitch+(y-lastY)*YsDegToRad(config.cameraSensitivity),-YsPi*0.48,YsPi*0.48);}
 dragging=right;lastX=x;lastY=y;
}
void FsSimExtension_Airshow::Report(const FsSimulation *sim) const
{
 printf("V8SHOW selected=%d sync=%d burst=%d camera=%d heading=%.3f pitch=%.3f distance=%.3f\n",selected,config.synchronized,config.burst,cameraUnit,heading,pitch,distance);
 for(int i=0;i<9;++i)if(auto a=Aircraft(sim,i))printf("V8SHOWUNIT slot=%d flare=%d smoke=%d ab=%d throttle=%.3f\n",i,a->Prop().GetNumWeapon(FSWEAPON_FLARE),int(a->Prop().IsTrailingSmoke(0)),int(a->Prop().GetAfterBurner()),a->Prop().GetThrottle());
}
