#include <ysclass.h>
#define FSSIMPLEWINDOW_DONT_INCLUDE_OPENGL_HEADERS
#include <fssimplewindow.h>
#include "fs.h"
#include "fsoperation.h"
#include "fsformationautopilot.h"
#include "fsgroundattackautopilot.h"
#include "fsdogfightautopilot.h"
#include "fstextresource.h"
#include "graphics/common/fsopengl.h"
#include "graphics/common/fsfontrenderer.h"
namespace
{
const wchar_t *T(const char *k,const wchar_t *s){return FsGetTextResource(k,s);}
YsColor C(int r,int g,int b){YsColor c;c.SetIntRGB(r,g,b);return c;}
YsWString W(const YsString &s){YsWString w;w.SetUTF8String(s);return w;}
// Native hover physics and saved HOVER___ intention; the extension restores aiming.
class OperationHover : public FsHoveringAutopilot
{
public:
    bool aim=false;double maximumSpeed=22.0;YsVec3 aimPosition;
    virtual YSRESULT ApplyControl(FsAirplane &air,FsSimulation *sim,const double &dt)
    {
        const auto result=FsHoveringAutopilot::ApplyControl(air,sim,dt);
        // Native hover uses an unbounded attitude gain. Heavy helicopters can
        // roll through 180 degrees on a lateral transfer. Keep native thrust
        // control but use bounded, gentle attitude commands for operation AI.
        YsVec3 velocity;air.Prop().GetVelocity(velocity);
        YsVec3 error=desigPos-air.GetPosition();error.SetY(0.0);
        YsVec3 desired=error*0.12;
        if(desired.GetLength()>maximumSpeed){desired.Normalize();desired*=maximumSpeed;}
        YsAtt3 heading=air.GetAttitude();heading.SetP(0.0);heading.SetB(0.0);
        YsVec3 difference;heading.MulInverse(difference,desired-velocity);
        YsVec3 thrust;air.Prop().GetThrustDirection(thrust);
        const double zeroP=asin(YsBound(thrust.z(),-1.0,1.0)),zeroB=-asin(YsBound(thrust.x(),-1.0,1.0));
        const double wantedP=zeroP-YsBound(difference.z()*YsDegToRad(0.6),-YsDegToRad(8.0),YsDegToRad(8.0));
        const double wantedB=zeroB-YsBound(difference.x()*YsDegToRad(0.6),-YsDegToRad(10.0),YsDegToRad(10.0));
        const double bankError=atan2(sin(wantedB-air.GetAttitude().b()),cos(wantedB-air.GetAttitude().b()));
        air.Prop().SetDirectRollControl(YsBound(YsRadToDeg(bankError)*0.018,-0.3,0.3));
        air.Prop().SetDirectPitchControl(YsBound(YsRadToDeg(wantedP-air.GetAttitude().p())*0.025,-0.3,0.3));
        if(aim)
        {
            YsAtt3 heading=air.GetAttitude();heading.SetP(0.0);heading.SetB(0.0);
            YsVec3 relative;heading.MulInverse(relative,aimPosition-air.GetPosition());
            air.Prop().SetDirectYawControl(YsBound(atan2(-relative.x(),relative.z())*1.5,-0.5,0.5));
        }
        return result;
    }
};
OperationHover *Hover(FsAirplane &air,const YsVec3 &position)
{
    auto ap=new OperationHover;ap->state=1;ap->desigPos=position;air.SetAutopilot(ap);return ap;
}
struct MapView
{
    int left,top,width,height;double scale;YsVec3 center;
    MapView(const FsSimExtension_Operation &op)
    {
        int w,h;FsGetWindowSize(w,h);left=360;top=65;width=YsGreater(100,w-left-35);height=YsGreater(100,h-top-65);
        center=(op.landing+op.rally)*0.5;scale=YsSmaller(width,height)*op.mapZoom/10000.0;
    }
    int X(const YsVec3 &p)const{return left+width/2+int((p.x()-center.x())*scale);}
    int Y(const YsVec3 &p)const{return top+height/2-int((p.z()-center.z())*scale);}
    bool Contains(int x,int y)const{return x>=left && x<left+width && y>=top && y<top+height;}
    YsVec3 Pick(int x,int y)const{return center+YsVec3((x-left-width/2)/scale,0.0,-(y-top-height/2)/scale);}
};
const wchar_t *TaskName(int t)
{
    const char *keys[]={"v8/follow","v8/wait","v8/route","v8/airattack","v8/groundattack","v8/land","v8/retreat","v8/followgroup","v8/base","v8/manoeuvre"};
    const wchar_t *names[]={L"Following",L"Waiting",L"Route",L"Air attack",L"Ground attack",L"Landing",L"Retreating",L"Follow group",L"Return to base",L"Manoeuvre"};
    return T(keys[YsBound(t,0,9)],names[YsBound(t,0,9)]);
}
}
void FsCreateSafeFollower(FsAirplane &wing,FsAirplane &leader)
{
    if(wing.Prop().GetAircraftClass()!=FSCL_HELICOPTER && leader.Prop().GetVelocity()<wing.Prop().GetEstimatedLandingSpeed()*1.4)
    {
        // An aeroplane cannot hover in a helicopter formation. Orbit nearby.
        auto ap=FsGotoPosition::Create();const double radius=1400.0+120.0*YsGreater(0,wing.squadSlot);
        for(int i=0;i<4;++i){double angle=2.0*YsPi*i/4.0;auto p=leader.GetPosition()+YsVec3(sin(angle)*radius,200.0,cos(angle)*radius);ap->destination.Append(p);}
        ap->SetSpeed(wing.Prop().GetEstimatedLandingSpeed()*1.6);ap->SetUseAfterburner(YSFALSE);wing.SetAutopilot(ap);wing.squadTask=2;return;
    }
    auto ap=FsFormation::Create();ap->leader=&leader;ap->shouldBe=(wing.squadOffset.GetSquareLength()>1.0 ? wing.squadOffset : YsVec3(100,0,-150));
    ap->headingOnly=YSTRUE;ap->synchronizeTrigger=YSFALSE;ap->minAlt=0.0;
    if(wing.Prop().IsOnGround()!=YSTRUE)ap->mode=FSFOMMODE_LOSTPOSITION;
    wing.SetAutopilot(ap);wing.squadTask=0;
}
FsSimExtension_Operation::FsSimExtension_Operation()
{
    for(int i=0;i<4;++i)groupName[i].Printf("Group %d",i+1);
}
std::function<std::shared_ptr<FsSimExtensionBase>(void)> FsSimExtension_Operation::Generator()
{return [](){return std::make_shared<FsSimExtension_Operation>();};}
std::shared_ptr<FsSimExtension_Operation> FsGetOperation(const FsSimulation *sim)
{return nullptr!=sim ? std::dynamic_pointer_cast<FsSimExtension_Operation>(sim->FindExtension(FsSimExtension_Operation::Ident())) : nullptr;}
FsAirplane *FsSimExtension_Operation::Aircraft(const FsSimulation *sim,int slot) const
{
    auto player=sim->GetPlayerAirplane();if(slot<0)return player;
    for(auto air=sim->FindNextAirplane(nullptr);air!=nullptr;air=sim->FindNextAirplane(air))
        if(air!=player && air->squadSlot==slot && air->squadLeaderKey==FsExistence::GetSearchKey(player))return air;
    return nullptr;
}
FsOperationUnit *FsSimExtension_Operation::Unit(int slot)
{for(auto &u:units)if(u.slot==slot)return &u;return nullptr;}
bool FsSimExtension_Operation::InScope(int slot) const
{
    for(const auto &u:units)if(u.slot==slot)return scopeSlot!=-2 ? slot==scopeSlot : (scopeGroup==0 || u.group==scopeGroup);
    return false;
}
int FsSimExtension_Operation::LiveDefenders(const FsSimulation *sim) const
{
    int n=0;for(const auto &tag:defenders){auto g=sim->FindGroundByTag(tag);if(g!=nullptr && g->IsAlive()==YSTRUE)++n;}return n;
}
YsArray<YsString> FsSimExtension_Operation::Serialize(const FsSimulation *)
{
    YsArray<YsString> result;YsString s;
    s.Printf("EXTENSIO %s SETUP %d %.6f %.6f %.6f %.6f %.6f %.6f",Ident(),transportSlot,landing.x(),landing.y(),landing.z(),rally.x(),rally.y(),rally.z());result.Append(s);
    for(const auto &tag:defenders){s.Printf("EXTENSIO %s DEFENDER %s",Ident(),tag.Txt());result.Append(s);}
    for(int i=0;i<4;++i){s.Printf("EXTENSIO %s GROUP %d \"%s\"",Ident(),i+1,groupName[i].Txt());result.Append(s);}
    for(const auto &u:units)
    {
        s.Printf("EXTENSIO %s UNIT %d %d %d %.3f %.3f %.6f %.6f %.6f %d %d %s",Ident(),u.slot,u.group,u.task,u.height,u.speed,u.destination.x(),u.destination.y(),u.destination.z(),u.followGroup,u.landRequested ? 1:0,u.targetName.Strlen()>0 ? u.targetName.Txt() : "-");result.Append(s);
        for(const auto &p:u.route){s.Printf("EXTENSIO %s POINT %d %.6f %.6f %.6f",Ident(),u.slot,p.x(),p.y(),p.z());result.Append(s);}
    }
    s.Printf("EXTENSIO %s STATE %d %.6f",Ident(),status,landingSeconds);result.Append(s);return result;
}
YSRESULT FsSimExtension_Operation::ProcessCommand(FsSimulation *,const YsConstArrayMask<YsString> &a)
{
    if(a.GetN()<3)return YSERR;
    if(0==a[2].Strcmp("SETUP") && a.GetN()>=10){transportSlot=atoi(a[3]);landing.Set(atof(a[4]),atof(a[5]),atof(a[6]));rally.Set(atof(a[7]),atof(a[8]),atof(a[9]));return YSOK;}
    if(0==a[2].Strcmp("DEFENDER") && a.GetN()>=4){defenders.Append(a[3]);return YSOK;}
    if(0==a[2].Strcmp("GROUP") && a.GetN()>=5){int i=atoi(a[3])-1;if(i>=0 && i<4)groupName[i]=a[4];return YSOK;}
    if(0==a[2].Strcmp("UNIT") && a.GetN()>=14)
    {
        FsOperationUnit u;u.slot=atoi(a[3]);u.group=YsBound(atoi(a[4]),1,4);u.task=YsBound(atoi(a[5]),0,9);u.height=YsBound(atof(a[6]),20.0,10000.0);u.speed=atof(a[7]);u.destination.Set(atof(a[8]),atof(a[9]),atof(a[10]));u.followGroup=atoi(a[11]);u.landRequested=atoi(a[12])!=0;u.targetName=a[13];if(0==u.targetName.Strcmp("-"))u.targetName="";units.Append(u);return YSOK;
    }
    if(0==a[2].Strcmp("POINT") && a.GetN()>=7){if(auto u=Unit(atoi(a[3])))u->route.Append(YsVec3(atof(a[4]),atof(a[5]),atof(a[6])));return YSOK;}
    if(0==a[2].Strcmp("STATE") && a.GetN()>=5){status=YsBound(atoi(a[3]),0,2);landingSeconds=atof(a[4]);return YSOK;}
    return YSERR;
}
void FsSimExtension_Operation::StartSimulation(FsSimulation *sim)
{
    replaying=false;resultTime=-1.0;sim->GetPlayerSquad();
    for(auto &u:units){u.pending=true;u.waypoint=0;u.nextFire=0.0;}
    sim->AddTimedMessage(T("v8/brief",L"Clear the landing zone, then order the transport to land. F11: tactical map. Enter: commands."));
}
YSBOOL FsSimExtension_Operation::MustTerminate(const FsSimulation *sim) const
{return status!=0 && resultTime>=0.0 && sim->GetClock()-resultTime>8.0 ? YSTRUE : YSFALSE;}
void FsSimExtension_Operation::ApplyUnit(FsSimulation *sim,FsOperationUnit &u)
{
    auto a=Aircraft(sim,u.slot);auto leader=sim->GetPlayerAirplane();if(a==nullptr || a->IsAlive()!=YSTRUE || leader==nullptr)return;
    if(u.task==0 || u.task==7)
    {
        FsAirplane *follow=leader;
        if(u.task==7)for(const auto &candidate:units)if(candidate.group==u.followGroup && candidate.slot!=u.slot){auto other=Aircraft(sim,candidate.slot);if(other!=nullptr && other->IsAlive()==YSTRUE){follow=other;break;}}
        if(a!=follow)
        {
            if(a->Prop().GetAircraftClass()==FSCL_HELICOPTER){Hover(*a,a->GetPosition());a->squadTask=0;}
            else FsCreateSafeFollower(*a,*follow);
        }
        return;
    }
    if(u.task==3){auto ap=FsDogfight::Create();ap->SetTargetFlyingAircraftOnly(YSTRUE);a->SetAutopilot(ap);a->squadTask=3;return;}
    if(u.task==4 && a->Prop().GetAircraftClass()!=FSCL_HELICOPTER)
    {
        auto g=u.targetName.Strlen()>0 ? sim->FindGroundByTag(u.targetName) : nullptr;
        if(g==nullptr)for(const auto &tag:defenders){auto candidate=sim->FindGroundByTag(tag);if(candidate!=nullptr && candidate->IsAlive()==YSTRUE){g=candidate;u.targetName=tag;break;}}
        auto ap=FsGroundAttack::Create();ap->target=g;ap->SetAttackerAltitude(sim->GetFieldElevation(a->GetPosition().x(),a->GetPosition().z())+u.height);ap->SetAGMReleaseDistance(a->Prop().GetAGMRange()*0.8);a->SetAutopilot(ap);a->squadTask=3;return;
    }
    YsVec3 p=u.destination;
    if(u.task==1)p=a->GetPosition();
    if(u.task==2 && u.route.GetN()>0)p=u.route[YsBound(u.waypoint,0,int(u.route.GetN())-1)];
    if(u.task==8)p=rally;
    if(u.task==5)p=landing;
    p.SetY(sim->GetFieldElevation(p.x(),p.z())+u.height);
    if(a->Prop().GetAircraftClass()==FSCL_HELICOPTER)Hover(*a,p);
    else
    {
        auto ap=FsGotoPosition::Create();ap->destination.Append(p);
        // Fixed-wing waiting/retreat uses an orbit instead of stopping in the air.
        if(u.task!=2){ap->destination.Append(p+YsVec3(1000,0,1000));ap->destination.Append(p+YsVec3(1000,0,-1000));}
        ap->SetSpeed(YsGreater(u.speed,a->Prop().GetEstimatedLandingSpeed()*1.5));ap->SetUseAfterburner(YSFALSE);a->SetAutopilot(ap);
    }
    a->squadTask=(u.task==6 || u.task==8 ? 2 : 3);
}
void FsSimExtension_Operation::Order(FsSimulation *sim,int task,int followGroup)
{
    if(status!=0 || replaying)return;
    int changed=0;
    for(auto &u:units)
    {
        if(task==5 ? u.slot!=transportSlot : !InScope(u.slot))continue;
        auto a=Aircraft(sim,u.slot);if(a==nullptr || a->IsAlive()!=YSTRUE)continue;
        if((task==0 || task==7) && a==sim->GetPlayerAirplane())continue;
        if(task==7)
        {
            const int requestedGroup=(followGroup>=1 && followGroup<=4 ? followGroup : u.followGroup);
            bool visited[5]={false,false,false,false,false};
            std::function<bool(int)> reachesOwnGroup=[&](int g)
            {
                if(g==u.group)return true;
                if(g<1 || g>4 || visited[g])return false;
                visited[g]=true;
                for(const auto &other:units)if(other.group==g && other.task==7 && reachesOwnGroup(other.followGroup))return true;
                return false;
            };
            bool available=false;for(const auto &other:units)if(other.group==requestedGroup && other.slot!=u.slot){auto target=Aircraft(sim,other.slot);if(target!=nullptr && target->IsAlive()==YSTRUE)available=true;}
            if(!available || reachesOwnGroup(requestedGroup)){sim->AddTimedMessage(T("v8/followCycle",L"Choose another living group without circular follow orders."));continue;}
            u.followGroup=requestedGroup;
        }
        if(task==2 && u.route.GetN()==0){sim->AddTimedMessage(T("v8/noRoute",L"No route: add points on the tactical map first."));continue;}
        if(task==4)
        {
            auto g=selectedGround.Strlen()>0 ? sim->FindGroundByTag(selectedGround) : nullptr;
            if(g==nullptr)for(const auto &tag:defenders){auto candidate=sim->FindGroundByTag(tag);if(candidate!=nullptr && candidate->IsAlive()==YSTRUE){g=candidate;break;}}
            if(g==nullptr || g->IsAlive()!=YSTRUE || g->iff==a->iff){sim->AddTimedMessage(T("v8/noGroundTarget",L"Select a hostile ground target on the map."));continue;}
            if(a->Prop().GetNumWeapon(FSWEAPON_AGM65)+a->Prop().GetNumWeapon(FSWEAPON_ROCKET)+a->Prop().GetNumWeapon(FSWEAPON_BOMB)+a->Prop().GetNumWeapon(FSWEAPON_GUN)<=0){sim->AddTimedMessage(T("v8/noGroundWeapons",L"Unit has no suitable ground-attack weapon."));continue;}
            if(a->Prop().GetAircraftClass()==FSCL_HELICOPTER && a->Prop().GetNumWeapon(FSWEAPON_AGM65)<=0)
            {sim->AddTimedMessage(T("v8/heliAGM",L"Helicopter automatic attack requires guided air-to-ground missiles."));continue;}
            u.targetName=g->name;
        }
        if(task==5 && a->Prop().GetAircraftClass()!=FSCL_HELICOPTER){sim->AddTimedMessage(T("v8/needHeli",L"Landing task requires a helicopter."));continue;}
        // Every new order replaces the previous task and any old attack trigger.
        a->Prop().SetAllVirtualButton(YSFALSE);u.task=task;u.waypoint=0;u.pending=true;u.landRequested=(task==5);
        if(task==6 && hasPoint)u.destination=selectedPoint;else if(task==6 || task==8)u.destination=rally;
        ++changed;
    }
    sim->AddTimedMessage(changed>0 ? T("v8/orderReceived",L"Order received.") : T("v8/noUnits",L"No available units for this order."));
}
void FsSimExtension_Operation::OnInterval(FsSimulation *sim,double dt)
{
    if(replaying || dt<=0.0)return;
    auto transport=Aircraft(sim,transportSlot);auto player=sim->GetPlayerAirplane();
    if(status==0 && (transport==nullptr || transport->IsAlive()!=YSTRUE || player==nullptr || player->IsAlive()!=YSTRUE))
    {status=2;resultTime=sim->GetClock();sim->AddTimedMessage(T("v8/failed",L"MISSION FAILED: transport or commander lost."));}
    if(status!=0){if(resultTime<0.0)resultTime=sim->GetClock();return;}
    const int guards=LiveDefenders(sim);
    for(auto &u:units)
    {
        auto a=Aircraft(sim,u.slot);if(a==nullptr || a->IsAlive()!=YSTRUE)continue;
        if(guards==0 && u.task==4){u.task=(u.slot<0 ? 1 : 0);u.pending=true;}
        if(u.pending){ApplyUnit(sim,u);u.pending=false;}
        auto hover=dynamic_cast<OperationHover *>(a->GetAutopilot());
        if(hover!=nullptr)hover->maximumSpeed=YsBound(u.speed,1.0,22.0);
        if((u.task==0 || u.task==7) && hover!=nullptr && a!=player)
        {
            auto follow=player;
            if(u.task==7)for(const auto &candidate:units)if(candidate.group==u.followGroup && candidate.slot!=u.slot){auto other=Aircraft(sim,candidate.slot);if(other!=nullptr && other->IsAlive()==YSTRUE){follow=other;break;}}
            YsAtt3 heading=follow->GetAttitude();heading.SetP(0.0);heading.SetB(0.0);
            auto offset=a->squadOffset;if(offset.GetSquareLength()<1.0)offset.Set(100,0,-150);
            YsVec3 rotated;heading.Mul(rotated,offset);hover->desigPos=follow->GetPosition()+rotated;
            hover->desigPos.SetY(YsGreater(hover->desigPos.y(),sim->GetFieldElevation(hover->desigPos.x(),hover->desigPos.z())+60.0));
        }

        if(u.task==4 && a->Prop().GetAircraftClass()==FSCL_HELICOPTER)
        {
            auto target=u.targetName.Strlen()>0 ? sim->FindGroundByTag(u.targetName) : nullptr;
            if(target==nullptr || target->IsAlive()!=YSTRUE)
            {
                target=nullptr;for(const auto &tag:defenders){auto g=sim->FindGroundByTag(tag);if(g!=nullptr && g->IsAlive()==YSTRUE){target=g;u.targetName=tag;break;}}
                if(target==nullptr){u.task=0;u.pending=true;sim->AddTimedMessage(T("v8/attackDone",L"Ground targets destroyed. Returning to formation."));continue;}
            }
            YsVec3 away=a->GetPosition()-target->GetPosition();away.SetY(0);if(away.Normalize()!=YSOK)away.Set(0,0,-1);
            YsVec3 station=target->GetPosition()+away*1400.0;station.SetY(sim->GetFieldElevation(station.x(),station.z())+u.height);
            if(hover==nullptr)hover=Hover(*a,station);
            hover->desigPos=station;hover->aim=true;hover->aimPosition=target->GetPosition();
            YsVec3 relative;a->GetAttitude().MulInverse(relative,target->GetPosition()-a->GetPosition());
            if(a->Prop().GetNumWeapon(FSWEAPON_AGM65)>0 && relative.z()>0.0 && atan2(relative.GetLengthXY(),relative.z())<YsDegToRad(18.0) && relative.GetLength()<a->Prop().GetAGMRange() && sim->GetClock()>=u.nextFire)
            {
                a->Prop().SetGroundTargetKey(FsExistence::GetSearchKey(target));YSBOOL blocked=YSFALSE;
                a->Prop().FireWeapon(blocked,sim,sim->GetClock(),sim->GetWeaponStore(),a,FSWEAPON_AGM65);u.nextFire=sim->GetClock()+8.0;
            }
        }
        if(u.task==2 && u.route.GetN()>0 && (a->GetPosition()-u.route[u.waypoint]).GetLengthXZ()<130.0)
        {
            if(u.waypoint+1<u.route.GetN()){++u.waypoint;u.pending=true;}
            else {u.task=1;u.destination=a->GetPosition();u.pending=true;sim->AddTimedMessage(T("v8/routeDone",L"Route complete. Holding position."));}
        }
        if(u.task==5 && hover!=nullptr)
        {
            const double previousAltitude=hover->desigPos.y();
            a->Prop().SetGear(1.0);hover->desigPos=landing;
            const double distance=(a->GetPosition()-landing).GetLengthXZ();
            // The transport waits outside the zone until the actual defenders are destroyed.
            if(guards>0){hover->desigPos=rally;hover->desigPos.SetY(sim->GetFieldElevation(rally.x(),rally.z())+u.height);}
            else if(distance>100.0)hover->desigPos.SetY(landing.y()+YsGreater(60.0,u.height));
            else hover->desigPos.SetY(YsGreater(landing.y()+a->Prop().GetGroundStandingHeight()*0.8,previousAltitude-1.8*dt));
        }
    }
    const double distance=(transport->GetPosition()-landing).GetLengthXZ();
    const bool down=transport->Prop().IsOnGround()==YSTRUE && transport->Prop().GetVelocity()<1.5 && distance<130.0 && guards==0;
    landingSeconds=(down ? landingSeconds+dt : 0.0);
    if(landingSeconds>=8.0){status=1;resultTime=sim->GetClock();sim->AddTimedMessage(T("v8/won",L"MISSION COMPLETE: landing zone secured, troops delivered."));}
}
YsWString FsSimExtension_Operation::ScopeName() const
{
    if(scopeSlot<0 && scopeSlot!=-2)return YsWString(T("v8/player",L"Player"));
    if(scopeSlot>=0){YsString s;s.Printf(" %d",scopeSlot+1);YsWString name(T("v8/wingman",L"Wingman"));name.Append(W(s));return name;}
    if(scopeGroup>0)return W(groupName[scopeGroup-1]);
    return YsWString(T("v8/allUnits",L"All units"));
}
void FsSimExtension_Operation::Draw(const FsSimulation *sim) const
{
    int w,h;FsGetWindowSize(w,h);
    if(mapOpen || replaying)return;
    FsDrawRect(12,38,650,125,C(8,17,28),YSTRUE);
    FsDrawString(24,45,T("v8/missionTitle",L"OPERATION: GUARDED LANDING ZONE"),YsWhite());
    YsString info;auto tr=Aircraft(sim,transportSlot);const double km=(tr!=nullptr ? (tr->GetPosition()-landing).GetLengthXZ()/1000.0 : 0.0);
    info.Printf(" %d  |  %.1f km  |  %.0f/8 s",LiveDefenders(sim),km,landingSeconds);
    YsWString progress(T("v8/defendersLeft",L"Defenders:"));progress.Append(W(info));
    FsDrawString(24,72,progress,C(110,230,220));
    FsDrawString(24,99,T(status==1 ? "v8/won" : status==2 ? "v8/failed" : "v8/missionKeys",L"Enter: commands | F11: tactical map"),status==2 ? YsRed() : YsWhite());
}
void FsSimExtension_Operation::DrawMap(const FsSimulation *sim) const
{
    int w,h;FsGetWindowSize(w,h);MapView v(*this);
    FsDrawRect(0,0,w,h,C(12,22,33),YSTRUE);FsDrawString(24,20,T("v8/mapTitle",L"TACTICAL MAP - FLIGHT PAUSED"),YsWhite());
    FsDrawRect(v.left,v.top,v.left+v.width,v.top+v.height,C(29,49,57),YSTRUE);
    for(int x=v.left;x<v.left+v.width;x+=80)FsDrawLine(x,v.top,x,v.top+v.height,C(45,69,76));
    for(int y=v.top;y<v.top+v.height;y+=80)FsDrawLine(v.left,y,v.left+v.width,y,C(45,69,76));
    FsDrawCircle(v.X(landing),v.Y(landing),YsGreater(6,int(130*v.scale)),C(80,240,130),YSFALSE);
    FsDrawString(v.X(landing)+12,v.Y(landing),T("v8/lz",L"Landing zone"),C(80,240,130));
    FsDrawCircle(v.X(rally),v.Y(rally),8,C(90,180,255),YSFALSE);FsDrawString(v.X(rally)+12,v.Y(rally),T("v8/rally",L"Rally / retreat"),YsWhite());
    for(const auto &tag:defenders){auto g=sim->FindGroundByTag(tag);if(g!=nullptr && g->IsAlive()==YSTRUE){const auto p=g->GetPosition();FsDrawRect(v.X(p)-7,v.Y(p)-7,v.X(p)+7,v.Y(p)+7,YsRed(),YSTRUE);FsDrawString(v.X(p)+10,v.Y(p),W(tag),YsRed());}}
    int y=465;
    for(const auto &u:units)
    {
        auto a=Aircraft(sim,u.slot);if(a==nullptr)continue;const auto p=a->GetPosition();
        const auto color=(a->IsAlive()!=YSTRUE ? C(100,100,100) : InScope(u.slot) ? YsYellow() : C(90,195,255));
        FsDrawCircle(v.X(p),v.Y(p),6,color,YSTRUE);
        YsString id;id.Printf("%s %d / G%d",u.slot<0 ? "P" : "W",u.slot+1,u.group);FsDrawString(v.X(p)+8,v.Y(p),W(id),color);
        YsWString row=W(id);row.Append(L": ");row.Append(a->IsAlive()==YSTRUE ? TaskName(u.task) : T("v8/lost",L"Lost"));FsDrawString(24,y,row,color);y+=24;
        if(InScope(u.slot)){auto previous=p;int n=1;for(const auto &pt:u.route){FsDrawLine(v.X(previous),v.Y(previous),v.X(pt),v.Y(pt),color);FsDrawCircle(v.X(pt),v.Y(pt),4,color,YSFALSE);previous=pt;++n;}}
    }
    if(hasPoint){FsDrawLine(v.X(selectedPoint)-10,v.Y(selectedPoint),v.X(selectedPoint)+10,v.Y(selectedPoint),YsWhite());FsDrawLine(v.X(selectedPoint),v.Y(selectedPoint)-10,v.X(selectedPoint),v.Y(selectedPoint)+10,YsWhite());}
    YsWString who(T("v8/selected",L"Selected: "));who.Append(ScopeName());FsDrawString(24,55,who,YsYellow());
    const wchar_t *buttons[]={T("v8/addPoint",L"Add route point"),T("v8/clearRoute",L"Clear route"),T("v8/runRoute",L"Follow route"),T("v8/groundattack",L"Attack ground target"),T("v8/retreat",L"Retreat"),T("v7/regroup",L"Regroup"),T("v8/landTransport",L"Land transport"),T("v8/closeMap",L"Close (F11 / Esc)")};
    for(int i=0;i<8;++i){FsDrawRect(20,92+i*41,335,127+i*41,C(39,73,88),YSTRUE);FsDrawString(30,100+i*41,buttons[i],YsWhite());}
    FsDrawString(v.left,h-42,T("v8/mapHelp",L"Click: select point / target | Wheel: zoom | Enter wheel: choose recipients"),YsWhite());
    int lb,mb,rb,mx,my;FsGetMouseState(lb,mb,rb,mx,my);FsDrawCircle(mx,my,5,YsWhite(),YSFALSE);
}
void FsSimExtension_Operation::MapClick(FsSimulation *sim,int x,int y)
{
    MapView v(*this);
    if(v.Contains(x,y))
    {
        selectedPoint=v.Pick(x,y);selectedPoint.SetY(sim->GetFieldElevation(selectedPoint.x(),selectedPoint.z()));hasPoint=true;selectedGround="";
        for(const auto &tag:defenders){auto g=sim->FindGroundByTag(tag);if(g!=nullptr && g->IsAlive()==YSTRUE && abs(v.X(g->GetPosition())-x)<18 && abs(v.Y(g->GetPosition())-y)<18){selectedGround=tag;selectedPoint=g->GetPosition();}}
        return;
    }
    if(x<20 || x>335 || y<92 || y>=92+8*41)return;
    const int button=(y-92)/41;
    if(button==0 && !hasPoint)sim->AddTimedMessage(T("v8/selectPoint",L"Select a point on the map first."));
    if(button==0 && hasPoint)for(auto &u:units)if(InScope(u.slot) && u.route.GetN()<16){auto p=selectedPoint;p.SetY(sim->GetFieldElevation(p.x(),p.z())+u.height);u.route.Append(p);}
    if(button==1)for(auto &u:units)if(InScope(u.slot)){u.route.Clear();if(u.task==2){u.task=1;u.pending=true;}}
    if(button==2)Order(sim,2);if(button==3)Order(sim,4);if(button==4)Order(sim,6);if(button==5)Order(sim,0);if(button==6)Order(sim,5);if(button==7)mapOpen=false;
}
YsArray<YsWString> FsSimExtension_Operation::WheelLabels() const
{
    YsArray<YsWString> labels;
    if(wheelPage==2)
    {labels.Append(T("v8/allUnits",L"All units"));for(const auto &name:groupName)labels.Append(W(name));labels.Append(T("v8/individual",L"Individual"));labels.Append(T("v7/back",L"Back"));}
    else if(wheelPage==3)
    {labels.Append(T("v8/player",L"Player"));for(int i=0;i<8;++i){YsString s;s.Printf(" %d",i+1);YsWString name(T("v8/wingman",L"Wingman"));name.Append(W(s));labels.Append(name);}}
    else if(wheelPage==4)
    {for(const auto &name:groupName)labels.Append(W(name));labels.Append(T("v7/back",L"Back"));}
    else
    {
        const char *keys[]={"v8/recipients","v8/runRoute","v8/groundattack","v8/retreat","v8/landTransport","v8/map","v8/wait","v8/followgroup","v7/back"};
        const wchar_t *names[]={L"Recipients",L"Follow route",L"Ground attack",L"Retreat",L"Land transport",L"Tactical map",L"Wait / stop attack",L"Follow group",L"Back"};
        for(int i=0;i<9;++i)labels.Append(T(keys[i],names[i]));
    }
    return labels;
}
bool FsSimExtension_Operation::WheelChoose(FsSimulation *sim,int item)
{
    if(wheelPage==2)
    {if(item==5){wheelPage=3;return false;}if(item>=0 && item<5){scopeGroup=item;scopeSlot=-2;}wheelPage=1;return false;}
    if(wheelPage==3){if(item>=0 && item<=8){scopeSlot=item-1;scopeGroup=0;}wheelPage=1;return false;}
    if(wheelPage==4){if(item>=0 && item<4){Order(sim,7,item+1);return true;}wheelPage=1;return false;}
    if(item==0){wheelPage=2;return false;}
    if(item==1){Order(sim,2);return true;}if(item==2){Order(sim,4);return true;}if(item==3){Order(sim,6);return true;}
    if(item==4){Order(sim,5);return true;}if(item==5){mapOpen=true;return false;}if(item==6){Order(sim,1);return true;}
    if(item==7){wheelPage=4;return false;}wheelPage=0;return false;
}
void FsSimExtension_Operation::Report(const FsSimulation *sim) const
{
    printf("V8OP status=%d guards=%d transport=%d landed=%.3f group=%d slot=%d\n",status,LiveDefenders(sim),transportSlot,landingSeconds,scopeGroup,scopeSlot);
    for(const auto &u:units){auto a=Aircraft(sim,u.slot);if(a!=nullptr)printf("V8UNIT slot=%d group=%d task=%d alive=%d route=%d agm=%d x=%.3f y=%.3f z=%.3f\n",u.slot,u.group,u.task,int(a->IsAlive()),int(u.route.GetN()),a->Prop().GetNumWeapon(FSWEAPON_AGM65),a->GetPosition().x(),a->GetPosition().y(),a->GetPosition().z());}
    fflush(stdout);
}
