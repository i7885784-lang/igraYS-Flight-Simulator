#include "fs.h"
#include "fsguinewflightdialog.h"
#include "fstextresource.h"
namespace{const wchar_t *T(const char *k,const wchar_t *s){return FsGetTextResource(k,s);}}
void FsGuiNewFlightDialogClass::MakeShowTab()
{
 int tab=AddTab(mainTab,T("show/tab",L"Airshow"));BeginAddTabItem(mainTab,tab);
 const wchar_t *units[]={T("v8/player",L"Player"),L"1",L"2",L"3",L"4",L"5",L"6",L"7",L"8"};
 AddStaticText(0,FSKEY_NULL,T("show/unitColor",L"Smoke colour for aircraft"),YSTRUE);
 showUnit=AddDropList(MkId("showUnit"),FSKEY_NULL,L"",9,units,9,10,10,YSFALSE);
 const wchar_t *palette[]={T("show/white",L"White"),T("show/red",L"Red"),T("show/blue",L"Blue"),T("show/green",L"Green"),T("show/yellow",L"Yellow"),T("show/pink",L"Pink"),T("show/cyan",L"Cyan"),T("show/orange",L"Orange")};
 showPalette=AddDropList(MkId("showPalette"),FSKEY_NULL,T("show/palette",L"Palette"),8,palette,8,15,15,YSTRUE);
 for(int i=0;i<3;++i){const char *labels[]={"R","G","B"};YsString id;id.Printf("showRGB%d",i);showRGB[i]=AddTextBox(MkId(id),FSKEY_NULL,FsGuiTextBox::HORIZONTAL,labels[i],"255",4,i==0 ? YSTRUE : YSFALSE);showRGB[i]->SetTextType(FSGUI_INTEGER);}
 showSupply=AddTextButton(MkId("showSupply"),FSKEY_NULL,FSGUI_CHECKBOX,T("show/supply",L"Show equipment: 500 flares and smoke oil"),YSTRUE);showSupply->SetCheck(YSTRUE);
 showSync=AddTextButton(MkId("showSync"),FSKEY_NULL,FSGUI_CHECKBOX,T("show/all",L"Synchronize smoke and flare bursts for all aircraft"),YSTRUE);showSync->SetCheck(YSTRUE);
 showAutoAB=AddTextButton(MkId("showAutoAB"),FSKEY_NULL,FSGUI_CHECKBOX,T("show/autoAB",L"Automatic reheat at full throttle (equipped jets only)"),YSTRUE);showAutoAB->SetCheck(YSTRUE);
 showBurst=AddTextBox(MkId("showBurst"),FSKEY_NULL,FsGuiTextBox::HORIZONTAL,T("show/burstCount",L"Flares in burst (1-64)"),"16",4,YSTRUE);
 showInterval=AddTextBox(MkId("showInterval"),FSKEY_NULL,FsGuiTextBox::HORIZONTAL,T("show/interval",L"Burst interval, ms"),"200",5,YSTRUE);
 showSensitivity=AddTextBox(MkId("showSensitivity"),FSKEY_NULL,FsGuiTextBox::HORIZONTAL,T("show/sensitivity",L"Camera sensitivity, percent"),"100",4,YSTRUE);
 AddStaticText(0,FSKEY_NULL,T("show/hint",L"F10: smoke / flares / camera target. F2: right drag to orbit, wheel to zoom.\nRGB is saved separately for every aircraft. Smoke starts switched off."),YSTRUE);
 EndAddTabItem();showEdit=0;UpdateShow();
}
void FsGuiNewFlightDialogClass::CaptureShow()
{
 if(showUnit==nullptr)return;
 for(int c=0;c<3;++c)info.show.rgb[showEdit][c]=YsBound(showRGB[c]->GetInteger(),0,255);
 info.show.supply=showSupply->GetCheck()==YSTRUE;info.show.synchronized=showSync->GetCheck()==YSTRUE;info.show.autoAfterburner=showAutoAB->GetCheck()==YSTRUE;
 info.show.burst=YsBound(showBurst->GetInteger(),1,64);info.show.interval=YsBound(showInterval->GetInteger()/1000.0,0.1,2.0);info.show.cameraSensitivity=YsBound(showSensitivity->GetInteger()*0.0035,0.05,2.0);
}
void FsGuiNewFlightDialogClass::UpdateShow(){for(int c=0;c<3;++c)showRGB[c]->SetInteger(info.show.rgb[showEdit][c]);SetNeedRedraw(YSTRUE);}
