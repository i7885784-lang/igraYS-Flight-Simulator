#include "fs.h"
#include "fsformationautopilot.h"
YSRESULT FsFormation::SafeFormationControl(FsAirplane &air,FsSimulation *sim,double dt)
{
 auto &p=air.Prop();YsVec3 velocity,leadVelocity;p.GetVelocity(velocity);leader->Prop().GetVelocity(leadVelocity);
 const double margin=YsGreater(12.0,air.GetApproximatedCollideRadius()*0.8);
 safeTerrain=sim->GetFieldElevation(air.GetPosition().x(),air.GetPosition().z());
 // Look along velocity and the intended path, not only straight down.
 for(int i=1;i<=8;++i){auto sample=air.GetPosition()+velocity*(i*0.5);safeTerrain=YsGreater(safeTerrain,sim->GetFieldElevation(sample.x(),sample.z()));}
 bool collisionRisk=false;double avoidanceSign=1.0,closestRiskTime=4.0;
 const double groundAtSlot=sim->GetFieldElevation(goal.x(),goal.z());goal.SetY(YsGreater(goal.y(),groundAtSlot+margin));
 // Predict closest approach to nearby live aircraft. Different slots get a stable
 // side/height priority so reciprocal avoidance does not oscillate.
 for(auto other=sim->FindNextAirplane(nullptr);other;other=sim->FindNextAirplane(other))if(other!=&air && other->IsAlive()==YSTRUE)
 {
  const auto relative=other->GetPosition()-air.GetPosition();if(relative.GetSquareLength()>250000.0)continue;
  YsVec3 ov;other->Prop().GetVelocity(ov);const auto rv=ov-velocity;
  const double t=YsBound(-(relative*rv)/YsGreater(1.0,rv.GetSquareLength()),0.0,3.0);
  const auto closest=relative+rv*t;const double separation=YsGreater(35.0,(air.GetApproximatedCollideRadius()+other->GetApproximatedCollideRadius())*2.0);
  if(closest.GetLength()<separation)
  {
   collisionRisk=true;
   const double pairSign=(FsExistence::GetSearchKey(&air)<FsExistence::GetSearchKey(other) ? -1.0:1.0);
   if(t<closestRiskTime){closestRiskTime=t;avoidanceSign=pairSign;}
   YsVec3 away=-closest;away.SetY(0);if(away.Normalize()!=YSOK)away.Set(pairSign,0,0);
   goal+=away*(separation-closest.GetLength()+20.0);goal.AddY(12.0*(YsGreater(0,air.squadSlot)+1));
  }
 }
 const double downNow=YsGreater(0.0,-velocity.y());
 const bool lowSlot=(goal.y()-groundAtSlot<200.0);
 if(air.GetPosition().y()-safeTerrain>200.0+downNow*3.0 && collisionRisk && !recovering)
 {
  p.NeutralDirectAttitudeControl();p.BankController(YsBound(air.GetAttitude().b(),-YsDegToRad(35.0),YsDegToRad(35.0)));
  ControlGForAltitude(air,sim,air.GetPosition().y()+avoidanceSign*45.0,0.0,3.0);
  p.SpeedController(YsGreater(p.GetEstimatedLandingSpeed()*1.35,leader->Prop().GetVelocity()));safeGoalValid=false;return YSOK;
 }
 if(air.GetPosition().y()-safeTerrain>200.0+downNow*3.0 && !collisionRisk && !recovering && !lowSlot){safeGoalValid=false;return YSERR;}
 if(!safeGoalValid){safeGoal=goal;safeGoalValid=true;}
 else {auto move=goal-safeGoal;const double maxMove=YsGreater(60.0,leadVelocity.GetLength()*1.8)*dt;if(move.GetLength()>maxMove){move.Normalize();move*=maxMove;}safeGoal+=move;}
 const double down=YsGreater(0.0,-velocity.y());const double gLimit=YsBound(GetDefaultGLimit(air),2.0,7.0);
 const double rollTime=YsAbs(air.GetAttitude().b())/YsDegToRad(70.0);
 const double reserve=margin+down*(1.5+rollTime)+down*down/(2.0*YsGreater(3.0,(gLimit-1.0)*FsGravityConst*0.50));
 const double clearance=air.GetPosition().y()-safeTerrain;
 if(clearance<reserve && (down>1.0 || clearance<margin))recovering=true;
 if(recovering && velocity.y()>1.0 && clearance>margin+8.0)recovering=false;
 p.NeutralDirectAttitudeControl();
 const double minSpeed=YsGreater(25.0,p.GetEstimatedLandingSpeed()*1.35);
 if(recovering)
 {
  p.BankController(0.0,YsDegToRad(100.0));p.SetSpoiler(0.0);p.SetBrake(0.0);
  const double bank=air.GetAttitude().b();
  p.GController(cos(bank)>0.3 ? YsBound(1.4+down*0.14,1.5,gLimit) : cos(bank)<-0.3 ? -0.5 : 0.0);
  p.SpeedController(YsGreater(minSpeed,leader->Prop().GetVelocity()));mode=FSFOMMODE_RECOVER_FROM_LOWALT;
 }
 else
 {
  FollowTarget(air,sim,safeGoal,leader->GetAttitude(),leadVelocity,leader->Prop().GetG(),dt,gLimit,-1.0,YSFALSE);
  YsAtt3 heading=leader->GetAttitude();heading.SetP(0);heading.SetB(0);YsVec3 relative;heading.MulInverse(relative,safeGoal-air.GetPosition());
  double requested=leader->Prop().GetVelocity()+YsBound(relative.z()/8.0,-30.0,45.0);
  p.SpeedController(YsGreater(minSpeed,requested));
  if(clearance<150.0 || lowSlot)
  {
   YsVec3 local;air.GetAttitude().MulInverse(local,safeGoal+leadVelocity*1.0-air.GetPosition());
   double bearing=atan2(-local.x(),local.z());const double bankLimit=YsDegToRad(YsBound(20.0+clearance*0.25,20.0,55.0));
   p.BankController(YsBound(bearing*2.5,-bankLimit,bankLimit),YsDegToRad(60.0));
   const double floor=safeTerrain+margin;const double target=YsGreater(safeGoal.y(),floor);
   ControlGForAltitude(air,sim,target,YsBound(leadVelocity.y(),-8.0,12.0),gLimit);
  }
 }
 p.SetGear(leader->Prop().GetLandingGear());p.SetFlap(leader->Prop().GetFlap());p.SetRudder(0.0);p.SmartRudder(dt);
 return YSOK;
}
