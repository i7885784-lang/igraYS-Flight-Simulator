﻿Тестовая сборка №4. Распакуйте всю папку в новое место; старую игру не заменяйте.
Запуск: Play_Su27.bat или ysflight32_gl1.exe.
G — шасси; стрелки — тангаж/крен; Z/C — руль направления; Q/A — газ; Tab — форсаж; F/R — закрылки; B — воздушный тормоз.
Проверки игры: Win64/Wine. Настоящая Windows 10 x86 здесь не запускалась.
Исходники именно этого движка и адаптации: https://raw.githubusercontent.com/i7885784-lang/igraYS-Flight-Simulator/ysflight-center-download/downloads/YSFlight_Playtest_4_Sources.zip
Су-34 в этой публичной сборке отсутствует.
