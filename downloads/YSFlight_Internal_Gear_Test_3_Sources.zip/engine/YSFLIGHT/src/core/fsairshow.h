#ifndef FSAIRSHOW_IS_INCLUDED
#define FSAIRSHOW_IS_INCLUDED
#include "fssimextension.h"
#include "fsairshowconfig.h"
class FsAirplane;
class FsSimExtension_Airshow : public FsSimExtensionBase
{
public:
    struct Su27Event {double time=0,sl=0,sr=0,canopy=0,target=0;int id=0;unsigned int key=YSNULLHASHKEY;bool battery=false,pumps=false,left=false,right=false,parking=false;};
    YsArray<Su27Event> su27Events;
    void RecordSu27(const FsSimulation *,const FsAirplane &);
    void ReplaySu27(FsSimulation *);
    FsAirshowConfig config;
    bool menuOpen=false,replaying=false,smoke[FsMaxShowAircraft]={false},orbit=true,dragging=false;
    int selected=0,cameraUnit=0,remaining[FsMaxShowAircraft]={0},lastX=0,lastY=0,restoreX=0,restoreY=0;
    double nextFlare=0,heading=0,pitch=0.22,distance=100;
    double validationFitMinimum=0.0; // Set only by laboratory camera commands.
    struct BreakOrder { unsigned int key=YSNULLHASHKEY; double start=0,finish=0; bool started=false; double departureHeading=0.0; };
    YsArray<BreakOrder> breaks;
    void ReleaseFlares(FsSimulation *,bool all);
    void StartBreak(FsSimulation *,const YsArray<FsAirplane *,8> &);
    void ReturnBreak(FsSimulation *,const YsArray<FsAirplane *,8> &);
    void CancelBreak(unsigned int key);
    void MoveUnit(int from,int to);
    void SetColour(FsSimulation *,int,int,int,int);
    static const char *Ident(){return "AIRSHOW_V8";}
    virtual const char *GetIdent() const override{return Ident();}
    static std::function<std::shared_ptr<FsSimExtensionBase>(void)> Generator();
    virtual YsArray<YsString> Serialize(const FsSimulation *) override;
    virtual YSRESULT ProcessCommand(FsSimulation *,const YsConstArrayMask<YsString> &) override;
    virtual void StartSimulation(FsSimulation *) override;
    virtual void StartReplay(FsSimulation *) override;
    void SetupAircraft(FsSimulation *,bool);
    virtual void OnInterval(FsSimulation *,double) override;
    FsAirplane *Aircraft(const FsSimulation *,int index) const;
    void ApplyControls(FsSimulation *);
    void Command(FsSimulation *,int action);
    void DrawMenu(const FsSimulation *) const;
    void Click(FsSimulation *,int,int);
    void CameraInput(int key,bool right,int x,int y);
    void Report(const FsSimulation *) const;
};
std::shared_ptr<FsSimExtension_Airshow> FsGetAirshow(const FsSimulation *);
#endif
