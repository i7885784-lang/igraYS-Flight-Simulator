#define FSSIMPLEWINDOW_DONT_INCLUDE_OPENGL_HEADERS
#include <fssimplewindow.h>
#include <fsgui.h>
#include "fs.h"
#include "fsguimaincanvas.h"
#include "fsautopilot.h"
#include "fsairshow.h"
#include "fsgrouplayout.h"
namespace {
class StraightSetup : public FsGuiDialog {
public:
 FsGuiDropList *aircraft,*pattern;
 FsGuiNumberBox *count,*height,*gap,*spacing;
 FsGuiButton *fly,*cancel;
 YsArray<YsString> names;
 void Make(FsWorld *world){
 SetIdent("straightDlg");SetTextMessage(L"Тест: свободный полёт рядом с группой");
 for(int i=0;auto name=world->GetAirplaneTemplateName(i);++i)
  if(auto t=world->GetAirplaneTemplate(name))if(t->GetProperty()->GetAircraftClass()!=FSCL_HELICOPTER)names.Append(YsString(name));
 AddStaticText(0,FSKEY_NULL,L"Самолёт (одинаковый у всех)",YSTRUE);
 YsArray<const char *> choices;for(const auto &n:names)choices.Append(n.Txt());
 aircraft=AddDropList(MkId("aircraft"),FSKEY_NULL,"",choices.GetN(),choices,12,32,32,YSTRUE);
 for(int i=0;i<names.GetN();++i)if(0==names[i].Strcmp("MIG-29_FULCRUM"))aircraft->Select(i);
 count=AddNumberBox(MkId("count"),FSKEY_NULL,L"Ведомых",12,4,0,4,1,YSTRUE);
 height=AddNumberBox(MkId("height"),FSKEY_NULL,L"Твоя высота, м",16,1000,100,10000,100,YSTRUE);
 gap=AddNumberBox(MkId("gap"),FSKEY_NULL,L"Ведомые выше тебя, м",22,50,0,500,10,YSTRUE);
 spacing=AddNumberBox(MkId("spacing"),FSKEY_NULL,L"Интервал, м",16,50,30,500,10,YSTRUE);
 const wchar_t *p[]={L"Обратный клин",L"Клин",L"Колонна",L"Ромб",L"Фронт пар"};
 pattern=AddDropList(MkId("pattern"),FSKEY_NULL,L"Начальный строй",5,p,5,24,24,YSTRUE);pattern->Select(0);
 AddStaticText(0,FSKEY_NULL,L"Группа держит прямой курс и свою скорость.\nНа тебя и команды не реагирует. Можно пристроиться рядом.\nКарта: ровная зелёная земля без зданий.",YSTRUE);
 fly=AddTextButton(MkId("fly"),FSKEY_ENTER,FSGUI_PUSHBUTTON,L"Полететь",YSTRUE);
 cancel=AddTextButton(MkId("cancel"),FSKEY_ESC,FSGUI_PUSHBUTTON,L"Отмена",YSFALSE);Fit();
 }
 YSRESULT VirtualSelect(const YsString &id,int n)override{
 if(0==id.Strcmp("count")){count->SetNumber(YsBound(n,0,4));return YSOK;}
 if(0==id.Strcmp("height")){height->SetNumber(YsBound(n,100,10000));return YSOK;}
 if(0==id.Strcmp("gap")){gap->SetNumber(YsBound(n,0,500));return YSOK;}
 if(0==id.Strcmp("spacing")){spacing->SetNumber(YsBound(n,30,500));return YSOK;}
 return FsGuiDialog::VirtualSelect(id,n);
 }
 void OnButtonClick(FsGuiButton *b)override{if(b==fly)CloseModalDialog(YSOK);else if(b==cancel)CloseModalDialog(YSERR);}
};
}
void FsGuiMainCanvas::OpenMissions(FsGuiPopUpMenuItem *){
 if(!runLoop->SavePendingFlightHistory())return;
 auto d=FsGuiDialog::CreateSelfDestructiveDialog<StraightSetup>();d->Make(runLoop->GetWorld());d->BindCloseModalCallBack(&THISCLASS::MissionSetupSelected,this);AttachModalDialog(d);
}
void FsGuiMainCanvas::MissionChosen(FsGuiDialog *,int){}
void FsGuiMainCanvas::MissionSetupSelected(FsGuiDialog *closed,int code){
 auto d=dynamic_cast<StraightSetup *>(closed);if(!d || code!=YSOK)return;
 auto world=runLoop->GetWorld();int sel=d->aircraft->GetSelection();if(sel<0 || sel>=d->names.GetN())return;
 FsFlightConfig cfg;cfg.Load(FsGetConfigFile());FsNewFlightDialogInfo info;info.SetFromConfig(world,cfg);
 info.fieldName="STRAIGHT_TEST";info.playerAirInfo.typeName=d->names[sel];info.playerAirInfo.fuel=100;
 world->GetAirplaneTemplate(d->names[sel])->GetProperty()->GetWeaponConfig(info.playerAirInfo.weaponConfig);
 for(auto &w:info.wingman)w=YSFALSE;
 info.addComputerAircraft=YSFALSE;info.customStart=YSTRUE;info.customStartPosition=YsOrigin();info.customStartHeight=d->height->GetNumber();info.customStartHeading=0;
 info.groupAirStart=YSFALSE;info.groupFormation=YSFALSE;info.groupMission=YSFALSE;info.flyImmediately=YSFALSE;
 Sim_CreateFlight_Create(info);auto sim=world->GetSimulation();if(!sim)return;auto player=sim->GetPlayerAirplane();if(!player)return;
 const int ids[]={11,2,3,0,10};int pattern=ids[YsBound(d->pattern->GetSelection(),0,4)];double speed=player->Prop().GetVelocity();
 const double safeSpacing=YsGreater(double(d->spacing->GetNumber()),2.4*YsGreater(player->GetRadiusFromCollision(),player->GetApproximatedCollideRadius())+8.0);
 for(int i=0;i<YsBound(d->count->GetNumber(),0,4);++i){
 auto wing=world->AddAirplane(d->names[sel],YSFALSE);if(!wing)continue;wing->iff=FS_IFF0;
 wing->AutoSendCommand(info.playerAirInfo.weaponConfig.GetN(),info.playerAirInfo.weaponConfig,100);
 auto off=FsGetGroupOffset(pattern,i,safeSpacing);YsVec3 pos=player->GetPosition()+YsVec3(off.x,off.y+d->gap->GetNumber(),off.z);
 YsString c;c.Printf("POSITION %.6fm %.6fm %.6fm",pos.x(),pos.y(),pos.z());wing->SendCommand(c);
 wing->SendCommand("ATTITUDE 0deg 0deg 0deg");c.Printf("INITSPED %.6fm/s",speed);wing->SendCommand(c);wing->SendCommand("CTLLDGEA FALSE");wing->SendCommand("CTLTHROT 0.65");wing->Prop().SetFlightState(FSFLYING,FSDIEDOF_NULL);
 auto ap=FsGotoPosition::Create();ap->straightFlightMode=YSTRUE;ap->SetSingleDestination(pos.x(),pos.y(),pos.z()+1e12);ap->SetSpeed(speed);ap->SetUseAfterburner(YSFALSE);wing->SetAutopilot(ap);
 }
 player->name="STRAIGHT_TEST_PLAYER";
 if(auto show=FsGetAirshow(sim)){show->heading=0;show->pitch=0;show->dragging=false;}
 sim->SimProcessButtonFunction(FSBTF_COCKPITVIEW,FSUSC_ENABLE);
 Sim_Fly(nullptr);
}
