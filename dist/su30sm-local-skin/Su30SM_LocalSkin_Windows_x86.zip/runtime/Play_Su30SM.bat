@echo off
cd /d "%~dp0"
call Play_Su30SM_32.bat
