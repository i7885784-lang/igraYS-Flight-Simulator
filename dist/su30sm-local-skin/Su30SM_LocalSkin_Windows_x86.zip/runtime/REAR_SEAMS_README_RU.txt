Су-30СМ: текущая доработка стыков задних ниш. Запуск Play_Su30SM.bat. Для отката вернуть rollback-rear-seams/su30sm.dnm в aircraft/su30sm.dnm при закрытой игре. EXE и анимационные узлы сохранены.
