@echo off
cd /d "%~dp0"
start "" ysflight32_gl1.exe -script Start_Su57.script
