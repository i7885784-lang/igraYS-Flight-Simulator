@echo off
cd /d "%~dp0"
start "" ysflight64_gl1.exe -script Start_Su57.script
